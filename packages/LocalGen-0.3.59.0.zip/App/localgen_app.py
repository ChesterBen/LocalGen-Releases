from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any

import webview

from model_hub import MODEL_HUB
from localgen_update import UpdateManager

APP = Path(__file__).resolve().parent
FRONTEND = APP / "frontend"
ROOT = Path(r"C:\AI\LocalGen")
RUNTIME_APP = ROOT / "App"
QUALITY_SCORER = ROOT / "QualityRuntime" / "score_clip_aesthetic.py"
UPDATES = UpdateManager(ROOT)
os.environ.setdefault("ARGOS_PACKAGES_DIR", str(RUNTIME_APP / "data" / "argos-packages"))
os.environ.setdefault("ARGOS_CHUNK_TYPE", "MINISBD")
os.environ.setdefault("ARGOS_DEVICE_TYPE", "cpu")
os.environ.setdefault("ARGOS_COMPUTE_TYPE", "int8_float32")

CHARACTER_DIR = RUNTIME_APP / "data" / "characters"
CHARACTER_DB = CHARACTER_DIR / "profiles.json"
CHARACTER_LOCK = threading.Lock()
FRONTEND_ERROR_LOG = RUNTIME_APP / "data" / "frontend-errors.log"
FRONTEND_ERROR_LOG_MAX_BYTES = 512 * 1024
FRONTEND_ERROR_LOG_KEEP_LINES = 100
FRONTEND_ERROR_LOG_LOCK = threading.Lock()

def _sanitize_frontend_error_text(value: Any, limit: int) -> str:
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    text = "\n".join(line.rstrip() for line in text.split("\n")).strip()
    return text[-max(200, int(limit)):]

def _append_frontend_error(message: Any, stack: Any = "") -> None:
    FRONTEND_ERROR_LOG.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "at": datetime.now().isoformat(timespec="seconds"),
        "message": _sanitize_frontend_error_text(message, 1200),
    }
    stack_tail = _sanitize_frontend_error_text(stack, 3200)
    if stack_tail:
        record["stack_tail"] = stack_tail
    line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    with FRONTEND_ERROR_LOG_LOCK:
        with FRONTEND_ERROR_LOG.open("a", encoding="utf-8", newline="\n") as fh:
            fh.write(line + "\n")
        try:
            if FRONTEND_ERROR_LOG.stat().st_size > FRONTEND_ERROR_LOG_MAX_BYTES:
                lines = FRONTEND_ERROR_LOG.read_text(encoding="utf-8", errors="ignore").splitlines()[-FRONTEND_ERROR_LOG_KEEP_LINES:]
                temp = FRONTEND_ERROR_LOG.with_name(f".{FRONTEND_ERROR_LOG.name}.{uuid.uuid4().hex}.tmp")
                try:
                    with temp.open("w", encoding="utf-8", newline="\n") as fh:
                        if lines:
                            fh.write("\n".join(lines) + "\n")
                        fh.flush()
                        os.fsync(fh.fileno())
                    os.replace(temp, FRONTEND_ERROR_LOG)
                finally:
                    temp.unlink(missing_ok=True)
        except Exception:
            pass

def _load_characters() -> list[dict[str, Any]]:
    try:
        if not CHARACTER_DB.exists():
            return []
        data = json.loads(CHARACTER_DB.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []

def _save_characters(items: list[dict[str, Any]]) -> None:
    CHARACTER_DIR.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(items, ensure_ascii=False, indent=2)
    temp = CHARACTER_DIR / f".{CHARACTER_DB.name}.{uuid.uuid4().hex}.tmp"
    try:
        temp.write_text(payload, encoding="utf-8")
        os.replace(temp, CHARACTER_DB)
    finally:
        temp.unlink(missing_ok=True)

from localgen_service import (
    ASPECT_PRESETS,
    JOBS,
    MODEL_REGISTRY,
    backend_state,
    build_job,
    comfy_queue_snapshot,
    clean_temp_files,
    clean_stale_temp_files,
    clean_orphan_reference_cache,
    clean_stale_orphan_reference_cache,
    current_output_root,
    apply_runtime_settings as apply_service_runtime_settings,
    clipboard_image_to_file,
    copy_image_to_clipboard,
    output_path_from_result,
    prepare_prompt,
    recommend_create_model,
    plan_create_resolution as plan_create_resolution_service,
    free_comfy_memory,
    health_report,
    restart_comfy_backend,
    start_lifecycle_controller,
    stop_lifecycle_controller,
    runtime_settings,
    save_data_url,
    list_recent_outputs,
    delete_output_file,
    model_file_inventory,
    inspect_model_file,
    inspect_quality_regions as inspect_quality_regions_service,
    create_quality_region_mask as create_quality_region_mask_service,
    register_custom_sdxl_profile,
    register_custom_model_profile,
    delete_custom_model_profile as remove_custom_model_profile,
)

def _update_wait_pids() -> list[int]:
    values = [os.getpid(), os.getppid()]
    raw = str(os.environ.get("LOCALGEN_LAUNCHER_PID") or "").strip()
    if raw:
        try:
            values.append(int(raw))
        except ValueError:
            pass
    result: list[int] = []
    for value in values:
        value = int(value)
        if value > 0 and value not in result:
            result.append(value)
    return result


class API:
    def __init__(self) -> None:
        self._window = None
        self._update_apply_started = False
    def ready(self) -> dict[str, Any]:
        return {"ok": True, **backend_state()}

    def update_status(self) -> dict[str, Any]:
        try:
            current = str(backend_state().get("app_version") or "0.0.0")
            return UPDATES.status(current)
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def check_for_updates(self) -> dict[str, Any]:
        try:
            current = str(backend_state().get("app_version") or "0.0.0")
            return UPDATES.check(current)
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def download_update(self) -> dict[str, Any]:
        try:
            current = str(backend_state().get("app_version") or "0.0.0")
            return UPDATES.download(current)
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def apply_update(self) -> dict[str, Any]:
        try:
            local_queue = JOBS.queue_state()
            if int(local_queue.get("active_count") or 0) > 0:
                return {"ok": False, "message": "Дождись завершения очереди LocalGen"}
            comfy_queue = comfy_queue_snapshot()
            if comfy_queue.get("online") and (
                not comfy_queue.get("known") or not comfy_queue.get("idle")
            ):
                return {"ok": False, "message": "AI-движок ещё выполняет задачу"}
            current = str(backend_state().get("app_version") or "0.0.0")
            result = UPDATES.launch_apply(
                current,
                wait_pids=_update_wait_pids(),
                relaunch=str(RUNTIME_APP / "LocalGen.exe"),
            )
            if result.get("ok"):
                self._update_apply_started = True
                if self._window:
                    threading.Timer(0.35, self._window.destroy).start()
            return result
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def prepare_prompt(self, text: str, mode: str, model_id: str) -> dict[str, Any]:
        try:
            return {"ok": True, **prepare_prompt(str(text or ""), str(mode or "enhance"), str(model_id or "krea2_general"))}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def recommend_create_model(self, text: str, prompt_style: str = "auto") -> dict[str, Any]:
        try:
            return {"ok": True, **recommend_create_model(str(text or ""), str(prompt_style or "auto"))}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def plan_create_resolution(self, model_id: str, width: int, height: int) -> dict[str, Any]:
        try:
            return plan_create_resolution_service(str(model_id or ""), int(width), int(height))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def inspect_quality_regions(self, image_path: str) -> dict[str, Any]:
        try:
            return inspect_quality_regions_service(str(image_path or ""))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def create_quality_region_mask(self, image_path: str, bbox: list[Any], kind: str) -> dict[str, Any]:
        try:
            return create_quality_region_mask_service(str(image_path or ""), list(bbox or []), str(kind or "face"))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def score_quality_variants(self, paths: list[Any], prompt: str) -> dict[str, Any]:
        try:
            clean_prompt = str(prompt or "").strip()
            if not clean_prompt:
                return {"ok": False, "message": "Нет исходного промпта для оценки"}
            raw_paths = [str(x or "").strip() for x in list(paths or []) if str(x or "").strip()]
            if not 2 <= len(raw_paths) <= 6:
                return {"ok": False, "message": "Для оценки нужно от 2 до 6 изображений"}
            resolved: list[Path] = []
            allowed_ext = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
            for raw in raw_paths:
                path = Path(raw).expanduser().resolve()
                if not path.is_file() or path.suffix.lower() not in allowed_ext:
                    return {"ok": False, "message": f"Файл для оценки недоступен: {path.name}"}
                resolved.append(path)
            if not QUALITY_SCORER.is_file():
                return {"ok": False, "message": "Модуль оценки качества не установлен"}
            command = [
                sys.executable, str(QUALITY_SCORER),
                "--prompt", clean_prompt,
                "--device", "cpu",
            ]
            for path in resolved:
                command.extend(["--image", str(path)])
            env = dict(os.environ)
            env["PYTHONIOENCODING"] = "utf-8"
            proc = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=180,
                env=env,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if proc.returncode != 0:
                message = (proc.stderr or proc.stdout or "Scorer завершился с ошибкой").strip()
                return {"ok": False, "message": message[-900:]}
            result_line = next((line for line in proc.stdout.splitlines() if line.startswith("RESULT ")), "")
            if not result_line:
                return {"ok": False, "message": "Scorer не вернул результат"}
            data = json.loads(result_line[7:])
            if not isinstance(data, dict) or not data.get("ok"):
                return {"ok": False, "message": "Некорректный ответ scorer"}
            return data
        except subprocess.TimeoutExpired:
            return {"ok": False, "message": "Оценка качества заняла слишком много времени"}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def start_job(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            kind = str(kind)
            metadata = dict(payload or {})
            if kind == "create" and not metadata.get("seed"):
                metadata["seed"] = int(time.time() * 1000) % 2_147_483_647
            if kind == "animate" and metadata.get("seed") in (None, ""):
                metadata["seed"] = uuid.uuid4().int % 2_147_483_648
            command = build_job(kind, metadata)
            job_id = JOBS.create(kind, command, metadata=metadata)
            return {"ok": True, "job_id": job_id}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def job_state(self, job_id: str) -> dict[str, Any]:
        state = JOBS.state(str(job_id))
        path = output_path_from_result(state.get("result"))
        if path:
            state["output_path"] = str(path)
            try:
                state["output_url"] = path.resolve().as_uri()
            except Exception:
                pass
        return state

    def queue_state(self) -> dict[str, Any]:
        try:
            return {"ok": True, **JOBS.queue_state()}
        except Exception as exc:
            return {"ok": False, "message": str(exc), "running": [], "pending": [], "active_count": 0}

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        return {"ok": JOBS.cancel(str(job_id))}
    def choose_image(self) -> dict[str, Any]:
        if not self._window:
            return {"ok": False, "message": "Окно ещё не готово"}
        result = self._window.create_file_dialog(
            webview.FileDialog.OPEN,
            allow_multiple=False,
            file_types=("Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "All files (*.*)"),
        )
        path = str(result[0]) if result else ""
        return {"ok": bool(path), "path": path}

    def choose_images(self) -> dict[str, Any]:
        if not self._window:
            return {"ok": False, "message": "Окно ещё не готово"}
        result = self._window.create_file_dialog(
            webview.FileDialog.OPEN,
            allow_multiple=True,
            file_types=("Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "All files (*.*)"),
        )
        paths = [str(x) for x in (result or []) if str(x)]
        return {"ok": bool(paths), "paths": paths[:9], "truncated": len(paths) > 9}

    def choose_video(self) -> dict[str, Any]:
        if not self._window:
            return {"ok": False, "message": "Окно ещё не готово"}
        result = self._window.create_file_dialog(
            webview.FileDialog.OPEN,
            allow_multiple=False,
            file_types=("Video (*.mp4;*.mkv;*.webm;*.mov)", "All files (*.*)"),
        )
        path = str(result[0]) if result else ""
        return {"ok": bool(path), "path": path}

    def choose_mask(self) -> dict[str, Any]:
        return self.choose_image()

    def paste_image(self) -> dict[str, Any]:
        try:
            path = clipboard_image_to_file()
            return {"ok": bool(path), "path": path or "", "message": "" if path else "В буфере нет изображения"}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}
    def copy_image(self, path: str) -> dict[str, Any]:
        try:
            return {"ok": copy_image_to_clipboard(str(path))}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def copy_text(self, text: str) -> dict[str, Any]:
        try:
            import win32clipboard
            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardText(str(text or ""), win32clipboard.CF_UNICODETEXT)
            finally:
                win32clipboard.CloseClipboard()
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def reveal(self, path: str) -> dict[str, Any]:
        try:
            p = Path(path)
            if p.exists():
                subprocess_args = ["explorer.exe", f"/select,{p}"] if p.is_file() else ["explorer.exe", str(p)]
                import subprocess
                subprocess.Popen(subprocess_args)
                return {"ok": True}
            return {"ok": False, "message": "Файл не найден"}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}
    def choose_output_directory(self) -> dict[str, Any]:
        try:
            if not self._window:
                return {"ok": False, "message": "Окно ещё не готово"}
            current = current_output_root()
            current.mkdir(parents=True, exist_ok=True)
            result = self._window.create_file_dialog(
                webview.FileDialog.FOLDER,
                directory=str(current),
                allow_multiple=False,
            )
            path = str(result[0]) if result else ""
            return {"ok": bool(path), "path": path, "cancelled": not bool(path)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def apply_runtime_settings(
        self,
        output_directory: str,
        performance_profile: str,
        vram_policy: str = "",
        vram_idle_minutes: int | None = None,
        backend_policy: str = "",
        backend_idle_minutes: int | None = None,
    ) -> dict[str, Any]:
        try:
            settings = apply_service_runtime_settings(
                output_directory,
                performance_profile,
                vram_policy or None,
                vram_idle_minutes,
                backend_policy or None,
                backend_idle_minutes,
            )
            return {"ok": True, "settings": settings, **backend_state()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def open_outputs(self) -> dict[str, Any]:
        try:
            output = current_output_root()
            output.mkdir(parents=True, exist_ok=True)
            os.startfile(str(output))
            return {"ok": True, "path": str(output)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def delete_output(self, path: str) -> dict[str, Any]:
        try:
            return delete_output_file(path)
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def save_as(self, path: str) -> dict[str, Any]:
        try:
            source = Path(path)
            if not source.exists() or not self._window:
                return {"ok": False, "message": "Файл не найден"}
            ext = source.suffix or ".png"
            result = self._window.create_file_dialog(
                webview.FileDialog.SAVE,
                save_filename=source.name,
                file_types=(f"{ext.upper()} (*{ext})", "All files (*.*)"),
            )
            if not result:
                return {"ok": False, "cancelled": True}
            selected = result[0] if isinstance(result, (list, tuple)) else result
            target = Path(str(selected))
            if source.resolve() == target.resolve():
                return {"ok": True, "path": str(target)}
            shutil.copy2(source, target)
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def window_action(self, action: str) -> dict[str, Any]:
        try:
            if not self._window:
                return {"ok": False}
            if action == "minimize":
                self._window.minimize()
            elif action == "maximize":
                self._window.toggle_fullscreen() if False else self._window.maximize()
            elif action == "restore":
                self._window.restore()
            elif action == "close":
                threading.Timer(0.05, self._window.destroy).start()
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}
    def save_mask(self, data_url: str, grow: int = 0, feather: float = 0.0, invert: bool = False) -> dict[str, Any]:
        try:
            from PIL import Image, ImageFilter, ImageOps
            path = save_data_url(str(data_url), prefix="mask", suffix=".png")
            image = Image.open(path).convert("L")
            if bool(invert):
                image = ImageOps.invert(image)
            grow_px = max(0, min(32, int(grow or 0)))
            if grow_px:
                image = image.filter(ImageFilter.MaxFilter(grow_px * 2 + 1))
            feather_px = max(0.0, min(24.0, float(feather or 0.0)))
            if feather_px:
                image = image.filter(ImageFilter.GaussianBlur(radius=feather_px))
            image.save(path)
            return {"ok": True, "path": path, "grow": grow_px, "feather": feather_px, "invert": bool(invert)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def save_dropped_image(self, data_url: str, filename: str = "") -> dict[str, Any]:
        try:
            suffix = Path(filename or "image.png").suffix.lower()
            if suffix not in {".png",".jpg",".jpeg",".webp",".bmp"}:
                suffix = ".png"
            path = save_data_url(str(data_url), prefix="drop", suffix=suffix)
            return {"ok": True, "path": path}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def export_profile(self, profile: dict[str, Any]) -> dict[str, Any]:
        try:
            if not self._window:
                return {"ok": False, "message": "Окно ещё не готово"}
            payload = {
                "format": "localgen-profile",
                "version": 1,
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "preferences": profile.get("preferences") if isinstance(profile, dict) else {},
                "prompt_history": profile.get("prompt_history") if isinstance(profile, dict) else [],
                "user_presets": profile.get("user_presets") if isinstance(profile, dict) else [],
                "favorites": profile.get("favorites") if isinstance(profile, dict) else [],
            }
            result = self._window.create_file_dialog(
                webview.FileDialog.SAVE,
                save_filename=f"LocalGen-profile-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json",
                file_types=("LocalGen profile (*.json)", "JSON (*.json)"),
            )
            if not result:
                return {"ok": False, "cancelled": True}
            selected = result[0] if isinstance(result, (list, tuple)) else result
            target = Path(str(selected))
            target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            return {"ok": True, "path": str(target)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def import_profile(self) -> dict[str, Any]:
        try:
            if not self._window:
                return {"ok": False, "message": "Окно ещё не готово"}
            result = self._window.create_file_dialog(
                webview.FileDialog.OPEN,
                allow_multiple=False,
                file_types=("LocalGen profile (*.json)", "JSON (*.json)", "All files (*.*)"),
            )
            if not result:
                return {"ok": False, "cancelled": True}
            path = Path(str(result[0]))
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or data.get("format") != "localgen-profile" or int(data.get("version", 0)) != 1:
                return {"ok": False, "message": "Это не поддерживаемый профиль LocalGen"}
            preferences = data.get("preferences") if isinstance(data.get("preferences"), dict) else {}
            prompt_history_raw = data.get("prompt_history") if isinstance(data.get("prompt_history"), list) else []
            user_presets_raw = data.get("user_presets") if isinstance(data.get("user_presets"), list) else []
            favorites_raw = data.get("favorites") if isinstance(data.get("favorites"), list) else []
            prompt_history = [
                item for item in prompt_history_raw
                if isinstance(item, dict)
                and item.get("kind") in {"create", "edit", "motion"}
                and isinstance(item.get("text"), str) and item["text"].strip()
            ][:200]
            user_presets = [
                item for item in user_presets_raw
                if isinstance(item, dict)
                and isinstance(item.get("id"), str) and item["id"].strip()
                and isinstance(item.get("name"), str) and item["name"].strip()
            ][:100]
            favorites = [item for item in favorites_raw if isinstance(item, str) and item.strip()][:2000]
            return {
                "ok": True,
                "path": str(path),
                "profile": {
                    "preferences": preferences,
                    "prompt_history": prompt_history,
                    "user_presets": user_presets,
                    "favorites": favorites,
                },
            }
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def recent_outputs(self, limit: int = 60) -> dict[str, Any]:
        try:
            return {"ok": True, "items": list_recent_outputs(limit)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def model_inventory(self) -> dict[str, Any]:
        try:
            return {"ok": True, **model_file_inventory()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def open_model_folder(self, folder: str = "root") -> dict[str, Any]:
        try:
            folders = {
                "root": ROOT / "Models",
                "checkpoints": ROOT / "Models" / "checkpoints",
                "diffusion_models": ROOT / "Models" / "diffusion_models",
                "loras": ROOT / "Models" / "loras",
                "text_encoders": ROOT / "Models" / "text_encoders",
                "vae": ROOT / "Models" / "vae",
                "upscale_models": ROOT / "Models" / "upscale_models",
            }
            path = folders.get(str(folder or "root"))
            if path is None:
                return {"ok": False, "message": "Неизвестная папка моделей"}
            path.mkdir(parents=True, exist_ok=True)
            os.startfile(str(path))
            return {"ok": True, "path": str(path)}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def import_model_file(self, folder: str = "checkpoints") -> dict[str, Any]:
        try:
            if not self._window:
                return {"ok": False, "message": "Окно ещё не готово"}
            folders = {
                "checkpoints": ROOT / "Models" / "checkpoints",
                "diffusion_models": ROOT / "Models" / "diffusion_models",
                "loras": ROOT / "Models" / "loras",
                "text_encoders": ROOT / "Models" / "text_encoders",
                "vae": ROOT / "Models" / "vae",
                "upscale_models": ROOT / "Models" / "upscale_models",
            }
            dest_dir = folders.get(str(folder or "checkpoints"))
            if dest_dir is None:
                return {"ok": False, "message": "Неизвестный тип модели"}
            result = self._window.create_file_dialog(
                webview.FileDialog.OPEN,
                allow_multiple=False,
                file_types=("Model files (*.safetensors;*.ckpt;*.pt;*.pth;*.gguf)", "All files (*.*)"),
            )
            if not result:
                return {"ok": False, "cancelled": True}
            source = Path(str(result[0])).resolve()
            if not source.is_file() or source.suffix.lower() not in {".safetensors", ".ckpt", ".pt", ".pth", ".gguf"}:
                return {"ok": False, "message": "Выбран неподдерживаемый файл модели"}
            dest_dir.mkdir(parents=True, exist_ok=True)
            destination = dest_dir / source.name
            if source != destination.resolve():
                if destination.exists():
                    return {"ok": False, "message": f"Файл {destination.name} уже существует в этой папке"}
                shutil.copy2(source, destination)
            return {"ok": True, "path": str(destination), "name": destination.name, **model_file_inventory()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def inspect_model(self, folder: str, name: str) -> dict[str, Any]:
        try:
            return {"ok": True, **inspect_model_file(str(folder or ""), str(name or ""))}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def register_custom_sdxl(self, name: str, checkpoint: str, settings: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            profile = register_custom_sdxl_profile(str(name or ""), str(checkpoint or ""), dict(settings or {}))
            return {"ok": True, "profile": profile, "backend": backend_state(), "inventory": model_file_inventory()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def register_custom_model(self, name: str, folder: str, model_file: str, family: str, settings: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            profile = register_custom_model_profile(
                str(name or ""), str(folder or ""), str(model_file or ""), str(family or ""), dict(settings or {})
            )
            return {"ok": True, "profile": profile, "backend": backend_state(), "inventory": model_file_inventory()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def delete_custom_model(self, model_id: str) -> dict[str, Any]:
        try:
            ok = remove_custom_model_profile(str(model_id or ""))
            return {"ok": ok, "backend": backend_state(), "inventory": model_file_inventory()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def open_model_catalog(self, site: str) -> dict[str, Any]:
        urls = {
            "huggingface": "https://huggingface.co/models?pipeline_tag=text-to-image&library=safetensors&sort=trending",
            "civitai": "https://civitai.com/models",
            "comfy_manager": "https://docs.comfy.org/manager",
        }
        url = urls.get(str(site or ""))
        if not url:
            return {"ok": False, "message": "Неизвестный каталог"}
        try:
            webbrowser.open(url)
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def resolve_model_link(self, source: str) -> dict[str, Any]:
        try:
            return MODEL_HUB.resolve(str(source or ""))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def start_model_download(self, candidate_id: str, folder: str = "") -> dict[str, Any]:
        try:
            return MODEL_HUB.start(str(candidate_id or ""), str(folder or ""))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def model_download_state(self) -> dict[str, Any]:
        try:
            return MODEL_HUB.state()
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def cancel_model_download(self, job_id: str) -> dict[str, Any]:
        try:
            return MODEL_HUB.cancel(str(job_id or ""))
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def list_characters(self) -> dict[str, Any]:
        try:
            items = []
            for item in _load_characters():
                path = Path(str(item.get("image_path") or ""))
                if not path.exists():
                    continue
                row = dict(item)
                row["image_url"] = path.resolve().as_uri()
                items.append(row)
            return {"ok": True, "items": items}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def create_character(self, name: str, source_path: str, description: str = "") -> dict[str, Any]:
        try:
            clean_name = str(name or "").strip()
            if not clean_name:
                return {"ok": False, "message": "Укажи имя персонажа"}
            src = Path(str(source_path or ""))
            if not src.exists() or src.suffix.lower() not in {".png",".jpg",".jpeg",".webp",".bmp"}:
                return {"ok": False, "message": "Нужно выбрать существующее изображение"}
            with CHARACTER_LOCK:
                items = _load_characters()
                if len(items) >= 50:
                    return {"ok": False, "message": "Можно сохранить не более 50 персонажей"}
                CHARACTER_DIR.mkdir(parents=True, exist_ok=True)
                ident = uuid.uuid4().hex[:12]
                dst = CHARACTER_DIR / f"{ident}{src.suffix.lower()}"
                shutil.copy2(src, dst)
                item = {
                    "id": ident,
                    "name": clean_name[:60],
                    "description": str(description or "").strip()[:500],
                    "image_path": str(dst),
                    "created_at": datetime.now().isoformat(timespec="seconds"),
                }
                items.append(item)
                try:
                    _save_characters(items)
                except Exception:
                    dst.unlink(missing_ok=True)
                    raise
            item = dict(item)
            item["image_url"] = dst.resolve().as_uri()
            return {"ok": True, "item": item}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def delete_character(self, character_id: str) -> dict[str, Any]:
        try:
            ident = str(character_id or "")
            with CHARACTER_LOCK:
                items = _load_characters()
                target = next((x for x in items if str(x.get("id")) == ident), None)
                if not target:
                    return {"ok": False, "message": "Персонаж не найден"}
                path = Path(str(target.get("image_path") or ""))
                _save_characters([x for x in items if str(x.get("id")) != ident])
                if path.exists() and path.parent.resolve() == CHARACTER_DIR.resolve():
                    path.unlink(missing_ok=True)
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def health_check(self) -> dict[str, Any]:
        try:
            return {"ok": True, **health_report()}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def free_vram(self) -> dict[str, Any]:
        try:
            return free_comfy_memory()
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def restart_backend(self) -> dict[str, Any]:
        try:
            return restart_comfy_backend()
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def clean_temp(self) -> dict[str, Any]:
        try:
            return clean_temp_files()
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def log_frontend_error(self, message: str, stack: str = "") -> dict[str, Any]:
        try:
            _append_frontend_error(message, stack)
            return {"ok": True}
        except Exception:
            return {"ok": False}


def _frontend_probe(window) -> None:
    import time
    time.sleep(2.0)
    try:
        window.evaluate_js("""
          window.__localgenProbeReady = null;
          window.__localgenProbeQueue = null;
          if (window.pywebview && window.pywebview.api && window.pywebview.api.ready) {
            window.pywebview.api.ready()
              .then(x => window.__localgenProbeReady = {ok:true, value:x})
              .catch(e => window.__localgenProbeReady = {ok:false, error:String(e)});
            if (window.pywebview.api.queue_state) {
              window.pywebview.api.queue_state()
                .then(x => window.__localgenProbeQueue = {ok:true, value:x})
                .catch(e => window.__localgenProbeQueue = {ok:false, error:String(e)});
            }
          } else {
            window.__localgenProbeReady = {ok:false, error:'api missing'};
          }
          true;
        """)
        time.sleep(2.0)
        for _ in range(30):
            try:
                frontend_ready = window.evaluate_js(
                    "Boolean(typeof state!=='undefined' && state.backend && "
                    "Array.isArray(state.backend.models) && state.backend.models.length>0 && "
                    "document.querySelectorAll('#createModels .model-card').length>0)"
                )
                if frontend_ready:
                    break
            except Exception:
                pass
            time.sleep(0.5)
        window.evaluate_js("""
          window.__p31RuntimeProbe = null;
          if (typeof state !== 'undefined' && typeof renderQueueState === 'function') {
            const originalProfile = state.pendingPerformanceProfile || state.runtimeSettings?.performance_profile || 'auto';
            state.pendingPerformanceProfile = originalProfile === 'lowram' ? 'balanced' : 'lowram';
            if (typeof renderRuntimeSettings === 'function') renderRuntimeSettings();
            window.__p31RuntimeProbe = {
              output: document.querySelector('#runtimeOutputDirectory')?.value || '',
              dirtyBadge: document.querySelector('#runtimeSettingsBadge')?.textContent || '',
              selectedProfile: document.querySelector('[data-runtime-profile].active')?.dataset.runtimeProfile || '',
              applyDisabledBeforeQueue: !!document.querySelector('#applyRuntimeSettings')?.disabled,
              hasApplyApi: !!window.pywebview?.api?.apply_runtime_settings
            };
            window.__p32AnimateProbe = null;
            if (typeof renderAnimateControls === 'function') {
              const models = state.backend?.models || [];
              const preview = models.find(x => x.id === 'wan22_preview');
              const quality = models.find(x => x.id === 'wan22_quality');
              if (preview && quality) {
                state.animateModel = preview.id;
                state.animateSeconds = 2.37;
                state.fps = 20;
                state.animateWidth = 960;
                state.animateHeight = 544;
                state.animateSeed = '123456';
                state.animateExpertOverrides = {
                  ...(state.animateExpertOverrides || {}),
                  [preview.id]: {
                    steps: 7, cfg: 4.2, shift: 7.5, sampler: 'euler',
                    negative: 'probe negative'
                  }
                };
                renderAnimateControls();
                const previewSnapshot = {
                  model: state.animateModel,
                  seconds: state.animateSeconds,
                  fps: state.fps,
                  frames: state.frames,
                  width: state.animateWidth,
                  height: state.animateHeight,
                  actualSeconds: state.frames / state.fps,
                  durationInfo: document.querySelector('#animateDurationInfo')?.textContent || '',
                  resolutionInfo: document.querySelector('#animateResolutionInfo')?.textContent || '',
                  expertSummary: document.querySelector('#animateExpertSummary')?.textContent || '',
                  steps: document.querySelector('#animateSteps')?.value || '',
                  cfg: document.querySelector('#animateCfg')?.value || '',
                  shift: document.querySelector('#animateShift')?.value || '',
                  sampler: document.querySelector('#animateSampler')?.value || '',
                  negative: document.querySelector('#animateNegative')?.value || '',
                  seed: document.querySelector('#animateSeed')?.value || '',
                  activeResolution: document.querySelector('[data-animate-resolution].active')?.textContent || '',
                  hint: document.querySelector('#animateHint')?.textContent || ''
                };
                state.animateModel = quality.id;
                renderAnimateControls({modelChanged:true});
                const qualitySnapshot = {
                  model: state.animateModel,
                  width: state.animateWidth,
                  height: state.animateHeight,
                  pixels: state.animateWidth * state.animateHeight,
                  maxPixels: quality.video_controls?.max_pixels || 0,
                  activeResolution: document.querySelector('[data-animate-resolution].active')?.textContent || '',
                  hint: document.querySelector('#animateHint')?.textContent || ''
                };
                window.__p32AnimateProbe = {
                  preview: previewSnapshot,
                  quality: qualitySnapshot,
                  durationButtons: document.querySelectorAll('[data-duration-seconds]').length,
                  resolutionButtons: document.querySelectorAll('[data-animate-resolution]').length,
                  hasCustomSeconds: !!document.querySelector('#animateSeconds'),
                  hasFps: !!document.querySelector('#animateFps'),
                  hasExpertPanel: !!document.querySelector('#animateExpertPanel')
                };
              }
            }
            window.__p35RenderProbe = null;
            if (typeof renderCreateQuality === 'function' && typeof setExpertParam === 'function') {
              const models = state.backend?.models || [];
              const mystic = models.find(x => x.id === 'krea2_adult');
              const originalPrefs = localStorage.getItem(PREF_KEY);
              const originalPresets = localStorage.getItem(USER_PRESET_KEY);
              if (mystic) {
                state.autoModel = false;
                state.createModel = mystic.id;
                state.aspect = 'fhd_native';
                state.createWidth = 1920;
                state.createHeight = 1080;
                document.querySelector('#createWidth').value = 1920;
                document.querySelector('#createHeight').value = 1080;
                if (!state.expertOverrides || typeof state.expertOverrides !== 'object') state.expertOverrides = {};
                delete state.expertOverrides[mystic.id];
                state.createQuality = 'standard';
                renderExpertModelControls(); renderCreateQuality(); renderAspects();
                const standard = {
                  mode: state.createQuality,
                  label: document.querySelector('#standardQualityLabel')?.textContent || '',
                  maxLabel: document.querySelector('#maxQualityLabel')?.textContent || '',
                  fhdSupported: modelSupportsNativeSize(1920,1080,mystic),
                  fhdUnsupportedClass: document.querySelector('[data-aspect="fhd_native"]')?.classList.contains('unsupported') ?? null
                };
                state.createQuality = 'max'; renderExpertModelControls(); renderCreateQuality();
                const maximum = {
                  mode: state.createQuality,
                  help: document.querySelector('#createQualityHelp')?.textContent || '',
                  label: document.querySelector('#maxQualityLabel')?.textContent || ''
                };
                setExpertParam('steps', 9);
                setExpertParam('scheduler', 'simple');
                setExpertParam('lora_strength', 0.85);
                const manual = {
                  mode: state.createQuality,
                  activeButton: document.querySelector('[data-create-quality="custom"]')?.classList.contains('active') || false,
                  panelOpen: !!document.querySelector('#expertModelPanel')?.open,
                  label: document.querySelector('#customQualityLabel')?.textContent || '',
                  steps: document.querySelector('[data-expert-param="steps"]')?.value || '',
                  scheduler: document.querySelector('[data-expert-param="scheduler"]')?.value || '',
                  lora: document.querySelector('[data-expert-param="lora_strength"]')?.value || '',
                  overrides: {...modelExpertOverrides(mystic.id)}
                };
                document.querySelector('#userPresetName').value = 'P35 QA preset';
                saveUserPreset();
                const stored = userPresets().find(x => x.name === 'P35 QA preset');
                state.createQuality = 'standard'; delete state.expertOverrides[mystic.id];
                if (stored) applyUserPreset(stored.id);
                const presetRoundTrip = stored ? {
                  quality: state.createQuality,
                  steps: modelExpertOverrides(mystic.id).steps,
                  scheduler: modelExpertOverrides(mystic.id).scheduler,
                  lora: modelExpertOverrides(mystic.id).lora_strength,
                  width: +document.querySelector('#createWidth').value,
                  height: +document.querySelector('#createHeight').value
                } : null;
                resetExpertModel();
                const reset = {
                  mode: state.createQuality,
                  overrideCount: Object.keys(modelExpertOverrides(mystic.id)).length,
                  activeStandard: document.querySelector('[data-create-quality="standard"]')?.classList.contains('active') || false
                };
                const fhdModels = models.filter(x => x.kind === 'create' && x.installed).map(x => ({
                  id:x.id, side:x.max_native_side, pixels:x.max_native_pixels,
                  fhd:modelSupportsNativeSize(1920,1080,x)
                }));
                window.__p35RenderProbe = {
                  standard, maximum, manual, presetRoundTrip, reset, fhdModels,
                  qualityButtons: document.querySelectorAll('[data-create-quality]').length,
                  cacheP35: [...document.styleSheets].some(s => String(s.href||'').includes('p35'))
                };
              }
              if (originalPrefs === null) localStorage.removeItem(PREF_KEY); else localStorage.setItem(PREF_KEY, originalPrefs);
              if (originalPresets === null) localStorage.removeItem(USER_PRESET_KEY); else localStorage.setItem(USER_PRESET_KEY, originalPresets);
              renderUserPresets();
            }
            window.__p35CleanStartProbe = null;
            if (typeof cleanStartCreateContext === 'function') {
              const models = state.backend?.models || [];
              const characterModel = models.find(x => x.id === 'qwen21_character');
              const normalQwen = models.find(x => x.id === 'qwen21_design' && x.installed);
              const sourceModel = characterModel?.installed ? characterModel : (models.find(x => x.kind === 'create' && x.installed) || null);
              if (sourceModel) {
                state.createModel = sourceModel.id;
                state.createReferences = [{path:'C:/qa/ref.png',name:'ref.png'}];
                state.createReferenceRoles = ['identity'];
                state.structureControl = 'C:/qa/control.png';
                state.structureStrength = 0.65;
                state.createCharacter = 'qa-character';
                state.promptStyle = 'cinematic';
                state.promptLighting = 'studio';
                state.promptCamera = '50mm';
                state.promptFraming = 'portrait';
                if (!state.expertOverrides || typeof state.expertOverrides !== 'object') state.expertOverrides = {};
                state.expertOverrides[sourceModel.id] = {steps:9};
                state.createQuality = 'custom';
                const promptBefore = document.querySelector('#createPrompt')?.value || '';
                const widthBefore = document.querySelector('#createWidth')?.value || '';
                const heightBefore = document.querySelector('#createHeight')?.value || '';
                document.querySelector('#createSeed').value = '123456789';
                cleanStartCreateContext();
                window.__p35CleanStartProbe = {
                  refs: state.createReferences.length,
                  roles: state.createReferenceRoles.length,
                  structureControl: state.structureControl,
                  structureStrength: state.structureStrength,
                  character: state.createCharacter,
                  seed: document.querySelector('#createSeed')?.value || '',
                  style: state.promptStyle,
                  lighting: state.promptLighting,
                  camera: state.promptCamera,
                  framing: state.promptFraming,
                  quality: state.createQuality,
                  overrideCount: Object.keys(modelExpertOverrides(sourceModel.id)).length,
                  model: state.createModel,
                  leftCharacterWorkflow: sourceModel.workflow !== 'character_scene' || (!!normalQwen && state.createModel === normalQwen.id),
                  promptPreserved: (document.querySelector('#createPrompt')?.value || '') === promptBefore,
                  widthPreserved: (document.querySelector('#createWidth')?.value || '') === widthBefore,
                  heightPreserved: (document.querySelector('#createHeight')?.value || '') === heightBefore,
                  buttonPresent: !!document.querySelector('#cleanStartCreate')
                };
              }
            }
            window.__p36ZImageProbe = null;
            if (typeof renderModels === 'function' && typeof renderExpertModelControls === 'function' && typeof renderCreateQuality === 'function') {
              const z = (state.backend?.models || []).find(x => x.id === 'zimage_turbo_q5');
              if (z) {
                state.autoModel = false;
                state.createModel = z.id;
                state.createQuality = 'standard';
                state.aspect = 'fhd_native';
                state.createWidth = 1920;
                state.createHeight = 1080;
                const cw=document.querySelector('#createWidth'), ch=document.querySelector('#createHeight');
                if(cw)cw.value='1920'; if(ch)ch.value='1080';
                renderModels(); renderExpertModelControls(); renderCreateQuality(); renderAspects();
                const card=document.querySelector('[data-model="zimage_turbo_q5"]');
                const expert=(key)=>document.querySelector('[data-expert-param="'+key+'"]')?.value ?? null;
                window.__p36ZImageProbe = {
                  installed: !!z.installed,
                  name: z.name || '',
                  family: z.family || '',
                  workflow: z.workflow || '',
                  category: z.category || '',
                  tier: z.quality_tier || '',
                  cardPresent: !!card,
                  cardSelected: !!card?.classList.contains('selected'),
                  cardText: card?.innerText || '',
                  standardLabel: document.querySelector('#standardQualityLabel')?.textContent || '',
                  maxLabel: document.querySelector('#maxQualityLabel')?.textContent || '',
                  steps: expert('steps'),
                  cfg: expert('cfg'),
                  sampler: expert('sampler'),
                  scheduler: expert('scheduler'),
                  shift: expert('shift'),
                  fhdSupported: (typeof modelSupportsNativeSize === 'function') ? modelSupportsNativeSize(1920,1080,z) : null,
                  fhdUnsupportedClass: document.querySelector('[data-aspect="fhd_native"]')?.classList.contains('unsupported') ?? null,
                  maxSide: z.max_native_side,
                  maxPixels: z.max_native_pixels,
                  bestFor: z.best_for || '',
                  limitations: z.limitations || ''
                };
              }
            }
            window.__p36StructureProbe = null;
            if (typeof renderStructureControl === 'function' && typeof updateAutoModelRecommendation === 'function') {
              const z=(state.backend?.models||[]).find(x=>x.id==='zimage_turbo_q5');
              if(z?.installed&&z?.structure_control_installed){
                state.createReferences=[];state.createReferenceRoles=[];
                state.autoModel=true;
                state.createModel=(state.backend?.models||[]).find(x=>x.id==='krea2_general'&&x.installed)?.id||state.createModel;
                state.structureControl='C:/AI/LocalGen/App/data/qa-p36-zimage-controlnet/canny_smoke.png';
                state.structureMode='canny';
                state.structureStrength=0.85;
                renderCreateReferences();renderStructureControl();
                updateAutoModelRecommendation();
                renderStructureControl();
                const preview=document.querySelector('#structureControlPreview');
                const beforeRef={
                  model:state.createModel,
                  routedToZImage:state.createModel==='zimage_turbo_q5',
                  autoModel:state.autoModel,
                  badge:document.querySelector('#structureControlBadge')?.textContent||'',
                  previewEmpty:preview?.classList.contains('empty')??null,
                  strength:document.querySelector('#structureStrength')?.value||'',
                  strengthText:document.querySelector('#structureStrengthValue')?.textContent||'',
                  status:document.querySelector('#structureControlStatus')?.textContent||'',
                  switchHidden:document.querySelector('#useZImageForStructure')?.classList.contains('hidden')??null,
                  shootoutDisabled:document.querySelector('#modelShootoutBtn')?.disabled??null,
                  controlInstalled:!!z.structure_control_installed,
                  availableModes:[...(z.structure_control_modes||[])],
                  activeMode:state.structureMode,
                  modeButtons:document.querySelectorAll('[data-structure-mode]').length
                };
                state.structureMode='pose'; renderStructureControl();
                const poseMode={
                  active:document.querySelector('[data-structure-mode="pose"]')?.classList.contains('active')||false,
                  disabled:document.querySelector('[data-structure-mode="pose"]')?.disabled??null,
                  badge:document.querySelector('#structureControlBadge')?.textContent||'',
                  status:document.querySelector('#structureControlStatus')?.textContent||''
                };
                state.structureMode='depth'; renderStructureControl();
                const depthMode={
                  active:document.querySelector('[data-structure-mode="depth"]')?.classList.contains('active')||false,
                  disabled:document.querySelector('[data-structure-mode="depth"]')?.disabled??null,
                  badge:document.querySelector('#structureControlBadge')?.textContent||'',
                  status:document.querySelector('#structureControlStatus')?.textContent||''
                };
                state.structureMode='canny'; renderStructureControl();
                appendCreateReferences(['C:/qa/reference.png']);
                const afterReference={
                  structureControl:state.structureControl,
                  refs:state.createReferences.length
                };
                state.createReferences=[];state.createReferenceRoles=[];
                state.structureControl='C:/AI/LocalGen/App/data/qa-p36-zimage-controlnet/canny_smoke.png';
                state.structureStrength=0.55;
                cleanStartCreateContext();
                const afterClean={
                  structureControl:state.structureControl,
                  mode:state.structureMode,
                  strength:state.structureStrength
                };
                window.__p36StructureProbe={
                  cardPresent:!!document.querySelector('#createStructureCard'),
                  pickPresent:!!document.querySelector('#pickStructureControl'),
                  pastePresent:!!document.querySelector('#pasteStructureControl'),
                  strengthPresent:!!document.querySelector('#structureStrength'),
                  beforeRef,poseMode,depthMode,afterReference,afterClean,
                  cache:[...document.styleSheets].some(s=>String(s.href||'').includes('p37repair2'))
                };
              }
            }
            window.__p37RepairProbe = null;
            if (typeof wireMaskEditor === 'function') {
              const opacity=document.querySelector('#maskOpacity');
              const overlay=document.querySelector('#maskOverlay');
              const invert=document.querySelector('#maskInvert');
              const grow=document.querySelector('#maskGrow');
              const feather=document.querySelector('#maskFeather');
              const oldOpacity=opacity?.value || '85';
              if(opacity){opacity.value='55';opacity.oninput?.();}
              const opacityApplied=overlay?.style.opacity || '';
              const beforeInvert=(typeof maskInvert!=='undefined')?maskInvert:null;
              invert?.onclick?.();
              const invertOn=(typeof maskInvert!=='undefined')?maskInvert:null;
              const invertClassOn=!!invert?.classList.contains('active');
              invert?.onclick?.();
              const invertRestored=(typeof maskInvert!=='undefined')?maskInvert:null;
              if(opacity){opacity.value=oldOpacity;opacity.oninput?.();}
              window.__p37RepairProbe={
                controls:{
                  brush:!!document.querySelector('#maskBrush'),
                  opacity:!!opacity,
                  draw:!!document.querySelector('#maskDraw'),
                  erase:!!document.querySelector('#maskErase'),
                  invert:!!invert,
                  clear:!!document.querySelector('#maskClear'),
                  grow:!!grow,
                  feather:!!feather,
                  save:!!document.querySelector('#maskSave')
                },
                handlers:{
                  opacity:typeof opacity?.oninput==='function',
                  invert:typeof invert?.onclick==='function',
                  save:typeof document.querySelector('#maskSave')?.onclick==='function'
                },
                opacityApplied,
                invertRoundTrip:beforeInvert===false&&invertOn===true&&invertClassOn&&invertRestored===false,
                growDefault:grow?.value || '',
                featherDefault:feather?.value || '',
                exactHelp:(document.querySelector('#editModeHelp')?.textContent||''),
                cache:[...document.styleSheets].some(s=>String(s.href||'').includes('p37repair2'))
              };
            }
            state.queueSnapshot = {
              running:[{id:'probe-running',kind:'create',state:'running',started_at:Date.now()/1000-3,metadata:{model:'flux2_fast',source_prompt:'probe running'}}],
              pending:[{id:'probe-pending',kind:'edit_smart',state:'queued',queue_position:1,metadata:{source_prompt:'probe pending'}}],
              active_count:2,max_pending:20
            };
            renderQueueState();
            if (typeof renderRuntimeSettings === 'function') renderRuntimeSettings();
            window.__p31RuntimeProbe.applyDisabledWithQueue = !!document.querySelector('#applyRuntimeSettings')?.disabled;
            window.__p33SettingsProbe = null;
            if (typeof switchView === 'function' && typeof applyUiScale === 'function') {
              switchView('settings');
              applyUiScale(120,{persist:false,announce:false});
              const specs = [
                ['quick','.quickstart-card'],['prompt','.prompt-settings-card'],['backend','.backend-settings-card'],
                ['about','.about-card'],['runtime','.runtime-settings-card'],['health','.health-card'],
                ['interface','.interface-scale-card'],['profile','.profile-card'],['shortcuts','.shortcuts-card'],
                ['diagnostics','.diagnostics-card'],['models','.model-manager-card']
              ];
              const cards = {};
              for (const [name,selector] of specs) {
                const el=document.querySelector(selector);
                if (!el) continue;
                const r=el.getBoundingClientRect();
                cards[name]={x:r.x,y:r.y,w:r.width,h:r.height,right:r.right,bottom:r.bottom,order:getComputedStyle(el).order};
              }
              const grid=document.querySelector('.settings-grid')?.getBoundingClientRect();
              const viewport=document.querySelector('.viewport');
              const same=(a,b,key,t=1.5)=>Math.abs((cards[a]?.[key]||0)-(cards[b]?.[key]||0))<=t;
              window.__p33SettingsProbe = {
                uiScale: state.uiScale,
                logicalLayoutNarrow: document.documentElement.classList.contains('ui-layout-narrow'),
                logicalLayoutCompact: document.documentElement.classList.contains('ui-layout-compact'),
                grid: grid?{x:grid.x,y:grid.y,w:grid.width,h:grid.height,right:grid.right}:null,
                cards,
                rows:{
                  compactAligned:same('prompt','backend','y')&&same('backend','about','y')&&same('prompt','backend','h')&&same('backend','about','h'),
                  runtimeHealthAligned:same('runtime','health','y')&&same('runtime','health','h'),
                  interfaceProfileAligned:same('interface','profile','y')&&same('interface','profile','h'),
                  shortcutsDiagnosticsAligned:same('shortcuts','diagnostics','y')&&same('shortcuts','diagnostics','h')
                },
                noGridOverflow: !!grid && Object.values(cards).every(r=>r.right<=grid.right+1.5&&r.x>=grid.x-1.5),
                noViewportHorizontalOverflow: !!viewport && viewport.scrollWidth<=viewport.clientWidth+1,
                settingsMaxWidth:getComputedStyle(document.querySelector('#view-settings')).maxWidth,
                cacheCss:[...document.styleSheets].some(s=>String(s.href||'').includes('p35'))
              };
              applyUiScale(160,{persist:false,announce:false});
              const scale160Grid=document.querySelector('.settings-grid')?.getBoundingClientRect();
              const rect160=(selector)=>{
                const el=document.querySelector(selector); if(!el)return null;
                const r=el.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height,right:r.right,bottom:r.bottom};
              };
              const p160=rect160('.prompt-settings-card'), b160=rect160('.backend-settings-card'), a160=rect160('.about-card');
              const r160=rect160('.runtime-settings-card'), h160=rect160('.health-card');
              window.__p33SettingsProbe.scale160={
                uiScale:state.uiScale,
                logicalLayoutNarrow:document.documentElement.classList.contains('ui-layout-narrow'),
                logicalLayoutCompact:document.documentElement.classList.contains('ui-layout-compact'),
                grid:scale160Grid?{x:scale160Grid.x,w:scale160Grid.width,right:scale160Grid.right}:null,
                promptBackendSameRow:!!p160&&!!b160&&Math.abs(p160.y-b160.y)<=1.5,
                aboutNextFullRow:!!a160&&!!scale160Grid&&Math.abs(a160.w-scale160Grid.width)<=2,
                runtimeFullRow:!!r160&&!!scale160Grid&&Math.abs(r160.w-scale160Grid.width)<=2,
                healthFullRow:!!h160&&!!scale160Grid&&Math.abs(h160.w-scale160Grid.width)<=2,
                noOverflow:!!scale160Grid&&[p160,b160,a160,r160,h160].filter(Boolean).every(r=>r.x>=scale160Grid.x-1.5&&r.right<=scale160Grid.right+1.5)
              };
              applyUiScale(120,{persist:false,announce:false});
            }
            document.querySelector('#queueModal')?.classList.remove('hidden');
          }
          true;
        """)
        window.evaluate_js("""
          window.__p38InspectProbe = {started:true,done:false};
          if (typeof state !== 'undefined' && typeof showResult === 'function' &&
              typeof inspectCurrentResult === 'function' && typeof prepareQualityRegionRepair === 'function') {
            state.queueSnapshot={running:[],pending:[],active_count:0,max_pending:20};
            state.jobId='';
            const qa='C:/AI/LocalGen/ComfyUI/output/LocalGen/adult_00035_.png';
            showResult(qa,'file:///C:/AI/LocalGen/ComfyUI/output/LocalGen/adult_00035_.png','',null);
            (async()=>{
              try{
                const buttonVisible=!document.querySelector('#inspectDetailsResult')?.classList.contains('hidden');
                await inspectCurrentResult();
                const regions=[...(state.qualityRegions||[])];
                const face=regions.find(x=>x.kind==='face')||regions[0]||null;
                if(face)selectQualityRegion(face.id);
                const overlayCount=document.querySelectorAll('.quality-region-box').length;
                const listCount=document.querySelectorAll('.quality-region-item').length;
                const selectedBefore=state.qualityRegionSelected;
                if(face)await prepareQualityRegionRepair();
                window.__p38InspectProbe={
                  started:true,done:true,buttonVisible,
                  regions:regions.map(x=>({id:x.id,kind:x.kind,label:x.label,points:x.points,bbox:x.bbox})),
                  overlayCount,listCount,selectedBefore,
                  editMode:state.editMode,
                  editSource:state.editSource,
                  editMask:state.editMask,
                  maskStatus:document.querySelector('#maskStatus')?.textContent||'',
                  editPrompt:document.querySelector('#editPrompt')?.value||'',
                  promptMode:document.querySelector('#editPromptMode')?.value||'',
                  editViewActive:document.querySelector('#view-edit')?.classList.contains('active')||false,
                  maskControlsVisible:!document.querySelector('#maskControls')?.classList.contains('hidden'),
                  referenceCardHidden:document.querySelector('#referenceCard')?.classList.contains('hidden')||false,
                  repairButtonPresent:!!document.querySelector('#qualityInspectRepair'),
                  cache:[...document.styleSheets].some(s=>String(s.href||'').includes('p38inspect1'))
                };
              }catch(e){
                window.__p38InspectProbe={started:true,done:true,error:String(e),stack:String(e?.stack||'')};
              }
            })();
          } else {
            window.__p38InspectProbe={started:true,done:true,error:'P38 functions/state missing'};
          }
          true;
        """)
        for _ in range(150):
            try:
                p38_done = window.evaluate_js("Boolean(window.__p38InspectProbe && window.__p38InspectProbe.done)")
                if p38_done:
                    break
            except Exception:
                pass
            time.sleep(0.5)
        window.evaluate_js("""
          window.__p40ResolutionProbe = null;
          if (typeof currentResolutionPlan === 'function' && typeof renderResolutionPlanner === 'function') {
            try {
              if (typeof switchView === 'function') switchView('create');
              const originalPrefs = localStorage.getItem(PREF_KEY);
              const original = {
                model: state.createModel, aspect: state.aspect,
                width: state.createWidth, height: state.createHeight,
                delivery: state.deliveryPreset
              };
              const setFhd=(modelId)=>{
                state.createModel=modelId; state.aspect='fhd_native';
                state.createWidth=1920; state.createHeight=1080;
                document.querySelector('#createWidth').value='1920';
                document.querySelector('#createHeight').value='1080';
                renderModels(); renderAspects(); renderDeliveryPresets(); renderResolutionPlanner();
                const p=currentResolutionPlan();
                return {
                  model:modelId,
                  current:[+document.querySelector('#createWidth').value,+document.querySelector('#createHeight').value],
                  recommended:p?[+p.recommended.width,+p.recommended.height]:null,
                  reference:p?.reference?[+p.reference.width,+p.reference.height]:null,
                  title:document.querySelector('#resolutionPlannerTitle')?.textContent||'',
                  text:document.querySelector('#resolutionPlannerText')?.textContent||'',
                  meta:document.querySelector('#resolutionPlannerMeta')?.textContent||'',
                  apply:document.querySelector('#applyResolutionPlan')?.textContent||'',
                  applyDisabled:!!document.querySelector('#applyResolutionPlan')?.disabled,
                  visible:!document.querySelector('#resolutionPlanner')?.classList.contains('hidden')
                };
              };
              const animagine=setFhd('animagine_anime');
              const qwen=setFhd('qwen21_design');
              const qwenBefore=[+document.querySelector('#createWidth').value,+document.querySelector('#createHeight').value];
              document.querySelector('#applyResolutionPlan')?.click();
              const qwenAfter=[+document.querySelector('#createWidth').value,+document.querySelector('#createHeight').value];
              const chroma=setFhd('chroma1_hd');
              window.__p40ResolutionProbe={
                animagine,qwen,chroma,qwenBefore,qwenAfter,
                fhdPreservedBeforeClick:qwenBefore[0]===1920&&qwenBefore[1]===1080,
                qwenApplied:qwenAfter[0]===1280&&qwenAfter[1]===720,
                cache:[...document.styleSheets].some(s=>String(s.href||'').includes('p40res1')),
                bridgePresent:!!window.pywebview?.api?.plan_create_resolution
              };
              state.createModel=original.model; state.aspect=original.aspect;
              state.createWidth=original.width; state.createHeight=original.height;
              state.deliveryPreset=original.delivery;
              document.querySelector('#createWidth').value=original.width||1024;
              document.querySelector('#createHeight').value=original.height||1024;
              if(originalPrefs===null)localStorage.removeItem(PREF_KEY);else localStorage.setItem(PREF_KEY,originalPrefs);
            } catch(e) {
              window.__p40ResolutionProbe={error:String(e),stack:String(e?.stack||'')};
            }
          }
          true;
        """)
        raw = window.evaluate_js("""
          JSON.stringify({
            readyState: document.readyState,
            hasPy: !!window.pywebview,
            hasApi: !!(window.pywebview && window.pywebview.api),
            initialized: (typeof appInitialized !== 'undefined') ? appInitialized : null,
            errors: window.__localgenErrors || [],
            probe: window.__localgenProbeReady,
            queueProbe: window.__localgenProbeQueue,
            modelCards: document.querySelectorAll('#createModels .model-card').length,
            pill: document.querySelector('#backendPill span')?.textContent || '',
            queuePill: !!document.querySelector('#queuePill'),
            queueCount: document.querySelector('#queueCount')?.textContent || '',
            queueModalHidden: document.querySelector('#queueModal')?.classList.contains('hidden') ?? null,
            queueItems: document.querySelectorAll('.queue-item').length,
            queueCancelButtons: document.querySelectorAll('[data-queue-cancel]').length,
            queueClearDisabled: document.querySelector('#queueClearPending')?.disabled ?? null,
            runtimeProbe: window.__p31RuntimeProbe,
            animateProbe: window.__p32AnimateProbe,
            settingsProbe: window.__p33SettingsProbe,
            renderQualityProbe: window.__p35RenderProbe,
            cleanStartProbe: window.__p35CleanStartProbe,
            zImageProbe: window.__p36ZImageProbe,
            structureProbe: window.__p36StructureProbe,
            repairProbe: window.__p37RepairProbe,
            qualityInspectProbe: window.__p38InspectProbe,
            resolutionPlannerProbe: window.__p40ResolutionProbe,
            runtimeCurrentProfile: (typeof state !== 'undefined' && state.runtimeSettings) ? state.runtimeSettings.performance_profile : '',
            runtimeCurrentOutput: (typeof state !== 'undefined' && state.runtimeSettings) ? state.runtimeSettings.output_directory : ''
          })
        """)
        target = RUNTIME_APP / "data" / "bridge-probe.json"
        target.write_text(str(raw), encoding="utf-8")
    except Exception:
        (RUNTIME_APP / "data" / "bridge-probe-error.log").write_text(traceback.format_exc(), encoding="utf-8")

UI_SESSION_FILE = RUNTIME_APP / "data" / "ui-session.json"
IDLE_GUARD = ROOT / "Tools" / "localgen_idle_guard.py"


def _write_ui_session(token: str) -> None:
    UI_SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "token": str(token),
        "pid": os.getpid(),
        "started_at": datetime.now().isoformat(timespec="seconds"),
    }
    temp = UI_SESSION_FILE.with_name(f".{UI_SESSION_FILE.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, UI_SESSION_FILE)
    finally:
        temp.unlink(missing_ok=True)


def _clear_ui_session(token: str) -> None:
    try:
        current = json.loads(UI_SESSION_FILE.read_text(encoding="utf-8"))
        if isinstance(current, dict) and str(current.get("token") or "") == str(token):
            UI_SESSION_FILE.unlink(missing_ok=True)
    except FileNotFoundError:
        pass
    except Exception:
        # Fail safe: leave an ambiguous marker in place so an exit guard will
        # treat a later UI session as active rather than stopping the backend.
        pass


def _launch_exit_guard(token: str) -> dict[str, Any]:
    settings = runtime_settings()
    vram_policy = str(settings.get("vram_policy") or "keep")
    backend_policy = str(settings.get("backend_policy") or "keep")
    if vram_policy == "keep" and backend_policy == "keep":
        return {"started": False, "reason": "keep_policies"}
    guard_override = str(os.environ.get("LOCALGEN_IDLE_GUARD") or "").strip()
    guard = Path(guard_override) if guard_override else IDLE_GUARD
    if not guard.is_file():
        return {"started": False, "reason": "guard_missing", "path": str(guard)}
    pythonw = RUNTIME_APP / ".venv" / "Scripts" / "pythonw.exe"
    executable = pythonw if pythonw.is_file() else Path(sys.executable)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(
        [str(executable), str(guard), "--exit-token", str(token)],
        cwd=str(ROOT),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=flags,
        close_fds=True,
    )
    return {"started": True, "pid": proc.pid, "path": str(guard)}


def main() -> None:
    api = API()
    index = (FRONTEND / "index.html").resolve()
    window = webview.create_window(
        "LocalGen",
        url=index.as_uri(),
        js_api=api,
        width=1440,
        height=860,
        min_size=(980, 650),
        frameless=True,
        easy_drag=False,
        shadow=True,
        background_color="#070910",
        text_select=True,
        zoomable=False,
    )
    api._window = window
    if os.environ.get("LOCALGEN_DEBUG"):
        def _probe_frontend():
            try:
                import time
                time.sleep(2.0)
                payload = window.evaluate_js("""JSON.stringify({
                  ready:document.readyState,
                  hasPy:!!window.pywebview?.api,
                  hasInit:typeof init==='function',
                  initialized:typeof appInitialized!=='undefined'?appInitialized:null,
                  modelCards:document.querySelectorAll('#createModels .model-card').length,
                  backendText:document.querySelector('#backendPill span')?.textContent||'',
                  innerWidth:window.innerWidth,
                  docClient:document.documentElement.clientWidth,
                  docScroll:document.documentElement.scrollWidth,
                  viewport:document.querySelector('.viewport')?.getBoundingClientRect(),
                  view:document.querySelector('.view.active')?.getBoundingClientRect(),
                  grid:document.querySelector('.studio-grid')?.getBoundingClientRect(),
                  config:document.querySelector('.config-column')?.getBoundingClientRect(),
                  preview:document.querySelector('.preview-column')?.getBoundingClientRect(),
                  backendPill:document.querySelector('#backendPill')?.getBoundingClientRect(),
                  helpBtn:document.querySelector('#helpBtn')?.getBoundingClientRect(),
                  windowActions:document.querySelector('.window-actions')?.getBoundingClientRect(),
                  errors:window.__localgenErrors||[]
                })""")
                print("[LocalGen JS probe]", payload, flush=True)
            except Exception as exc:
                print("[LocalGen JS probe error]", repr(exc), flush=True)
        window.events.loaded += lambda: threading.Thread(target=_probe_frontend, daemon=True).start()
    probe = _frontend_probe if os.environ.get("LOCALGEN_PROBE") else None
    session_token = uuid.uuid4().hex
    try:
        clean_stale_temp_files()
        clean_stale_orphan_reference_cache()
    except Exception:
        pass
    _write_ui_session(session_token)
    start_lifecycle_controller()
    try:
        webview.start(
            probe,
            args=(window,) if probe else None,
            gui="edgechromium",
            debug=bool(os.environ.get("LOCALGEN_DEBUG")),
            private_mode=False,
            storage_path=str(RUNTIME_APP / "data" / "webview-profile"),
        )
    finally:
        active_at_exit = bool(JOBS.active_jobs())
        stop_lifecycle_controller()
        if not active_at_exit:
            try:
                clean_temp_files()
                clean_orphan_reference_cache()
            except Exception:
                pass
        _clear_ui_session(session_token)
        if not active_at_exit and not api._update_apply_started:
            try:
                _launch_exit_guard(session_token)
            except Exception:
                pass

if __name__ == "__main__":
    try:
        main()
    except Exception:
        data = RUNTIME_APP / "data"
        data.mkdir(parents=True, exist_ok=True)
        crash = data / "startup-crash.log"
        details = traceback.format_exc()
        crash.write_text(details, encoding="utf-8")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0,
                "LocalGen не удалось запустить.\n\nПодробности сохранены в:\n" + str(crash),
                "LocalGen",
                0x10,
            )
        except Exception:
            pass


from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import secrets
import shutil
import socket
import struct
import subprocess
import threading
import time
import traceback
import uuid
from collections import deque
from pathlib import Path
from typing import Any

import requests
from PIL import Image, ImageGrab

import localgen_exact_text as exact_text
import localgen_lifecycle as lifecycle_policy

ROOT = Path(r"C:\AI\LocalGen")
APP = ROOT / "App"
os.environ.setdefault("ARGOS_PACKAGES_DIR", str(APP / "data" / "argos-packages"))
os.environ.setdefault("ARGOS_CHUNK_TYPE", "MINISBD")
os.environ.setdefault("ARGOS_DEVICE_TYPE", "cpu")
os.environ.setdefault("ARGOS_COMPUTE_TYPE", "int8_float32")
TOOLS = ROOT / "Tools"
DEFAULT_OUTPUT = ROOT / "ComfyUI" / "output"
COMFY_PY = ROOT / "ComfyUI" / ".venv" / "Scripts" / "python.exe"
COMFY_URL = "http://127.0.0.1:8188"
HYBRID_EXACT_TEXT_WRAPPER = TOOLS / "hybrid_exact_text_postprocess.py"
ZEN_EDIT_ROOT = ROOT / "Models" / "zen_image_edit"
ZEN_EDIT_STUDENT = ZEN_EDIT_ROOT / "Qwen3.5-0.8B"
ZEN_EDIT_ADAPTER = ZEN_EDIT_ROOT / "adapter_v12.safetensors"
ZEN_EDIT_NODE = ROOT / "ComfyUI" / "custom_nodes" / "localgen_zen_conditioning" / "__init__.py"
APP_VERSION = "0.3.46"

DWPOSE_BBOX_MODEL = ROOT / "ComfyUI" / "custom_nodes" / "comfyui_controlnet_aux" / "ckpts" / "yzd-v" / "DWPose" / "yolox_l.onnx"
DWPOSE_POSE_MODEL = ROOT / "ComfyUI" / "custom_nodes" / "comfyui_controlnet_aux" / "ckpts" / "yzd-v" / "DWPose" / "dw-ll_ucoco_384.onnx"
DEPTH_ANYTHING_V2_ONNX = ROOT / "Models" / "preprocessors" / "depth_anything_v2_small_onnx" / "model_q4f16.onnx"
DWPOSE_BBOX_BYTES = 216_746_733
DWPOSE_POSE_BYTES = 134_399_116
DEPTH_ANYTHING_V2_BYTES = 19_126_267


APP_SETTINGS_FILE = APP / "data" / "app-settings.json"
BACKEND_START_FILE = APP / "data" / "backend-start.json"
_RUNTIME_SETTINGS_LOCK = threading.RLock()
_PERFORMANCE_PROFILES = {"auto", "balanced", "lowram"}

def _canonical_directory(value: Any, fallback: Path = DEFAULT_OUTPUT) -> Path:
    raw = str(value or "").strip()
    if not raw:
        return fallback.resolve()
    expanded = os.path.expandvars(os.path.expanduser(raw))
    path = Path(expanded)
    if not path.is_absolute():
        path = ROOT / path
    return path.resolve()

def _runtime_settings_unlocked() -> dict[str, Any]:
    raw: dict[str, Any] = {}
    if APP_SETTINGS_FILE.exists():
        try:
            loaded = json.loads(APP_SETTINGS_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                raw = loaded
        except Exception:
            raw = {}
    try:
        output = _canonical_directory(raw.get("output_directory"))
    except Exception:
        output = DEFAULT_OUTPUT.resolve()
    profile = str(raw.get("performance_profile") or "auto").strip().lower()
    if profile not in _PERFORMANCE_PROFILES:
        profile = "auto"
    known: list[str] = []
    for value in raw.get("known_output_directories") or []:
        try:
            item = str(_canonical_directory(value))
        except Exception:
            continue
        if item.lower() not in {x.lower() for x in known}:
            known.append(item)
    for item in (str(DEFAULT_OUTPUT.resolve()), str(output)):
        if item.lower() not in {x.lower() for x in known}:
            known.append(item)
    lifecycle = lifecycle_policy.normalize_policy_settings(raw)
    return {
        "version": 2,
        "output_directory": str(output),
        "performance_profile": profile,
        "known_output_directories": known,
        **lifecycle,
    }

def _write_runtime_settings_unlocked(settings: dict[str, Any]) -> None:
    APP_SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    temp = APP_SETTINGS_FILE.with_name(f".{APP_SETTINGS_FILE.name}.{uuid.uuid4().hex}.tmp")
    payload = json.dumps(settings, ensure_ascii=False, indent=2)
    try:
        temp.write_text(payload, encoding="utf-8")
        os.replace(temp, APP_SETTINGS_FILE)
    finally:
        temp.unlink(missing_ok=True)

def _validate_output_directory(value: Any) -> tuple[Path, int]:
    path = _canonical_directory(value)
    path.mkdir(parents=True, exist_ok=True)
    if not path.is_dir():
        raise ValueError(f"Путь результатов не является папкой: {path}")
    probe = path / f".localgen-write-{uuid.uuid4().hex}.tmp"
    try:
        probe.write_bytes(b"LocalGen")
    except Exception as exc:
        raise ValueError(f"Нет доступа на запись в папку результатов: {path}") from exc
    finally:
        probe.unlink(missing_ok=True)
    return path, shutil.disk_usage(path).free

def runtime_settings() -> dict[str, Any]:
    with _RUNTIME_SETTINGS_LOCK:
        settings = _runtime_settings_unlocked()
    output = Path(settings["output_directory"])
    try:
        free = shutil.disk_usage(output).free if output.exists() else 0
    except Exception:
        free = 0
    backend_start: dict[str, Any] = {}
    if BACKEND_START_FILE.exists():
        try:
            loaded = json.loads(BACKEND_START_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                backend_start = loaded
        except Exception:
            pass
    return {
        **settings,
        "default_output_directory": str(DEFAULT_OUTPUT.resolve()),
        "output_exists": output.is_dir(),
        "output_free_bytes": free,
        "effective_performance_profile": str(backend_start.get("effective_profile") or ""),
        "backend_output_directory": str(backend_start.get("output_directory") or ""),
    }

def current_output_root() -> Path:
    with _RUNTIME_SETTINGS_LOCK:
        return Path(_runtime_settings_unlocked()["output_directory"])

def _effective_performance_profile() -> str:
    if BACKEND_START_FILE.is_file():
        try:
            raw = json.loads(BACKEND_START_FILE.read_text(encoding="utf-8"))
            profile = str(raw.get("effective_profile") or "").strip().lower()
            if profile in {"balanced", "lowram"}:
                return profile
        except Exception:
            pass
    with _RUNTIME_SETTINGS_LOCK:
        selected = str(_runtime_settings_unlocked().get("performance_profile") or "auto")
    return selected if selected in {"balanced", "lowram"} else ""

def _zen_edit_assets_ready() -> bool:
    required = (
        ZEN_EDIT_NODE,
        ZEN_EDIT_ADAPTER,
        ZEN_EDIT_STUDENT / "config.json",
        ZEN_EDIT_STUDENT / "model.safetensors-00001-of-00001.safetensors",
        ZEN_EDIT_STUDENT / "model.safetensors.index.json",
        ZEN_EDIT_STUDENT / "preprocessor_config.json",
        ZEN_EDIT_STUDENT / "tokenizer.json",
        ZEN_EDIT_STUDENT / "tokenizer_config.json",
        ZEN_EDIT_STUDENT / "merges.txt",
        ZEN_EDIT_STUDENT / "vocab.json",
    )
    return all(path.is_file() for path in required)

_SMART_EDIT_TEXT_SENSITIVE_RE = re.compile(
    r"\b(?:text|lettering|word|words|number|numbers|digit|digits|sign|signage|label|logo|poster|banner|caption|headline|title)\b"
    r"|(?:\u0442\u0435\u043a\u0441\u0442\w*|\u043d\u0430\u0434\u043f\u0438\u0441\w*|\u0431\u0443\u043a\u0432\w*|\u0441\u043b\u043e\u0432\w*|\u0446\u0438\u0444\u0440\w*|\u0432\u044b\u0432\u0435\u0441\w*|\u044d\u0442\u0438\u043a\u0435\u0442\w*|\u043b\u043e\u0433\u043e\u0442\u0438\u043f\w*|\u043f\u043b\u0430\u043a\u0430\u0442\w*|\u0431\u0430\u043d\u043d\u0435\u0440\w*|\u0437\u0430\u0433\u043e\u043b\u043e\u0432\w*)",
    re.I,
)

def _use_zen_smart_edit(payload: dict[str, Any], refs: list[Path]) -> bool:
    if _effective_performance_profile() != "lowram":
        return False
    if str(payload.get("edit_mode") or "").strip().lower() != "smart":
        return False
    # Multi-reference and Adult routes remain on the native 8B encoder until
    # separately qualified. The source image itself is supported by Zen.
    if refs:
        return False
    actual_prompt = str(payload.get("prompt") or "").strip()
    if not actual_prompt or detect_language(actual_prompt) != "en":
        return False
    source = "\n".join([
        str(payload.get("source_prompt") or ""),
        actual_prompt,
    ])
    if exact_text.quoted_fragments(source) or _SMART_EDIT_TEXT_SENSITIVE_RE.search(source):
        return False
    return _zen_edit_assets_ready()

def known_output_roots() -> list[Path]:
    with _RUNTIME_SETTINGS_LOCK:
        values = list(_runtime_settings_unlocked()["known_output_directories"])
    out: list[Path] = []
    for value in values:
        try:
            path = Path(value)
            if path.is_dir() and str(path).lower() not in {str(x).lower() for x in out}:
                out.append(path)
        except Exception:
            pass
    return out

CREATE_NATIVE_MAX_SIDE = 2048
CREATE_NATIVE_MAX_PIXELS = 2_200_000

MODEL_REGISTRY: dict[str, dict[str, Any]] = {
    "krea2_general": {
        "name": "Krea 2 Turbo",
        "kind": "create",
        "family": "krea2",
        "category": "universal",
        "category_label": "Универсально",
        "quality_tier": "best",
        "profile": "general",
        "steps": 8,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "simple",
        "max_native_side": 2048,
        "max_native_pixels": 2200000,
        "max_quality": True,
        "max_steps": 10,
        "max_quality_note": "Нативный Krea Turbo quality mode: 10 шагов вместо 8, без повторного denoise. Для максимальной детализации можно рендерить сразу до 1920×1080 / ~2 Мп.",
        "recommended": False,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Универсальные сцены, сложные описания и современный визуал",
        "estimate": "≈ 20–50 с",
        "strengths": "Универсальный генератор для сцен, объектов и смешанных задач.",
        "limitations": "Для людей, anime и 18+ теперь есть отдельные специализированные модели с более точным профилем.",
        "installed": ROOT / "Models" / "diffusion_models" / "krea2_turbo_nvfp4.safetensors",
    },
    "krea2_adult": {
        "name": "Mystic XXX v3 · 18+",
        "kind": "create",
        "family": "krea2",
        "category": "adult_photo",
        "category_label": "18+ фото",
        "quality_tier": "best",
        "adult": True,
        "profile": "adult",
        "steps": 8,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "beta",
        "lora_strength": 1.0,
        "max_native_side": 2048,
        "max_native_pixels": 2200000,
        "max_quality": True,
        "max_steps": 9,
        "max_expert": {"steps": 9, "lora_strength": 0.85},
        "max_quality_note": "Проверенный финальный профиль: 9 шагов, Beta, Mystic LoRA 0.85. Он сохраняет детализацию, но уменьшает пережаренную микротекстуру кожи по сравнению с 10 шагами / LoRA 1.0.",
        "recommended": True,
        "enabled": True,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "18+ фото, ню и анатомия взрослых людей",
        "estimate": "≈ 30–70 с",
        "strengths": "Krea 2 Turbo + специализированный Mystic XXX v3 LoRA для взрослого фотореала и сложных 18+ сцен.",
        "limitations": "Специализирован под 18+ фотореал. Для обычных сцен без эротики используй Krea 2 Turbo.",
        "installed": ROOT / "Models" / "loras" / "MysticXXX_KREA2_v3.safetensors",
    },
    "zimage_turbo_q5": {
        "name": "Z-Image Turbo Q5 · Editorial",
        "kind": "create",
        "family": "zimage",
        "category": "photo_quality",
        "category_label": "Фото / Editorial",
        "quality_tier": "specialist",
        "workflow": "zimage_t2i",
        "steps": 8,
        "cfg": 1.0,
        "sampler": "res_multistep",
        "scheduler": "simple",
        "shift": 3.0,
        "max_native_side": 2048,
        "max_native_pixels": 2200000,
        "max_quality": True,
        "max_steps": 8,
        "max_quality_note": "Z-Image Turbo рассчитан на 8 шагов: Maximum не пересэмплирует модель сверх проверенного Turbo-рецепта. Для финального разрешения используй native Full HD или Delivery upscale.",
        "recommended": True,
        "speed": "Средняя",
        "memory": "Очень высокая",
        "best_for": "Editorial, fashion, environmental portrait, сложный фотореал и выразительный свет",
        "estimate": "≈ 35–90 с @ 512–768px",
        "strengths": "Сильная фотореалистичная подача, натуральная микротекстура кожи, богатый свет и связное окружение. Controlled tests дали более выразительный editorial/full-body результат, чем Krea.",
        "limitations": "На 8 ГБ работает через GGUF и близко к лимиту памяти. Для обычных портретов Juggernaut остаётся более специализированным, для точной предметной геометрии — Krea.",
        "model_file": "z-image-turbo-Q5_K_M.gguf",
        "text_encoder": "qwen_3_4b.safetensors",
        "vae": "ae.safetensors",
        "structure_control_model": "Z-Image-Turbo-Fun-Controlnet-Union-2.1-lite-2602-8steps.safetensors",
        "structure_control_expected_bytes": 2016627488,
        "structure_control_kind": "canny",
        "expected_bytes": 5574444096,
        "installed": ROOT / "Models" / "diffusion_models" / "z-image-turbo-Q5_K_M.gguf",
    },
    "chroma1_hd": {
        "name": "Chroma1-HD · Creative",
        "kind": "create",
        "family": "chroma",
        "category": "creative",
        "category_label": "Creative / Editorial",
        "quality_tier": "specialist",
        "workflow": "chroma_t2i",
        "steps": 12,
        "cfg": 3.8,
        "sampler": "euler",
        "shift": 1.0,
        "beta_alpha": 0.45,
        "beta_beta": 0.45,
        "negative": "low quality, blurry, deformed, disfigured, warped geometry, duplicate subjects, bad hands, watermark, unwanted text, oversharpened skin, plastic skin",
        "max_native_side": 2048,
        "max_native_pixels": 2200000,
        "max_quality": True,
        "max_steps": 26,
        "max_quality_note": "Финальный официальный-style профиль Chroma: 26 Beta-шагов, CFG 3.8, Euler, Flow shift 1.0. Очень медленно на 8 ГБ, но даёт сильный арт-дирекшн и архитектурную композицию.",
        "recommended": False,
        "speed": "Очень медленно",
        "memory": "Очень высокая",
        "best_for": "Архитектура, интерьер, editorial, концепт-сцены и арт-дирекшн",
        "estimate": "≈ 70–220 с @ 512px",
        "strengths": "Сильная композиция пространства, свет, материалы и редакционный визуальный язык.",
        "limitations": "Не использовать как дефолт для точной предметной геометрии: controlled tests показали хуже Krea на сложном продукте. На RTX 3070 работает почти у потолка VRAM.",
        "model_file": "Chroma1-HD-Q5_K_M.gguf",
        "text_encoder": "t5xxl_fp8_e4m3fn.safetensors",
        "vae": "ae.safetensors",
        "expected_bytes": 6286069920,
        "installed": ROOT / "Models" / "diffusion_models" / "Chroma1-HD-Q5_K_M.gguf",
    },
    "anima_portrait": {
        "name": "Anima Turbo v1.1 · Anime Portrait",
        "kind": "create",
        "family": "anima",
        "category": "anime",
        "category_label": "Anime / Portrait",
        "quality_tier": "specialist",
        "workflow": "anima_t2i",
        "steps": 10,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "simple",
        "negative": "worst quality, low quality, score_1, score_2, score_3, artist name, blurry, jpeg artifacts, chromatic aberration",
        "max_native_side": 2048,
        "max_native_pixels": 2200000,
        "max_quality": True,
        "max_steps": 10,
        "max_quality_note": "Anima Turbo рассчитан на 10 шагов. Maximum не пересэмплирует Turbo сверх проверенного профиля; для финального размера используй native Full HD или Delivery upscale.",
        "recommended": True,
        "speed": "Быстро",
        "memory": "Высокая",
        "best_for": "Детализированный anime-портрет, upper-body, ornate illustration и сложный фон",
        "estimate": "≈ 12–30 с @ 832×1216",
        "strengths": "Controlled portrait test дал более сложную одежду, цельный фон, структурное лицо и читаемые руки при ~2.3× меньшем времени, чем Animagine.",
        "limitations": "Не использовать как auto-default для full-body и запросов со строгими атрибутами: controlled full-body test потерял цвет волос/глаз и изменил позу. Для них остаётся Animagine XL 4.0.",
        "model_file": "anima-turbo-v1.1.safetensors",
        "text_encoder": "qwen_3_06b_base.safetensors",
        "vae": "qwen_image_vae.safetensors",
        "expected_bytes": 4182230656,
        "installed": ROOT / "Models" / "diffusion_models" / "anima-turbo-v1.1.safetensors",
    },
    "sdxl_people": {
        "name": "Juggernaut XL v9 · Фото",
        "kind": "create",
        "family": "sdxl",
        "category": "photo",
        "category_label": "Фотореал",
        "quality_tier": "best",
        "workflow": "sdxl",
        "max_quality": True,
        "max_steps": 40,
        "hires_scale": 1.0,
        "hires_steps": 15,
        "hires_denoise": 0.30,
        "max_quality_note": "Финальный профиль: 40 шагов, CFG 4, DPM++ 2M Karras. CFG 4 подтверждён локальными A/B. По умолчанию без общего negative; LocalGen добавляет только точечные anti-collage/anti-clone/framing ограничения, когда они реально нужны. Автоматический latent-refine отключён.",
        "recommended": True,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Люди, лица, кожа, fashion и реалистичные фото",
        "estimate": "≈ 25–55 с",
        "strengths": "Специализированный SDXL-фотореал: естественные лица, кожа, свет и полный рост.",
        "limitations": "Медленнее черновых моделей. Для аниме и 18+ лучше выбрать профиль своей ниши.",
        "checkpoint": "Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors",
        "steps": 35,
        "cfg": 4.0,
        "sampler": "dpmpp_2m",
        "scheduler": "karras",
        "negative": "",
        "expected_bytes": 7105348188,
        "sha256": "C9E3E68F89B8E38689E1097D4BE4573CF308DE4E3FD044C64CA697BDB4AA8BCA",
        "installed": ROOT / "Models" / "checkpoints" / "Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors",
    },
    "animagine_anime": {
        "name": "Animagine XL 4.0 Opt · Anime",
        "kind": "create",
        "family": "animagine",
        "category": "anime",
        "category_label": "Anime / Art",
        "quality_tier": "best",
        "workflow": "sdxl",
        "max_quality": True,
        "max_steps": 28,
        "hires_scale": 1.0,
        "hires_steps": 10,
        "hires_denoise": 0.22,
        "max_quality_note": "28 шагов в штатном Animagine workflow. Автоматический latent-refine отключён, чтобы не перерисовывать линии и лицо.",
        "recommended": True,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Anime, персонажи, иллюстрации и стилизованный арт",
        "estimate": "≈ 25–50 с",
        "strengths": "Специализированный anime SDXL checkpoint с сильными персонажами, позами и чистой стилизацией.",
        "limitations": "Не предназначен для фотореализма. Лучше работает с конкретным описанием персонажа, позы и сцены.",
        "checkpoint": "Animagine-XL-4.0-Opt.safetensors",
        "steps": 28,
        "cfg": 5.0,
        "sampler": "euler_ancestral",
        "scheduler": "normal",
        "negative": "lowres, bad anatomy, bad hands, text, error, missing finger, extra digits, fewer digits, cropped, worst quality, low quality, low score, bad score, average score, signature, watermark, username, blurry",
        "expected_bytes": 6938350040,
        "sha256": "6327ECA98BFB6538DD7A4EDCE22484A1BBC57A8CFF6B11D075D40DA1AFB847AC",
        "installed": ROOT / "Models" / "checkpoints" / "Animagine-XL-4.0-Opt.safetensors",
    },
    "noobai_adult_anime": {
        "name": "NoobAI XL V-Pred 1.0 · 18+ Anime",
        "kind": "create",
        "family": "noobai",
        "category": "adult_anime",
        "category_label": "18+ Anime",
        "quality_tier": "best",
        "workflow": "sdxl",
        "max_quality": True,
        "max_steps": 35,
        "hires_scale": 1.0,
        "hires_steps": 10,
        "hires_denoise": 0.22,
        "max_quality_note": "35 шагов / CFG 4 / Euler. CFG 4 подтверждён локальными A/B как менее пережаренный и более чистый для линий/лица при сохранении деталей. Автоматический latent-refine отключён.",
        "adult": True,
        "recommended": True,
        "optional": False,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "18+ anime, pin-up, стилизованные взрослые персонажи и сложные позы",
        "estimate": "≈ 25–55 с",
        "strengths": "NoobAI V-Pred 1.0 обучен на крупном anime/e621-корпусе и использует отдельный V-Pred + ZSNR workflow для более сильного anime/18+ профиля.",
        "limitations": "Только anime/art, не фотореал. Лицензия NoobAI/Fair AI содержит ограничения на коммерческое использование; для коммерческих задач проверь условия модели.",
        "checkpoint": "NoobAI-XL-Vpred-v1.0.safetensors",
        "steps": 30,
        "cfg": 4.0,
        "sampler": "euler",
        "scheduler": "normal",
        "clip_skip": 2,
        "prediction": "v_prediction",
        "zsnr": True,
        "negative": "lowres, worst quality, low quality, bad anatomy, bad hands, 4koma, comic, greyscale, censored, jpeg artifacts, overly saturated, overly vivid, signature, username, logo, text, watermark",
        "expected_bytes": 7105350110,
        "sha256": "EA349EEAE87CA8D25BA902C93810F7CA83E5C82F920EDF12F273AF004AE02819",
        "source": "ModelScope ModelE/noobai-XL-Vpred-1.0",
        "installed": ROOT / "Models" / "checkpoints" / "NoobAI-XL-Vpred-v1.0.safetensors",
    },
    "qwen21_design": {
        "name": "Qwen-Image-2.1 · Текст / Дизайн",
        "kind": "create",
        "family": "qwen",
        "category": "design",
        "category_label": "Текст / Дизайн",
        "quality_tier": "best",
        "workflow": "qwen_t2i",
        "max_quality": True,
        "steps": 28,
        "max_steps": 40,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "simple",
        "max_quality_note": "40 шагов Qwen-Image-2.1 для финальной типографики и сложной дизайнерской композиции. Медленнее обычного режима.",
        "recommended": True,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Постеры, баннеры, надписи, русская типографика, интерфейсные и рекламные композиции",
        "estimate": "≈ 35–80 с",
        "strengths": "Qwen-Image-2.1 хорошо работает с типографикой, компоновкой, графическим дизайном, прозрачностью и сложными визуальными инструкциями.",
        "limitations": "Не заменяет векторный редактор: длинный мелкий текст и точная верстка могут потребовать нескольких вариантов. Для чистого фотореала лучше Juggernaut.",
        "installed": ROOT / "Models" / "diffusion_models" / "qwen_image_2.1_int8_convrot.safetensors",
        "structure_control_model": "Qwen-Image-2.1-Fun-Controlnet-Union-ComfyUI.safetensors",
        "structure_control_expected_bytes": 7550980272,
        "structure_control_backend": "qwen21_union",
        "structure_control_modes": ["canny"],
        "structure_control_max_pixels": 1100000,
        "structure_control_steps": 20,
        "structure_control_max_steps": 40,
    },
    "qwen21_detail_fix": {
        "name": "Qwen-Image-2.1 · Detail / Anatomy Fix",
        "kind": "create",
        "family": "qwen",
        "category": "photo",
        "category_label": "Фотореал",
        "quality_tier": "best",
        "workflow": "qwen_fix_t2i",
        "prompt_model_id": "qwen21_design",
        "steps": 20,
        "cfg": 3.0,
        "sampler": "seeds_2",
        "scheduler": "sgm_uniform",
        "max_quality": False,
        "recommended": False,
        "speed": "Медленно",
        "memory": "Очень высокая",
        "best_for": "Кисти, лица, мелкие текстуры и сложные детали, когда обычный Qwen даёт артефакты",
        "estimate": "≈ 90–140 с при ~1 Мп",
        "strengths": "Специализированный Qwen-Image-2.1 Fix LoRA с APG и FreSca. В локальных A/B улучшал следование промту и детализацию без грубого ухудшения лица или кистей.",
        "limitations": "Только ручной specialist. Может заметно менять кадрирование и композицию. Не поддерживает visual references или Structure Control. Проверен на RTX 3070 8 ГБ до 1024×1024; для Full HD используй Delivery upscale или AI Restore.",
        "installed": ROOT / "Models" / "loras" / "Qwen" / "qwen-image-2.1-fix-1.0-comfy.safetensors",
        "expected_bytes": 111612000,
        "sha256": "E4A369158B957AEE3A8316D94DBE00C98F7D648EF3D1926CCF7283915B6DB60C",
        "max_native_side": 1280,
        "max_native_pixels": 1100000,
    },
    "qwen21_pdd4_fast": {
        "name": "Qwen-Image-2.1 · PDD4 Fast",
        "kind": "create",
        "family": "qwen",
        "category": "draft",
        "category_label": "Быстрые режимы",
        "quality_tier": "fast",
        "workflow": "qwen_pdd4_t2i",
        "steps": 4,
        "max_quality": False,
        "recommended": False,
        "speed": "Быстро",
        "memory": "Высокая",
        "best_for": "Быстрые финальные варианты Qwen-Image-2.1 без визуальных референсов",
        "estimate": "≈ 18–25 с",
        "strengths": "Официальный Alibaba PAI Fun-Acc PDD: 4 шага, примерно в 2.2–2.7 раза быстрее текущего 40-step Maximum в локальных A/B, при сопоставимом качестве T2I.",
        "limitations": "Только text-to-image Fast. Не использовать для Edit/identity/reference: локальные тесты показали заметный дрейф лица, волос и кадрирования. Maximum 40-step остаётся режимом качества.",
        "installed": ROOT / "Models" / "loras" / "Qwen" / "Qwen-Image-2.1-Fun-Acc-4Step-PDD-T8.safetensors",
        "expected_bytes": 345632904,
        "sha256": "6f6fc81bea6ce13f2515e21cc2b62de374fa77ecc43f18988028bbf1b3403ee4",
    },
    "qwen21_character": {
        "name": "Персонаж · новая сцена",
        "kind": "create",
        "family": "qwen",
        "category": "character",
        "category_label": "Персонажи",
        "quality_tier": "best",
        "workflow": "character_scene",
        "steps": 25,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "simple",
        "max_quality": True,
        "max_steps": 40,
        "max_quality_note": "Финальный identity/reference-профиль Qwen-Image-2.1: 40 шагов. Локальный same-source/seed тест показал лучшее удержание лица/волос и более чистую кисть/позу, чем 32 шага.",
        "recommended": False,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Новая сцена с уже сохранённым персонажем",
        "estimate": "≈ 35–50 с",
        "strengths": "РСЃРїРѕР»СЊР·СѓРµС‚ СЃРѕС…СЂР°РЅС‘РЅРЅС‹Р№ РїСЂРѕС„РёР»СЊ РєР°Рє identity-reference Рё РїРѕР·РІРѕР»СЏРµС‚ РјРµРЅСЏС‚СЊ СЃС†РµРЅСѓ, РѕРґРµР¶РґСѓ, РїРѕР·Сѓ, СЂР°РєСѓСЂСЃ Рё С„РѕСЂРјР°С‚.",
        "limitations": "Лучший локальный режим continuity, но не биометрическая копия: при очень сильной смене ракурса или стилизации лицо может немного дрейфовать.",
        "installed": ROOT / "Models" / "diffusion_models" / "qwen_image_2.1_int8_convrot.safetensors",
    },
    "flux2_fast": {
        "name": "FLUX.2 Klein",
        "kind": "create",
        "family": "flux2",
        "category": "draft",
        "category_label": "Быстрые режимы",
        "quality_tier": "draft",
        "profile": "fast",
        "steps": 4,
        "cfg": 1.0,
        "sampler": "euler",
        "scheduler": "Flux2Scheduler",
        "max_quality": True,
        "max_steps": 4,
        "max_quality_note": "FLUX.2 Klein Distilled рассчитан на 4 шага. Maximum не пережаривает distilled-профиль; для финального качества лучше выбрать Krea/Juggernaut/Qwen.",
        "recommended": False,
        "speed": "Очень быстро",
        "memory": "Средняя",
        "best_for": "Черновики и быстрый подбор идеи",
        "estimate": "≈ 4–10 с",
        "strengths": "Быстрые черновики, подбор композиции и короткие итерации.",
        "limitations": "Финальный фотореал обычно слабее Krea 2 Turbo.",
        "installed": ROOT / "Models" / "diffusion_models" / "flux-2-klein-4b-fp8.safetensors",
    },
    "qwen21_edit": {
        "name": "Qwen-Image-2.1",
        "kind": "edit",
        "recommended": True,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Одежда, фон, объекты, смысловые правки",
        "estimate": "≈ 30–50 с",
        "strengths": "Умное редактирование всей сцены: одежда, фон, объекты, смысловые изменения.",
        "limitations": "Может немного изменить соседние детали; для пиксельной точности используй Exact Edit.",
        "installed": ROOT / "Models" / "diffusion_models" / "qwen_image_2.1_int8_convrot.safetensors",
    },
    "qwen21_adult_edit": {
        "name": "Qwen-Image-2.1 · 18+ Adult Edit (Base)",
        "kind": "edit",
        "adult": True,
        "recommended": False,
        "speed": "Средняя",
        "memory": "Высокая",
        "best_for": "Локальное adult-only редактирование взрослых персонажей без облачной модерации",
        "estimate": "≈ 30–50 с",
        "strengths": "Тот же локальный Qwen-Image-2.1 Smart Edit, но с явным 18+ age-guard и сохранением исходного adult-запроса.",
        "limitations": "Пока используется базовый Qwen 2.1: специализированный anatomy/NSFW LoRA v2 проходит отдельную квалификацию и ещё не установлен.",
        "installed": ROOT / "Models" / "diffusion_models" / "qwen_image_2.1_int8_convrot.safetensors",
    },
    "flux2_exact": {
        "name": "FLUX.2 Exact Edit",
        "kind": "edit",
        "recommended": False,
        "speed": "Быстро",
        "memory": "Средняя",
        "best_for": "Тату, одежда и мелкие локальные правки",
        "estimate": "≈ 10–15 с",
        "strengths": "Меняет только область маски; остальная картинка сохраняется пиксельно.",
        "limitations": "Нужна маска. Не предназначен для крупных смысловых перестроений всей сцены.",
        "installed": ROOT / "Models" / "diffusion_models" / "flux-2-klein-4b-fp8.safetensors",
    },
    "wan22_preview": {
        "name": "Wan 2.2 Preview 5B",
        "kind": "animate",
        "recommended": True,
        "speed": "Быстрее",
        "memory": "Высокая",
        "best_for": "Проверка движения перед финальным видео",
        "estimate": "≈ 2 мин / 1 с видео",
        "strengths": "Подбор движения и быстрые image-to-video предпросмотры.",
        "limitations": "Финальная детализация ниже A14B.",
        "video_controls": {
            "max_frames": 81,
            "max_pixels": 920000,
            "defaults": {
                "width": 640, "height": 640, "fps": 16,
                "steps": 12, "cfg": 5.0, "shift": 8.0, "sampler": "uni_pc",
                "negative": "blurry, low quality, distorted face, deformed body, extra limbs, identity change, flicker, jitter, morphing, melting, warped anatomy, text, watermark"
            },
            "resolutions": [
                {"id": "square", "label": "1:1", "width": 640, "height": 640},
                {"id": "wide", "label": "16:9", "width": 960, "height": 544},
                {"id": "portrait", "label": "9:16", "width": 544, "height": 960}
            ],
            "ranges": {
                "width": {"min": 320, "max": 1280, "step": 16},
                "height": {"min": 320, "max": 1280, "step": 16},
                "fps": {"min": 8, "max": 30, "step": 1},
                "steps": {"min": 4, "max": 30, "step": 1},
                "cfg": {"min": 0.5, "max": 10.0, "step": 0.1},
                "shift": {"min": 1.0, "max": 12.0, "step": 0.1}
            },
            "samplers": ["uni_pc", "euler"]
        },
        "installed": ROOT / "Models" / "diffusion_models" / "Wan2.2-TI2V-5B-Q4_K_M.gguf",
    },
    "wan22_quality": {
        "name": "Wan 2.2 Quality A14B",
        "kind": "animate",
        "recommended": False,
        "speed": "Очень медленно",
        "memory": "Высокая",
        "best_for": "Финальный I2V с максимальным качеством",
        "estimate": "≈ 15–25+ мин / короткий клип",
        "strengths": "Лучший установленный image-to-video режим по деталям и движению.",
        "limitations": "Очень тяжёлый для 8 ГБ. Сначала согласуй движение в Preview; игры и другие GPU-приложения могут сильно увеличить время.",
        "video_controls": {
            "max_frames": 81,
            "max_pixels": 460000,
            "defaults": {
                "width": 640, "height": 640, "fps": 16,
                "steps": 20, "cfg": 3.5, "shift": 5.0, "sampler": "euler",
                "negative": "blurry, low quality, distorted face, deformed body, extra limbs, identity change, flicker, jitter, morphing, melting, warped anatomy, text, watermark"
            },
            "resolutions": [
                {"id": "square", "label": "1:1", "width": 640, "height": 640},
                {"id": "wide", "label": "16:9", "width": 832, "height": 480},
                {"id": "portrait", "label": "9:16", "width": 480, "height": 832}
            ],
            "ranges": {
                "width": {"min": 320, "max": 1280, "step": 16},
                "height": {"min": 320, "max": 1280, "step": 16},
                "fps": {"min": 8, "max": 30, "step": 1},
                "steps": {"min": 8, "max": 32, "step": 1},
                "cfg": {"min": 0.5, "max": 8.0, "step": 0.1},
                "shift": {"min": 1.0, "max": 10.0, "step": 0.1}
            },
            "samplers": ["euler", "uni_pc"]
        },
        "installed": ROOT / "Models" / "diffusion_models" / "Wan2.2-I2V-A14B-HighNoise-Q3_K_M.gguf",
    },
    "nmkd_upscale": {
        "name": "NMKD Superscale",
        "kind": "enhance",
        "recommended": True,
        "speed": "Быстро",
        "memory": "Низкая",
        "best_for": "Финальное увеличение картинки или видео",
        "estimate": "≈ 10 с для изображения ×2",
        "strengths": "Быстрое увеличение изображения и покадровый video upscale. Для PNG из Qwen/Krea2 перед image-upscale автоматически убирается 2px VAE-grid из временной копии; исходный файл не меняется.",
        "limitations": "Очень быстрый, но работает покадрово и не восстанавливает временную согласованность между кадрами.",
        "installed": ROOT / "Models" / "upscale_models" / "4x_NMKD-Superscale-SP_178000_G.pth",
    },
    "omnisr_upscale": {
        "name": "OmniSR Faithful X2",
        "kind": "enhance",
        "recommended": True,
        "speed": "Очень быстро",
        "memory": "Низкая",
        "best_for": "Бережное увеличение фото без сильного изменения исходника",
        "estimate": "≈ 4–5 с для 768×1024 → 1536×2048",
        "strengths": "Лёгкий x2 super-resolution, хорошо сохраняющий исходную структуру и цвета. Для PNG из Qwen/Krea2 перед upscale автоматически убирается 2px VAE-grid из временной копии; исходный файл не меняется.",
        "limitations": "Только ×2. Добавляет меньше агрессивной резкости, чем NMKD.",
        "installed": ROOT / "Models" / "upscale_models" / "OmniSR_X2_DIV2K.safetensors",
    },
    "vosr2_restore": {
        "name": "VOSR2 AI Restore",
        "kind": "enhance",
        "recommended": True,
        "speed": "Медленнее",
        "memory": "Высокая",
        "best_for": "Умное восстановление дефектных AI-фото: кожа, волосы, лицо и мелкие структуры",
        "estimate": "≈ 55–70 с для 960×540 → 1920×1080",
        "strengths": "Генеративно реконструирует правдоподобные детали вместо простого усиления исходных пикселей.",
        "limitations": "Может дорисовывать правдоподобные детали, которых не было в исходнике. Для точного сохранения используй OmniSR.",
        "expected_bytes": 5576385424,
        "installed": ROOT / "ComfyUI" / "models" / "vosr2" / "VOSR2" / "checkpoints" / "ema_model.safetensors",
    },
    "seedvr2_video": {
        "name": "SeedVR2 AI Restore",
        "kind": "enhance",
        "recommended": True,
        "speed": "Медленнее",
        "memory": "Высокая",
        "best_for": "Финальное восстановление деталей и стабильности видео",
        "estimate": "≈ 95 с / 1 с видео при 512→1024",
        "strengths": "Диффузионное восстановление видео с учётом соседних кадров: детали, текстуры и временная согласованность лучше покадрового upscale.",
        "limitations": "На 8 ГБ используется 3B FP8 + BlockSwap/CPU offload. Длинные и высокие ролики обрабатываются заметно дольше.",
        "installed": ROOT / "Models" / "SEEDVR2" / "seedvr2_ema_3b_fp8_e4m3fn.safetensors",
    },
}
PRODUCTION_ASSETS = [
    ("Krea 2 Turbo", ROOT / "Models" / "diffusion_models" / "krea2_turbo_nvfp4.safetensors", 7673668448),
    ("Z-Image Turbo Q5", ROOT / "Models" / "diffusion_models" / "z-image-turbo-Q5_K_M.gguf", 5574444096),
    ("Chroma1-HD Q5", ROOT / "Models" / "diffusion_models" / "Chroma1-HD-Q5_K_M.gguf", 6286069920),
    ("Anima Turbo v1.1", ROOT / "Models" / "diffusion_models" / "anima-turbo-v1.1.safetensors", 4182230656),
    ("Anima Qwen3 0.6B encoder", ROOT / "Models" / "text_encoders" / "qwen_3_06b_base.safetensors", 1192135096),
    ("Juggernaut XL v9", ROOT / "Models" / "checkpoints" / "Juggernaut-XL_v9_RunDiffusionPhoto_v2.safetensors", 7105348188),
    ("Animagine XL 4.0 Opt", ROOT / "Models" / "checkpoints" / "Animagine-XL-4.0-Opt.safetensors", 6938350040),
    ("NoobAI XL V-Pred 1.0", ROOT / "Models" / "checkpoints" / "NoobAI-XL-Vpred-v1.0.safetensors", 7105350110),
    ("Krea/Qwen3-VL 4B encoder", ROOT / "Models" / "text_encoders" / "qwen3vl_4b_fp8_scaled.safetensors", 5242467968),
    ("Krea/Qwen VAE", ROOT / "Models" / "vae" / "qwen_image_vae.safetensors", 253806246),
    ("FLUX.2 Klein", ROOT / "Models" / "diffusion_models" / "flux-2-klein-4b-fp8.safetensors", 4070624520),
    ("FLUX.2 Qwen encoder", ROOT / "Models" / "text_encoders" / "qwen_3_4b_fp4_flux2.safetensors", 3848213998),
    ("FLUX.2 VAE", ROOT / "Models" / "vae" / "flux2-vae.safetensors", 336211292),
    ("Qwen-Image-2.1", ROOT / "Models" / "diffusion_models" / "qwen_image_2.1_int8_convrot.safetensors", 7256783064),
    ("Qwen3-VL 8B W4A8", ROOT / "Models" / "text_encoders" / "qwen3vl_8b_w4a8.safetensors", 6312105364),
    ("Qwen3-VL 8B Int8 ConvRot", ROOT / "Models" / "text_encoders" / "qwen3vl_8b_int8_convrot.safetensors", 6312105364),
    ("Qwen-Image-2.1 VAE", ROOT / "Models" / "vae" / "qwen_image_2.1_vae_bf16.safetensors", 675509688),
    ("Zen Qwen3.5-0.8B adapter v12", ZEN_EDIT_ADAPTER, 638987136),
    ("Zen Qwen3.5-0.8B model", ZEN_EDIT_STUDENT / "model.safetensors-00001-of-00001.safetensors", 1746942600),
    ("Zen Qwen3.5-0.8B config", ZEN_EDIT_STUDENT / "config.json", 2907),
    ("Zen Qwen3.5-0.8B index", ZEN_EDIT_STUDENT / "model.safetensors.index.json", 50900),
    ("Zen Qwen3.5-0.8B preprocessor", ZEN_EDIT_STUDENT / "preprocessor_config.json", 390),
    ("Zen Qwen3.5-0.8B tokenizer", ZEN_EDIT_STUDENT / "tokenizer.json", 12807982),
    ("Zen Qwen3.5-0.8B tokenizer config", ZEN_EDIT_STUDENT / "tokenizer_config.json", 16709),
    ("Zen Qwen3.5-0.8B merges", ZEN_EDIT_STUDENT / "merges.txt", 3353259),
    ("Zen Qwen3.5-0.8B vocab", ZEN_EDIT_STUDENT / "vocab.json", 6722759),
    ("Zen Qwen3.5-0.8B video preprocessor", ZEN_EDIT_STUDENT / "video_preprocessor_config.json", 385),
    ("Zen Qwen3.5-0.8B chat template", ZEN_EDIT_STUDENT / "chat_template.jinja", 7755),
    ("Qwen-Image-2.1 PDD4", ROOT / "Models" / "loras" / "Qwen" / "Qwen-Image-2.1-Fun-Acc-4Step-PDD-T8.safetensors", 345632904),
    ("Qwen-Image-2.1 Detail Fix", ROOT / "Models" / "loras" / "Qwen" / "qwen-image-2.1-fix-1.0-comfy.safetensors", 111612000),
    ("Qwen-Image-2.1 Union Control", ROOT / "ComfyUI" / "models" / "controlnet" / "Qwen-Image-2.1-Fun-Controlnet-Union-ComfyUI.safetensors", 7550980272),
    ("Wan 2.2 Preview 5B", ROOT / "Models" / "diffusion_models" / "Wan2.2-TI2V-5B-Q4_K_M.gguf", 3433116000),
    ("Wan 2.2 A14B HighNoise", ROOT / "Models" / "diffusion_models" / "Wan2.2-I2V-A14B-HighNoise-Q3_K_M.gguf", 7176106496),
    ("Wan 2.2 A14B LowNoise", ROOT / "Models" / "diffusion_models" / "Wan2.2-I2V-A14B-LowNoise-Q3_K_M.gguf", 7176106496),
    ("Wan UMT5 encoder", ROOT / "Models" / "text_encoders" / "umt5-xxl-encoder-Q3_K_M.gguf", 3055097696),
    ("Wan 2.2 VAE", ROOT / "Models" / "vae" / "wan2.2_vae.safetensors", 1409400960),
    ("Wan 2.1 VAE", ROOT / "Models" / "vae" / "wan_2.1_vae.safetensors", 253815318),
    ("NMKD Superscale", ROOT / "Models" / "upscale_models" / "4x_NMKD-Superscale-SP_178000_G.pth", 66958607),
    ("OmniSR X2", ROOT / "Models" / "upscale_models" / "OmniSR_X2_DIV2K.safetensors", 1655992),
    ("VOSR2 DiT", ROOT / "ComfyUI" / "models" / "vosr2" / "VOSR2" / "checkpoints" / "ema_model.safetensors", 5576385424),
    ("VOSR2 Qwen 2D VAE", ROOT / "ComfyUI" / "models" / "vosr2" / "VOSR2" / "Qwen-Image-vae-2d" / "diffusion_pytorch_model.safetensors", 178418892),
    ("VOSR2 DINOv2-L", ROOT / "ComfyUI" / "models" / "vosr2" / "VOSR2" / "dinov2_vitl14.safetensors", 1217506936),
    ("SeedVR2 3B FP8", ROOT / "Models" / "SEEDVR2" / "seedvr2_ema_3b_fp8_e4m3fn.safetensors", 3391544696),
    ("SeedVR2 VAE", ROOT / "Models" / "SEEDVR2" / "ema_vae_fp16.safetensors", 501324814),
]

def production_asset_integrity() -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    for name, path, expected in PRODUCTION_ASSETS:
        exists = path.is_file()
        actual = path.stat().st_size if exists else 0
        ok = exists and actual == expected
        items.append({
            "name": name,
            "path": str(path),
            "exists": exists,
            "expected_bytes": expected,
            "actual_bytes": actual,
            "ok": ok,
        })
    bad = [x for x in items if not x["ok"]]
    return {"ok": not bad, "total": len(items), "valid": len(items) - len(bad), "bad": bad, "items": items}

ASPECT_PRESETS = {
    "square": {"name": "Квадрат", "ratio": "1:1", "width": 1024, "height": 1024},
    "portrait": {"name": "Портрет", "ratio": "3:4", "width": 768, "height": 1024},
    "portrait_hq": {"name": "Портрет 2:3", "ratio": "2:3", "width": 832, "height": 1248},
    "social": {"name": "Соцсети", "ratio": "4:5", "width": 896, "height": 1120},
    "landscape": {"name": "Альбом", "ratio": "4:3", "width": 1152, "height": 864},
    "wide": {"name": "Широкий", "ratio": "16:9", "width": 1280, "height": 720},
    "fhd_native": {"name": "Full HD native", "ratio": "16:9", "width": 1920, "height": 1080},
    "story": {"name": "Вертикаль", "ratio": "9:16", "width": 720, "height": 1280},
}

# P40: model-aware resolution advice. This is metadata/planning only: manual/native
# dimensions remain valid and build_job does not silently replace them.
RESOLUTION_PLANNER_PROFILES: dict[str, dict[str, Any]] = {
    "krea2_8gb": {
        "label": "Krea 2 · 8GB",
        "confidence": "high",
        "evidence": "LocalGen controlled 1024² and 1280×720 tests",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1248},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
    },
    "sdxl_1mp": {
        "label": "SDXL · ~1 MP",
        "confidence": "high",
        "evidence": "Model-native SDXL buckets + LocalGen 832×1216 tests; working buckets preserve the requested LocalGen aspect",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "portrait_tall", "width": 768, "height": 1344},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "landscape_hq", "width": 1216, "height": 832},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
        "native_reference_buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 896, "height": 1152},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "portrait_tall", "width": 768, "height": 1344},
            {"id": "landscape", "width": 1152, "height": 896},
            {"id": "landscape_hq", "width": 1216, "height": 832},
            {"id": "wide", "width": 1344, "height": 768},
        ],
    },
    "juggernaut_8gb": {
        "label": "Juggernaut XL · LocalGen 8GB",
        "confidence": "high",
        "evidence": "Two-seed LocalGen FHD A/B: 1280×720 + NMKD delivery was ~34–36% faster and avoided a severe extra-hand artifact on seed400002; native FHD preserved more scene/prompt detail on seed400001. Recommendation stays advisory; native FHD remains available.",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "portrait_tall", "width": 768, "height": 1344},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "landscape_hq", "width": 1216, "height": 832},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
        "native_reference_buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 896, "height": 1152},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "portrait_tall", "width": 768, "height": 1344},
            {"id": "landscape", "width": 1152, "height": 896},
            {"id": "landscape_hq", "width": 1216, "height": 832},
            {"id": "wide", "width": 1344, "height": 768},
        ],
    },
    "anima_8gb": {
        "label": "Anima · 8GB portrait",
        "confidence": "high",
        "evidence": "LocalGen controlled 832×1216 Anima portrait tests; wide/story working buckets preserve requested aspect",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "portrait_tall", "width": 768, "height": 1344},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "landscape_hq", "width": 1216, "height": 832},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
    },
    "zimage_8gb_candidate": {
        "label": "Z-Image Q5 · 8GB candidate",
        "confidence": "research",
        "evidence": "Official 1024-class buckets; LocalGen Q5 validated at 512², higher buckets require P40 A/B",
        "buckets": [
            {"id": "square", "width": 768, "height": 768},
            {"id": "portrait", "width": 640, "height": 896},
            {"id": "portrait_hq", "width": 640, "height": 960},
            {"id": "landscape", "width": 896, "height": 640},
            {"id": "wide", "width": 1024, "height": 576},
            {"id": "story", "width": 576, "height": 1024},
        ],
        "native_reference_buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 864, "height": 1152},
            {"id": "portrait_hq", "width": 832, "height": 1248},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "landscape_hq", "width": 1248, "height": 832},
            {"id": "wide", "width": 1280, "height": 720},
        ],
    },
    "chroma_8gb": {
        "label": "Chroma1-HD Q5 · 8GB",
        "confidence": "high",
        "evidence": "LocalGen measured 7687 MiB peak at 512²; preserve approximately the same latent area",
        "buckets": [
            {"id": "square", "width": 512, "height": 512},
            {"id": "portrait", "width": 432, "height": 576},
            {"id": "portrait_hq", "width": 416, "height": 608},
            {"id": "landscape", "width": 576, "height": 432},
            {"id": "wide", "width": 672, "height": 384},
            {"id": "story", "width": 384, "height": 672},
        ],
    },
    "qwen_8gb_candidate": {
        "label": "Qwen-Image 2.1 · 8GB candidate",
        "confidence": "medium",
        "evidence": "LocalGen int8/offload tests; official Qwen buckets retained as reference only",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1248},
            {"id": "landscape", "width": 1152, "height": 864},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
        "native_reference_buckets": [
            {"id": "square", "width": 1328, "height": 1328},
            {"id": "wide", "width": 1664, "height": 928},
            {"id": "story", "width": 928, "height": 1664},
            {"id": "landscape", "width": 1472, "height": 1140},
            {"id": "portrait", "width": 1140, "height": 1472},
            {"id": "landscape_hq", "width": 1584, "height": 1056},
            {"id": "portrait_hq", "width": 1056, "height": 1584},
        ],
    },
    "flux2_1mp": {
        "label": "FLUX.2 Klein · ~1 MP",
        "confidence": "medium",
        "evidence": "FLUX.2 1024-class VAE + LocalGen fast-model tests",
        "buckets": [
            {"id": "square", "width": 1024, "height": 1024},
            {"id": "portrait", "width": 768, "height": 1024},
            {"id": "portrait_hq", "width": 832, "height": 1216},
            {"id": "landscape", "width": 1216, "height": 832},
            {"id": "wide", "width": 1280, "height": 720},
            {"id": "story", "width": 720, "height": 1280},
        ],
    },
}

MODEL_RESOLUTION_PROFILE_IDS = {
    "krea2_general": "krea2_8gb",
    "krea2_adult": "krea2_8gb",
    "zimage_turbo_q5": "zimage_8gb_candidate",
    "chroma1_hd": "chroma_8gb",
    "anima_portrait": "anima_8gb",
    "sdxl_people": "juggernaut_8gb",
    "animagine_anime": "sdxl_1mp",
    "noobai_adult_anime": "sdxl_1mp",
    "qwen21_design": "qwen_8gb_candidate",
    "qwen21_character": "qwen_8gb_candidate",
    "flux2_fast": "flux2_1mp",
}
FAMILY_RESOLUTION_PROFILE_IDS = {
    "krea2": "krea2_8gb",
    "zimage": "zimage_8gb_candidate",
    "chroma": "chroma_8gb",
    "anima": "anima_8gb",
    "sdxl": "sdxl_1mp",
    "animagine": "sdxl_1mp",
    "noobai": "sdxl_1mp",
    "qwen": "qwen_8gb_candidate",
    "flux2": "flux2_1mp",
}

def _resolution_profile_for(model_id: str, item: dict[str, Any] | None = None) -> tuple[str, dict[str, Any] | None]:
    item = item or MODEL_REGISTRY.get(model_id) or {}
    profile_id = MODEL_RESOLUTION_PROFILE_IDS.get(model_id)
    if not profile_id:
        profile_id = FAMILY_RESOLUTION_PROFILE_IDS.get(str(item.get("family") or ""))
    profile = RESOLUTION_PLANNER_PROFILES.get(str(profile_id or ""))
    return str(profile_id or ""), profile

def _resolution_bucket_distance(bucket: dict[str, Any], target_ratio: float) -> float:
    width = max(1, int(bucket.get("width") or 1))
    height = max(1, int(bucket.get("height") or 1))
    ratio = width / height
    return abs(ratio - target_ratio) / max(target_ratio, 1e-9)

def _resolution_bucket_public(bucket: dict[str, Any]) -> dict[str, Any]:
    width = int(bucket.get("width") or 0)
    height = int(bucket.get("height") or 0)
    return {
        "id": str(bucket.get("id") or ""),
        "width": width,
        "height": height,
        "pixels": width * height,
        "ratio": round(width / height, 6) if width and height else 0.0,
    }

def resolution_planner_metadata(model_id: str) -> dict[str, Any]:
    model = MODEL_REGISTRY.get(str(model_id or ""))
    if not model or model.get("kind") != "create":
        return {}
    profile_id, profile = _resolution_profile_for(str(model_id), model)
    if not profile:
        return {}
    return {
        "profile_id": profile_id,
        "label": str(profile.get("label") or profile_id),
        "confidence": str(profile.get("confidence") or "research"),
        "evidence": str(profile.get("evidence") or ""),
        "automatic": False,
        "manual_native_sizes_preserved": True,
        "buckets": [_resolution_bucket_public(x) for x in (profile.get("buckets") or [])],
        "native_reference_buckets": [
            _resolution_bucket_public(x) for x in (profile.get("native_reference_buckets") or [])
        ],
    }

def plan_create_resolution(model_id: str, width: int, height: int) -> dict[str, Any]:
    model_id = str(model_id or "")
    model = MODEL_REGISTRY.get(model_id)
    if not model or model.get("kind") != "create":
        raise ValueError("Неизвестная Create-модель")
    width = _checked_int(width, name="Ширина", default=1024, low=256, high=CREATE_NATIVE_MAX_SIDE)
    height = _checked_int(height, name="Высота", default=1024, low=256, high=CREATE_NATIVE_MAX_SIDE)
    profile_id, profile = _resolution_profile_for(model_id, model)
    if not profile or not profile.get("buckets"):
        return {
            "ok": True,
            "model_id": model_id,
            "requested": {"width": width, "height": height},
            "recommended": {"width": width, "height": height},
            "changed": False,
            "profile_id": "",
            "confidence": "none",
            "manual_native_sizes_preserved": True,
        }

    target_ratio = width / height
    buckets = list(profile.get("buckets") or [])
    best = min(buckets, key=lambda x: (_resolution_bucket_distance(x, target_ratio), -int(x.get("width", 0)) * int(x.get("height", 0))))
    reference_buckets = list(profile.get("native_reference_buckets") or [])
    ref = min(reference_buckets, key=lambda x: (_resolution_bucket_distance(x, target_ratio), -int(x.get("width", 0)) * int(x.get("height", 0)))) if reference_buckets else None

    recommended = _resolution_bucket_public(best)
    requested = {
        "width": width,
        "height": height,
        "pixels": width * height,
        "ratio": round(target_ratio, 6),
    }
    max_side = int(model.get("max_native_side") or CREATE_NATIVE_MAX_SIDE)
    max_pixels = int(model.get("max_native_pixels") or CREATE_NATIVE_MAX_PIXELS)
    manual_supported = (
        width <= max_side and height <= max_side and width * height <= max_pixels
        and width % 8 == 0 and height % 8 == 0
    )
    result = {
        "ok": True,
        "model_id": model_id,
        "profile_id": profile_id,
        "profile_label": str(profile.get("label") or profile_id),
        "confidence": str(profile.get("confidence") or "research"),
        "evidence": str(profile.get("evidence") or ""),
        "requested": requested,
        "recommended": recommended,
        "changed": recommended["width"] != width or recommended["height"] != height,
        "aspect_error": round(_resolution_bucket_distance(best, target_ratio), 6),
        "manual_native_supported": manual_supported,
        "manual_native_sizes_preserved": True,
        "automatic": False,
    }
    if ref:
        result["native_reference"] = _resolution_bucket_public(ref)
    return result

def _port_open(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.4):
            return True
    except OSError:
        return False

def _model_available(item: dict[str, Any]) -> bool:
    if not bool(item.get("enabled", True)):
        return False
    path = Path(item["installed"])
    if not path.is_file():
        return False
    expected = item.get("expected_bytes")
    if expected is not None and path.stat().st_size != int(expected):
        return False
    return True

EXPERT_SAMPLERS = ["euler", "euler_ancestral", "dpmpp_2m", "dpmpp_2m_sde", "dpmpp_3m_sde", "res_multistep"]
EXPERT_SCHEDULERS = ["simple", "normal", "karras", "beta", "sgm_uniform"]

def _model_expert_info(item: dict[str, Any]) -> dict[str, Any]:
    workflow = str(item.get("workflow") or "")
    profile = str(item.get("profile") or "")
    defaults: dict[str, Any] = {}
    editable: list[str] = []
    for key in ("steps", "cfg", "sampler", "scheduler", "clip_skip", "prediction", "zsnr", "negative", "lora_strength", "hires_scale", "hires_steps", "hires_denoise", "shift", "beta_alpha", "beta_beta"):
        if key in item:
            defaults[key] = item[key]
    if workflow == "sdxl":
        editable = ["steps", "cfg", "sampler", "scheduler", "clip_skip", "prediction", "zsnr", "negative", "hires_scale", "hires_steps", "hires_denoise"]
    elif workflow in {"qwen_t2i", "character_scene"}:
        editable = ["steps", "cfg", "sampler", "scheduler"]
    elif workflow in {"qwen_pdd4_t2i", "qwen_fix_t2i"}:
        editable = []
    elif workflow == "chroma_t2i":
        editable = ["steps", "cfg", "sampler", "shift", "beta_alpha", "beta_beta", "negative"]
    elif workflow == "zimage_t2i":
        editable = ["steps", "cfg", "sampler", "scheduler", "shift"]
    elif workflow == "anima_t2i":
        editable = ["steps", "cfg", "sampler", "scheduler", "negative"]
    elif profile in {"general", "adult"}:
        editable = ["steps", "cfg", "sampler", "scheduler"]
        if profile == "adult":
            editable.append("lora_strength")
    elif profile == "fast":
        editable = ["steps", "cfg", "sampler"]
    return {
        "defaults": defaults,
        "editable": editable,
        "ranges": {
            "steps": {"min": 1, "max": 80, "step": 1},
            "cfg": {"min": 0.1, "max": 20.0, "step": 0.1},
            "clip_skip": {"min": 1, "max": 4, "step": 1},
            "lora_strength": {"min": 0.0, "max": 2.0, "step": 0.05},
            "hires_scale": {"min": 1.0, "max": 1.6, "step": 0.05},
            "hires_steps": {"min": 1, "max": 40, "step": 1},
            "hires_denoise": {"min": 0.05, "max": 0.6, "step": 0.01},
            "shift": {"min": 0.0, "max": 4.0, "step": 0.05},
            "beta_alpha": {"min": 0.05, "max": 2.0, "step": 0.01},
            "beta_beta": {"min": 0.05, "max": 2.0, "step": 0.01},
        },
        "options": {
            "sampler": EXPERT_SAMPLERS,
            "scheduler": EXPERT_SCHEDULERS,
            "prediction": ["eps", "v_prediction"],
        },
    }

def _structure_control_path(item: dict[str, Any]) -> Path:
    control_name = str(item.get("structure_control_model") or "")
    if str(item.get("structure_control_backend") or "") == "qwen21_union":
        return ROOT / "ComfyUI" / "models" / "controlnet" / control_name
    return ROOT / "Models" / "model_patches" / control_name

def _structure_control_modes(item: dict[str, Any]) -> list[str]:
    control_name = str(item.get("structure_control_model") or "")
    if not control_name:
        return []
    control_path = _structure_control_path(item)
    control_expected = int(item.get("structure_control_expected_bytes") or 0)
    if not control_path.is_file() or (control_expected and control_path.stat().st_size != control_expected):
        return []
    declared = item.get("structure_control_modes")
    if isinstance(declared, list) and declared:
        return [str(mode) for mode in declared if str(mode) in {"canny", "pose", "depth"}]
    modes = ["canny"]
    if (
        DWPOSE_BBOX_MODEL.is_file() and DWPOSE_BBOX_MODEL.stat().st_size == DWPOSE_BBOX_BYTES
        and DWPOSE_POSE_MODEL.is_file() and DWPOSE_POSE_MODEL.stat().st_size == DWPOSE_POSE_BYTES
    ):
        modes.append("pose")
    if DEPTH_ANYTHING_V2_ONNX.is_file() and DEPTH_ANYTHING_V2_ONNX.stat().st_size == DEPTH_ANYTHING_V2_BYTES:
        modes.append("depth")
    return modes

def _model_public(item: dict[str, Any], model_id: str) -> dict[str, Any]:
    out = {k: v for k, v in item.items() if k not in {"installed", "sha256"}}
    out["id"] = model_id
    out["installed"] = _model_available(item)
    if item.get("kind") == "create":
        out["max_native_side"] = int(item.get("max_native_side") or CREATE_NATIVE_MAX_SIDE)
        out["max_native_pixels"] = int(item.get("max_native_pixels") or CREATE_NATIVE_MAX_PIXELS)
        out["expert"] = _model_expert_info(item)
        planner = resolution_planner_metadata(model_id)
        if planner:
            out["resolution_planner"] = planner
        control_name = str(item.get("structure_control_model") or "")
        if control_name:
            modes = _structure_control_modes(item)
            out["structure_control_installed"] = bool(modes)
            out["structure_control_modes"] = modes
    return out

CUSTOM_MODELS_FILE = APP / "data" / "custom-models.json"
_CUSTOM_MODEL_LOCK = threading.Lock()
MODEL_STORAGE_FOLDERS = {
    "checkpoints": ROOT / "Models" / "checkpoints",
    "diffusion_models": ROOT / "Models" / "diffusion_models",
    "loras": ROOT / "Models" / "loras",
    "text_encoders": ROOT / "Models" / "text_encoders",
    "vae": ROOT / "Models" / "vae",
    "upscale_models": ROOT / "Models" / "upscale_models",
}
REFERENCE_CACHE_DIR = APP / "data" / "reference-cache"
REFERENCE_ORPHAN_STALE_SECONDS = 24 * 60 * 60
CUSTOM_WORKFLOW_BASES = {
    "krea2": {"label": "Krea 2", "model_id": "krea2_general", "folder": "diffusion_models", "reference": "krea2_turbo_nvfp4.safetensors"},
    "flux2": {"label": "FLUX.2 Klein", "model_id": "flux2_fast", "folder": "diffusion_models", "reference": "flux-2-klein-4b-fp8.safetensors"},
    "qwen21": {"label": "Qwen-Image-2.1", "model_id": "qwen21_design", "folder": "diffusion_models", "reference": "qwen_image_2.1_int8_convrot.safetensors"},
}
_SAFETENSORS_FINGERPRINT_CACHE: dict[tuple[str, int, int], str] = {}

def _read_custom_model_records() -> list[dict[str, Any]]:
    try:
        if not CUSTOM_MODELS_FILE.is_file():
            return []
        data = json.loads(CUSTOM_MODELS_FILE.read_text(encoding="utf-8"))
        return [x for x in data if isinstance(x, dict)] if isinstance(data, list) else []
    except Exception:
        return []

def _write_custom_model_records(records: list[dict[str, Any]]) -> None:
    CUSTOM_MODELS_FILE.parent.mkdir(parents=True, exist_ok=True)
    temp = CUSTOM_MODELS_FILE.with_name(f".{CUSTOM_MODELS_FILE.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, CUSTOM_MODELS_FILE)
    finally:
        temp.unlink(missing_ok=True)

def _custom_sdxl_registry_item(record: dict[str, Any]) -> dict[str, Any]:
    checkpoint = Path(str(record.get("checkpoint") or "")).name
    return {
        "name": str(record.get("name") or checkpoint or "Custom SDXL"),
        "kind": "create",
        "family": "sdxl_custom",
        "category": "custom",
        "category_label": "Мои модели",
        "quality_tier": "custom",
        "workflow": "sdxl",
        "max_quality": True,
        "hires_scale": float(record.get("hires_scale", 1.15)),
        "hires_steps": int(record.get("hires_steps", 6)),
        "hires_denoise": float(record.get("hires_denoise", 0.22)),
        "max_quality_note": "Двухэтапный latent-refine с пользовательскими настройками этого SDXL-профиля.",
        "recommended": False,
        "optional": True,
        "user_model": True,
        "speed": "Зависит от модели",
        "memory": "Высокая",
        "best_for": str(record.get("best_for") or "Пользовательский SDXL checkpoint"),
        "estimate": "зависит от checkpoint",
        "strengths": str(record.get("description") or "Пользовательский SDXL checkpoint."),
        "limitations": "Параметры задаёт пользователь. LocalGen не может гарантировать совместимость checkpoint, если это не SDXL-модель.",
        "checkpoint": checkpoint,
        "steps": int(record.get("steps", 30)),
        "cfg": float(record.get("cfg", 5.0)),
        "sampler": str(record.get("sampler") or "dpmpp_2m"),
        "scheduler": str(record.get("scheduler") or "karras"),
        "clip_skip": int(record.get("clip_skip", 1)),
        "prediction": str(record.get("prediction") or "eps"),
        "zsnr": bool(record.get("zsnr", False)),
        "negative": str(record.get("negative") or ""),
        "source": "user",
        "installed": ROOT / "Models" / "checkpoints" / checkpoint,
    }

def _custom_diffusion_registry_item(record: dict[str, Any]) -> dict[str, Any]:
    family = str(record.get("family") or "")
    spec = CUSTOM_WORKFLOW_BASES.get(family)
    if not spec:
        raise ValueError("Неизвестное семейство пользовательской модели")
    base = dict(MODEL_REGISTRY[spec["model_id"]])
    model_file = Path(str(record.get("model_file") or "")).name
    base.update({
        "name": str(record.get("name") or model_file or spec["label"]),
        "family": family + "_custom",
        "category": "custom",
        "category_label": "Мои модели",
        "quality_tier": "custom",
        "recommended": False,
        "optional": True,
        "user_model": True,
        "source": "user",
        "prompt_model_id": spec["model_id"],
        "model_file": model_file,
        "installed": ROOT / "Models" / spec["folder"] / model_file,
        "best_for": str(record.get("best_for") or f"Пользовательская {spec['label']} модель"),
        "strengths": str(record.get("description") or f"Пользовательская модель, совместимая с workflow {spec['label']}."),
        "limitations": f"LocalGen подтвердил совместимость структуры весов с {spec['label']}; encoder/VAE используются из проверенного базового workflow.",
    })
    for key in ("steps", "cfg", "sampler", "scheduler"):
        if key in record and record.get(key) not in (None, ""):
            base[key] = record[key]
    return base


def _load_custom_models_into_registry() -> None:
    for model_id in [k for k, v in MODEL_REGISTRY.items() if v.get("user_model")]:
        MODEL_REGISTRY.pop(model_id, None)
    for record in _read_custom_model_records():
        model_id = str(record.get("id") or "")
        if re.fullmatch(r"custom_sdxl_[a-z0-9]{8,32}", model_id):
            MODEL_REGISTRY[model_id] = _custom_sdxl_registry_item(record)
            continue
        if re.fullmatch(r"custom_(?:krea2|flux2|qwen21)_[a-z0-9]{8,32}", model_id):
            try:
                MODEL_REGISTRY[model_id] = _custom_diffusion_registry_item(record)
            except Exception:
                continue

def list_custom_model_profiles() -> list[dict[str, Any]]:
    return _read_custom_model_records()


def _registered_refs_for_model_path(path: Path) -> list[str]:
    refs: list[str] = []
    try:
        target = str(path.resolve()).lower()
    except Exception:
        target = str(path).lower()
    for model_id, item in MODEL_REGISTRY.items():
        raw = item.get("installed")
        if not raw:
            continue
        try:
            if str(Path(raw).resolve()).lower() == target:
                refs.append(model_id)
        except Exception:
            pass
    return refs

def _read_safetensors_header(path: Path) -> tuple[list[str], dict[str, Any], int]:
    with path.open("rb") as handle:
        raw_len = handle.read(8)
        if len(raw_len) != 8:
            raise ValueError("Файл слишком короткий для safetensors")
        header_len = struct.unpack("<Q", raw_len)[0]
        if header_len < 2 or header_len > 16 * 1024 * 1024:
            raise ValueError("Некорректный или слишком большой заголовок safetensors")
        raw_header = handle.read(header_len)
        if len(raw_header) != header_len:
            raise ValueError("Повреждённый заголовок safetensors")
    header = json.loads(raw_header)
    if not isinstance(header, dict):
        raise ValueError("Некорректный заголовок safetensors")
    keys = [str(k) for k in header.keys() if k != "__metadata__"]
    metadata = header.get("__metadata__")
    return keys, metadata if isinstance(metadata, dict) else {}, header_len

def _safetensors_structure_fingerprint(path: Path) -> str:
    stat = path.stat()
    key = (str(path.resolve()).lower(), int(stat.st_size), int(stat.st_mtime_ns))
    cached = _SAFETENSORS_FINGERPRINT_CACHE.get(key)
    if cached:
        return cached
    with path.open("rb") as handle:
        raw_len = handle.read(8)
        if len(raw_len) != 8:
            raise ValueError("Файл слишком короткий для safetensors")
        header_len = struct.unpack("<Q", raw_len)[0]
        if header_len < 2 or header_len > 16 * 1024 * 1024:
            raise ValueError("Некорректный или слишком большой заголовок safetensors")
        raw_header = handle.read(header_len)
        if len(raw_header) != header_len:
            raise ValueError("Повреждённый заголовок safetensors")
    header = json.loads(raw_header)
    if not isinstance(header, dict):
        raise ValueError("Некорректный заголовок safetensors")
    digest = hashlib.sha256()
    for tensor_name in sorted(k for k in header if k != "__metadata__"):
        spec = header.get(tensor_name)
        if not isinstance(spec, dict):
            continue
        shape = spec.get("shape") if isinstance(spec.get("shape"), list) else []
        digest.update(tensor_name.encode("utf-8", "replace"))
        digest.update(b"\0")
        digest.update(",".join(str(int(x)) for x in shape).encode("ascii"))
        digest.update(b"\n")
    value = digest.hexdigest()
    _SAFETENSORS_FINGERPRINT_CACHE[key] = value
    return value


def _compatible_custom_targets(folder_id: str, path: Path) -> list[dict[str, str]]:
    if folder_id != "diffusion_models" or path.suffix.lower() != ".safetensors":
        return []
    try:
        candidate = _safetensors_structure_fingerprint(path)
    except Exception:
        return []
    matches: list[dict[str, str]] = []
    for family, spec in CUSTOM_WORKFLOW_BASES.items():
        reference = MODEL_STORAGE_FOLDERS[spec["folder"]] / spec["reference"]
        if not reference.is_file():
            continue
        try:
            if candidate == _safetensors_structure_fingerprint(reference):
                matches.append({"family": family, "label": spec["label"], "folder": spec["folder"]})
        except Exception:
            continue
    return matches


def _compact_model_metadata(metadata: dict[str, Any]) -> dict[str, str]:
    out: dict[str, str] = {}
    preferred = [
        "modelspec.title", "modelspec.author", "modelspec.description", "modelspec.architecture",
        "ss_output_name", "ss_base_model_version", "format", "current_epoch", "global_step",
    ]
    for key in preferred:
        if key in metadata:
            value = str(metadata.get(key) or "").strip()
            if value and "data:image" not in value.lower():
                out[key] = value[:500]
    for key, raw in metadata.items():
        if len(out) >= 12 or key in out:
            continue
        low = str(key).lower()
        if any(token in low for token in ("thumbnail", "preview", "cover", "image")):
            continue
        value = str(raw or "").strip()
        if not value or "data:image" in value.lower() or len(value) > 1200:
            continue
        out[str(key)] = value[:500]
    return out

def _suggest_model_name(path: Path, metadata: dict[str, Any]) -> str:
    for key in ("modelspec.title", "ss_output_name"):
        value = str(metadata.get(key) or "").strip()
        if value:
            return re.sub(r"\s+", " ", value)[:80]
    recipe = metadata.get("sd_merge_recipe")
    if recipe:
        try:
            parsed = json.loads(str(recipe))
            custom = str(parsed.get("custom_name") or "").strip() if isinstance(parsed, dict) else ""
            if custom:
                return re.sub(r"[_\-]+", " ", custom)[:80]
        except Exception:
            pass
    name = re.sub(r"[_\-]+", " ", path.stem)
    return re.sub(r"\s+", " ", name).strip()[:80]

def inspect_model_file(folder: str, name: str) -> dict[str, Any]:
    folder_id = str(folder or "")
    base = MODEL_STORAGE_FOLDERS.get(folder_id)
    if base is None:
        raise ValueError("Неизвестная папка моделей")
    filename = Path(str(name or "")).name
    if not filename:
        raise ValueError("Не указан файл модели")
    path = (base / filename).resolve()
    if path.parent != base.resolve() or not path.is_file():
        raise ValueError("Файл модели не найден")
    stat = path.stat()
    suffix = path.suffix.lower()
    refs = _registered_refs_for_model_path(path)
    registered_models = [MODEL_REGISTRY[x] for x in refs if x in MODEL_REGISTRY]
    keys: list[str] = []
    metadata: dict[str, Any] = {}
    header_bytes = 0
    header_error = ""
    if suffix == ".safetensors":
        try:
            keys, metadata, header_bytes = _read_safetensors_header(path)
        except Exception as exc:
            header_error = str(exc)

    keyset = set(keys)
    has = lambda prefix: any(k.startswith(prefix) for k in keys)
    has_contains = lambda token: any(token in k for k in keys)
    architecture = "unknown"
    architecture_label = "Не определено"
    confidence = "low"
    register_supported = False
    workflow = ""
    recommendation = ""

    if folder_id == "loras" and (
        has_contains(".lora_A.") or has_contains(".lora_B.") or
        has_contains("lora_down") or has_contains("lora_up")
    ):
        architecture = "lora"
        architecture_label = "LoRA"
        confidence = "high"
        workflow = "adapter"
        recommendation = "Это LoRA-адаптер. Его нужно подключать к совместимой базовой модели, а не регистрировать как самостоятельный SDXL checkpoint."
    elif (
        "model.diffusion_model.input_blocks.0.0.weight" in keyset and
        has("conditioner.embedders.0.transformer.text_model.") and
        has("conditioner.embedders.1.model.")
    ):
        architecture = "sdxl_checkpoint"
        architecture_label = "SDXL checkpoint"
        confidence = "high"
        workflow = "sdxl"
        register_supported = folder_id == "checkpoints"
        recommendation = "Совместим с LocalGen SDXL workflow. Можно создать пользовательский профиль и затем настроить Steps / CFG / sampler."
    elif has("double_blocks.") and "img_in.weight" in keyset and "txt_in.weight" in keyset:
        architecture = "flux"
        architecture_label = "FLUX / FLUX.2 diffusion model"
        confidence = "high"
        workflow = "flux"
        recommendation = "Это отдельная transformer-архитектура. Нужны совместимые text encoder/VAE и FLUX workflow; как SDXL checkpoint регистрировать нельзя."
    elif has("transformer_blocks.") and "img_in.weight" in keyset and has("txt_in.") and has("time_text_embed."):
        architecture = "qwen_image"
        architecture_label = "Qwen-Image diffusion model"
        confidence = "high"
        workflow = "qwen"
        recommendation = "Это Qwen-Image. Нужен Qwen workflow с отдельными encoder/VAE; SDXL-регистрация не подходит."
    elif has("blocks.0.attn.") and has("blocks.0.mlp."):
        architecture = "transformer_diffusion"
        architecture_label = "Transformer diffusion model"
        confidence = "medium"
        workflow = "specialized"
        recommendation = "Файл похож на отдельный diffusion-transformer. Для него нужен архитектурно совместимый workflow и encoders/VAE."
    elif suffix == ".gguf":
        architecture = "gguf"
        architecture_label = "GGUF model"
        confidence = "medium"
        workflow = "specialized"
        recommendation = "GGUF С‚СЂРµР±СѓРµС‚ loader/workflow СЃРІРѕРµР№ Р°СЂС…РёС‚РµРєС‚СѓСЂС‹. РРјСЏ С„Р°Р№Р»Р° РїРѕРјРѕРіР°РµС‚ РѕРїСЂРµРґРµР»РёС‚СЊ СЃРµРјРµР№СЃС‚РІРѕ, РЅРѕ РµРіРѕ РЅРµР»СЊР·СЏ СЃС‡РёС‚Р°С‚СЊ SDXL checkpoint."
    elif suffix in {".pt", ".pth"} and folder_id == "upscale_models":
        architecture = "upscaler"
        architecture_label = "Upscale model"
        confidence = "medium"
        workflow = "upscale"
        recommendation = "Модель увеличения изображения. Она используется в Enhance/Delivery, а не в Create как diffusion checkpoint."

    if registered_models and architecture in {"unknown", "transformer_diffusion", "gguf"}:
        family = str(registered_models[0].get("family") or "").strip()
        workflow = str(registered_models[0].get("workflow") or registered_models[0].get("profile") or "")
        if family:
            architecture = family
            architecture_label = {
                "krea2": "Krea 2 diffusion model",
                "flux2": "FLUX.2 diffusion model",
                "qwen": "Qwen-Image diffusion model",
                "wan22": "Wan 2.2 video model",
            }.get(family, family)
            confidence = "high"
            recommendation = "Файл уже подключён к LocalGen через проверенный production profile."

    lower_name = filename.lower()
    defaults = {
        "steps": 30, "cfg": 5.0, "sampler": "dpmpp_2m", "scheduler": "karras",
        "clip_skip": 1, "prediction": "eps", "zsnr": False,
        "hires_scale": 1.15, "hires_steps": 6, "hires_denoise": 0.22,
        "negative": "",
    }
    known_sdxl = next((x for x in registered_models if str(x.get("workflow") or "") == "sdxl"), None)
    if known_sdxl:
        expert = _model_expert_info(known_sdxl).get("defaults") or {}
        for key in list(defaults):
            if key in expert:
                defaults[key] = expert[key]
    elif architecture == "sdxl_checkpoint":
        if "noob" in lower_name or "vpred" in lower_name or "v-pred" in lower_name:
            defaults.update({"steps": 30, "cfg": 5.0, "sampler": "euler", "scheduler": "normal", "clip_skip": 2, "prediction": "v_prediction", "zsnr": True})
        elif "animagine" in lower_name:
            defaults.update({"steps": 28, "cfg": 5.0, "sampler": "euler_ancestral", "scheduler": "normal", "clip_skip": 1, "prediction": "eps", "zsnr": False})

    if suffix == ".safetensors":
        safety = "safe"
        safety_label = "Safetensors · без Python pickle"
        safety_note = "Предпочтительный контейнер весов. Заголовок читается без загрузки модели в память."
    elif suffix == ".gguf":
        safety = "safe_container"
        safety_label = "GGUF · бинарный контейнер"
        safety_note = "Не является Python pickle, но всё равно используй модели из доверенного источника."
    else:
        safety = "caution"
        safety_label = "Осторожно · pickle-based формат"
        safety_note = "CKPT/PT/PTH могут использовать Python pickle. Загружай такие файлы только из доверенного источника; safetensors предпочтительнее."

    registration_options: list[dict[str, str]] = []
    recommended_settings: dict[str, Any] = {}
    if header_error:
        architecture = "invalid_safetensors"
        architecture_label = "Safetensors повреждён или не распознан"
        confidence = "high"
        register_supported = False
        recommendation = "Не подключай этот файл до повторной загрузки или проверки источника."
    else:
        if architecture == "sdxl_checkpoint" and folder_id == "checkpoints":
            registration_options.append({"family": "sdxl", "label": "SDXL", "folder": "checkpoints"})
            recommended_settings = dict(defaults)
        compatible_targets = _compatible_custom_targets(folder_id, path)
        registration_options.extend(compatible_targets)
        if compatible_targets:
            target = compatible_targets[0]
            family = str(target["family"])
            spec = CUSTOM_WORKFLOW_BASES[family]
            base_model = MODEL_REGISTRY[spec["model_id"]]
            recommended_settings = dict(_model_expert_info(base_model).get("defaults") or {})
            architecture = {"krea2": "krea2", "flux2": "flux2", "qwen21": "qwen_image"}.get(family, architecture)
            architecture_label = f"{target['label']} · совместимая структура"
            workflow = str(base_model.get("workflow") or base_model.get("profile") or family)
            confidence = "high"
            recommendation = (
                f"Структура tensor keys и shapes совпадает с проверенным production workflow {target['label']}. "
                "LocalGen может использовать этот файл с уже установленными совместимыми encoder/VAE."
            )
        register_supported = bool(registration_options)

    used_names = [str(MODEL_REGISTRY[x].get("name") or x) for x in refs if x in MODEL_REGISTRY]
    return {
        "name": filename,
        "path": str(path),
        "folder": folder_id,
        "bytes": stat.st_size,
        "size_gb": round(stat.st_size / 1024**3, 3),
        "format": suffix.lstrip(".") or "unknown",
        "safety": safety,
        "safety_label": safety_label,
        "safety_note": safety_note,
        "architecture": architecture,
        "architecture_label": architecture_label,
        "confidence": confidence,
        "workflow": workflow,
        "register_supported": bool(register_supported),
        "registration_options": registration_options,
        "register_reason": recommendation,
        "registered": bool(refs),
        "used_by": refs,
        "used_by_names": used_names,
        "header_bytes": header_bytes,
        "tensor_key_count": len(keys),
        "header_error": header_error,
        "metadata": _compact_model_metadata(metadata),
        "suggested_name": _suggest_model_name(path, metadata),
        "recommended_settings": recommended_settings,
    }

def register_custom_sdxl_profile(name: str, checkpoint: str, settings: dict[str, Any] | None = None) -> dict[str, Any]:
    clean_name = re.sub(r"\s+", " ", str(name or "").strip())
    if not clean_name or len(clean_name) > 80:
        raise ValueError("Название модели должно содержать 1–80 символов")
    checkpoint_name = Path(str(checkpoint or "")).name
    path = ROOT / "Models" / "checkpoints" / checkpoint_name
    if not checkpoint_name or not path.is_file() or path.suffix.lower() not in {".safetensors", ".ckpt"}:
        raise ValueError("Выбери существующий SDXL checkpoint из папки Models\\checkpoints")
    if path.suffix.lower() == ".safetensors":
        inspection = inspect_model_file("checkpoints", checkpoint_name)
        if inspection.get("architecture") != "sdxl_checkpoint":
            label = str(inspection.get("architecture_label") or "другая архитектура")
            raise ValueError(f"Этот файл определён как {label}, а не SDXL checkpoint. LocalGen не будет подключать его через неправильный workflow.")
    cfg = dict(settings or {})
    sampler = str(cfg.get("sampler") or "dpmpp_2m")
    scheduler = str(cfg.get("scheduler") or "karras")
    prediction = str(cfg.get("prediction") or "eps")
    if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS or prediction not in {"eps", "v_prediction"}:
        raise ValueError("Неподдерживаемые sampler/scheduler/prediction")
    record = {
        "id": "custom_sdxl_" + uuid.uuid4().hex[:12],
        "name": clean_name,
        "checkpoint": checkpoint_name,
        "steps": _checked_int(cfg.get("steps"), name="Steps", default=30, low=1, high=80),
        "cfg": _checked_float(cfg.get("cfg"), name="CFG", default=5.0, low=0.1, high=20),
        "sampler": sampler,
        "scheduler": scheduler,
        "clip_skip": _checked_int(cfg.get("clip_skip"), name="CLIP skip", default=1, low=1, high=4),
        "prediction": prediction,
        "zsnr": bool(cfg.get("zsnr", False)),
        "negative": str(cfg.get("negative") or "")[:5000],
        "best_for": str(cfg.get("best_for") or "")[:300],
        "description": str(cfg.get("description") or "")[:1000],
        "hires_scale": _checked_float(cfg.get("hires_scale"), name="Hires scale", default=1.15, low=1.0, high=1.6),
        "hires_steps": _checked_int(cfg.get("hires_steps"), name="Hires steps", default=6, low=1, high=40),
        "hires_denoise": _checked_float(cfg.get("hires_denoise"), name="Hires denoise", default=0.22, low=0.05, high=0.6),
        "created_at": int(time.time()),
    }
    with _CUSTOM_MODEL_LOCK:
        records = _read_custom_model_records()
        records.append(record)
        _write_custom_model_records(records)
        MODEL_REGISTRY[record["id"]] = _custom_sdxl_registry_item(record)
    return record


def register_custom_diffusion_profile(
    name: str,
    folder: str,
    model_file: str,
    family: str,
    settings: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clean_name = re.sub(r"\s+", " ", str(name or "").strip())
    if not clean_name or len(clean_name) > 80:
        raise ValueError("Название модели должно содержать 1–80 символов")
    family_id = str(family or "").strip().lower()
    spec = CUSTOM_WORKFLOW_BASES.get(family_id)
    if spec is None:
        raise ValueError("Этот тип пользовательской модели пока не поддерживается")
    folder_id = str(folder or "")
    if folder_id != spec["folder"]:
        raise ValueError(f"Для {spec['label']} файл должен находиться в Models\\{spec['folder']}")
    filename = Path(str(model_file or "")).name
    path = MODEL_STORAGE_FOLDERS[folder_id] / filename
    if not filename or not path.is_file() or path.suffix.lower() != ".safetensors":
        raise ValueError("Выбери существующий .safetensors diffusion model")
    inspection = inspect_model_file(folder_id, filename)
    options = inspection.get("registration_options") or []
    if family_id not in {str(x.get("family") or "") for x in options if isinstance(x, dict)}:
        raise ValueError(
            f"Структура {filename} не совпадает с проверенным workflow {spec['label']}. "
            "LocalGen не будет подключать несовместимые веса."
        )
    base = MODEL_REGISTRY[spec["model_id"]]
    expert_info = _model_expert_info(base)
    defaults = dict(expert_info.get("defaults") or {})
    editable = set(expert_info.get("editable") or [])
    cfg = dict(settings or {})
    sampler = str(cfg.get("sampler") or defaults.get("sampler") or "euler")
    if sampler not in EXPERT_SAMPLERS:
        raise ValueError("Неподдерживаемый sampler")
    record: dict[str, Any] = {
        "id": f"custom_{family_id}_" + uuid.uuid4().hex[:12],
        "family": family_id,
        "name": clean_name,
        "folder": folder_id,
        "model_file": filename,
        "steps": _checked_int(cfg.get("steps"), name="Steps", default=int(defaults.get("steps", 8)), low=1, high=80),
        "cfg": _checked_float(cfg.get("cfg"), name="CFG", default=float(defaults.get("cfg", 1.0)), low=0.1, high=20),
        "sampler": sampler,
        "best_for": str(cfg.get("best_for") or "")[:300],
        "description": str(cfg.get("description") or "")[:1000],
        "created_at": int(time.time()),
    }
    if "scheduler" in editable:
        scheduler = str(cfg.get("scheduler") or defaults.get("scheduler") or "simple")
        if scheduler not in EXPERT_SCHEDULERS:
            raise ValueError("Неподдерживаемый scheduler")
        record["scheduler"] = scheduler
    with _CUSTOM_MODEL_LOCK:
        records = _read_custom_model_records()
        records.append(record)
        _write_custom_model_records(records)
        MODEL_REGISTRY[record["id"]] = _custom_diffusion_registry_item(record)
    return record


def register_custom_model_profile(
    name: str,
    folder: str,
    model_file: str,
    family: str,
    settings: dict[str, Any] | None = None,
) -> dict[str, Any]:
    family_id = str(family or "").strip().lower()
    if family_id == "sdxl":
        if str(folder or "") != "checkpoints":
            raise ValueError("SDXL checkpoint должен находиться в Models\\checkpoints")
        return register_custom_sdxl_profile(name, model_file, settings)
    return register_custom_diffusion_profile(name, folder, model_file, family_id, settings)


def delete_custom_model_profile(model_id: str) -> bool:
    model_id = str(model_id or "")
    with _CUSTOM_MODEL_LOCK:
        records = _read_custom_model_records()
        kept = [x for x in records if str(x.get("id") or "") != model_id]
        if len(kept) == len(records):
            return False
        _write_custom_model_records(kept)
        MODEL_REGISTRY.pop(model_id, None)
    return True

def model_file_inventory() -> dict[str, Any]:
    folders = MODEL_STORAGE_FOLDERS
    registered: dict[str, list[str]] = {}
    for model_id, item in MODEL_REGISTRY.items():
        raw = item.get("installed")
        if raw:
            try: registered.setdefault(str(Path(raw).resolve()).lower(), []).append(model_id)
            except Exception: pass
    for name, path, _ in PRODUCTION_ASSETS:
        try: registered.setdefault(str(path.resolve()).lower(), []).append("asset:" + name)
        except Exception: pass
    items: list[dict[str, Any]] = []
    allowed = {".safetensors", ".ckpt", ".pt", ".pth", ".gguf"}
    for folder_id, folder in folders.items():
        folder.mkdir(parents=True, exist_ok=True)
        for path in folder.iterdir():
            if not path.is_file() or path.suffix.lower() not in allowed:
                continue
            key = str(path.resolve()).lower()
            refs = registered.get(key, [])
            items.append({
                "name": path.name,
                "folder": folder_id,
                "path": str(path),
                "bytes": path.stat().st_size,
                "size_gb": round(path.stat().st_size / 1024**3, 3),
                "registered": bool(refs),
                "used_by": refs,
            })
    items.sort(key=lambda x: (x["folder"], x["name"].lower()))
    return {
        "items": items,
        "total": len(items),
        "registered": sum(1 for x in items if x["registered"]),
        "unregistered": sum(1 for x in items if not x["registered"]),
        "custom_profiles": list_custom_model_profiles(),
        "folders": {k: str(v) for k, v in folders.items()},
    }

_load_custom_models_into_registry()

def detect_language(text: str) -> str:
    return "ru" if re.search(r"[А-Яа-яЁё]", text or "") else "en"
def translate_to_english(text: str) -> tuple[str, str]:
    if not text.strip() or detect_language(text) == "en":
        return text.strip(), "already_en"
    try:
        import argostranslate.translate
        installed = argostranslate.translate.get_installed_languages()
        src = next((x for x in installed if x.code == "ru"), None)
        dst = next((x for x in installed if x.code == "en"), None)
        if src and dst:
            translation = src.get_translation(dst)
            if translation:
                return translation.translate(text).strip(), "argos"
    except Exception:
        pass
    return text.strip(), "unavailable"

def recommend_create_model(text: str, prompt_style: str = "auto") -> dict[str, Any]:
    source = re.sub(r"\s+", " ", str(text or "").strip()).lower()
    style = str(prompt_style or "auto").strip().lower()
    adult = bool(re.search(
        r"(?:18\+)|\b(?:nsfw|nude|naked|topless|explicit|erotic|sexual|sex|porn|pornographic|lingerie|boudoir|sensual|seductive)\b"
        r"|(?:нижн\w*\s+бель\w*|будуар\w*|чувствен\w*|соблазн\w*|эрот\w*)"
        r"|(?:гол\w*|обнаж\w*|топлесс|эрот\w*|сексуаль\w*|секс\w*|порно\w*)",
        source, re.I,
    ))
    anime = style == "anime" or bool(re.search(
        r"\b(?:anime|manga|cel[- ]?shad\w*|2d anime|doujin)\b"
        r"|(?:аниме|манга)",
        source, re.I,
    ))
    people_source = re.sub(
        r"\b(?:no|not|without)\s+(?:people|persons?|subjects?|humans?)\b"
        r"|(?:\bбез\s+|\bне\s+)(?:люд\w*|человек\w*|персонаж\w*)",
        " ", source, flags=re.I,
    )
    people = bool(re.search(
        r"\b(?:woman|women|girl|female|man|men|boy|male|person|people|portrait|face|skin|fashion model|female model|male model|runway model)\b"
        r"|(?:девушк\w*|женщин\w*|парн\w*|мужчин\w*|человек\w*|люд\w*|портрет\w*|лиц\w*|кож\w*|фэшн[- ]?модел\w*|модель[- ]?девушк\w*|модель[- ]?парн\w*)",
        people_source, re.I,
    ))
    photo_source = re.sub(
        r"\b(?:no|not|without)\s+(?:photorealism|photorealistic|photoreal|realistic photo(?:graphy)?|photograph(?:y)?|photo)\b"
        r"|(?:\bбез\s+|\bне\s+)(?:фотореал\w*|реалистичн\w* фото\w*|фотографичн\w*|фото\w*)",
        " ", source, flags=re.I,
    )
    photo = style == "photo" or bool(re.search(
        r"\b(?:photo|photograph|photoreal\w*|realistic photo|camera shot)\b"
        r"|(?:фото\w*|фотореал\w*|реалистичн\w* сним\w*)",
        photo_source, re.I,
    ))
    product = style == "product" or bool(re.search(
        r"\b(?:product shot|packshot|product photography|wristwatch|watch product|sneaker|shoe product|bottle product|phone product|laptop product|camera product|jewelry product|car product)\b"
        r"|(?:предметн\w* съем\w*|предметн\w* съём\w*|наручн\w* час\w*|товарн\w* фото\w*|фото товар\w*)",
        source, re.I,
    ))
    creative = bool(re.search(
        r"\b(?:architecture|architectural|interior design|exterior design|gallery space|pavilion|art direction|concept art|conceptual scene|brutalist|installation art|set design|environment design|surreal environment|editorial scene|illustration|editorial illustration|book illustration|children'?s illustration|fantasy illustration|digital painting|watercolou?r|gouache|oil painting|painting|drawing|sketch|vector art|flat vector|surreal\w*|abstract art|collage art|paper cut|clay art|pixel art)\b"
        r"|(?:архитектур\w*|интерьер\w*|экстерьер\w*|павильон\w*|арт[- ]?дирекш\w*|концепт[- ]?арт\w*|брутализм\w*|инсталляц\w*|декорац\w*|дизайн пространств\w*|иллюстрац\w*|цифров\w* живопис\w*|акварел\w*|гуаш\w*|живопис\w*|рисунк\w*|скетч\w*|векторн\w*|сюрреал\w*|абстракт\w*|коллаж\w*)",
        source, re.I,
    ))
    editorial_photo = bool(re.search(
        r"\b(?:fashion editorial|editorial portrait|editorial photograph|editorial photography|fashion campaign|campaign photography|environmental portrait|magazine portrait|magazine photography)\b"
        r"|(?:редакцион\w* (?:портрет\w*|фото\w*|съем\w*|съём\w*)|фэшн[- ]?съем\w*|фэшн[- ]?съём\w*|модн\w* съем\w*|модн\w* съём\w*|журнальн\w* портрет\w*)",
        source, re.I,
    ))
    design = bool(re.search(
        r"\b(?:poster|banner|typography|lettering|flyer|brochure|logo|graphic design|social card|ad creative|infographic|packaging design|title card|headline|subtitle|visible text|text on image|magazine layout|editorial design|layout design|book cover|album cover|cover design|menu design)\b"
        r"|(?:постер\w*|баннер\w*|типограф\w*|надпис\w*|афиш\w*|логотип\w*|графическ\w* дизайн\w*|обложк\w*|инфограф\w*|визитк\w*|рекламн\w* макет\w*|журнальн\w* макет\w*|макет\w* журнал\w*|в[её]рстк\w*|заголов\w*|подзаголов\w*|текст\w* на (?:картинк\w*|изображен\w*))",
        source, re.I,
    ))
    anime_portrait = bool(re.search(
        r"\b(?:portrait|headshot|close[- ]?up|upper[- ]?body|bust portrait|waist[- ]?up|chest[- ]?up)\b"
        r"|(?:портрет\w*|крупн\w* план\w*|по пояс|верхн\w* част\w* тел\w*|бюст\w*)",
        source, re.I,
    ))
    anime_fullbody = bool(re.search(
        r"\b(?:full[- ]?body|full[- ]?length|head[- ]?to[- ]?toe|entire body|whole body)\b"
        r"|(?:в полн\w* рост\w*|полный рост|во весь рост|целиком\w* тел\w*)",
        source, re.I,
    ))

    def available(model_id: str) -> bool:
        item = MODEL_REGISTRY.get(model_id)
        return bool(item and item.get("kind") == "create" and _model_available(item))

    warning = ""
    confidence = "high"
    if adult and anime:
        if available("noobai_adult_anime"):
            model_id = "noobai_adult_anime"
            reason = "Запрос сочетает 18+ и anime, поэтому выбран специализированный adult-anime профиль."
        else:
            model_id = "krea2_adult"
            reason = "Запрос 18+ требует adult-профиль; специализированная 18+ anime модель сейчас не установлена."
            warning = "NoobAI XL V-Pred 1.0 пока недоступен, поэтому LocalGen использует adult-профиль Krea. Anime-стиль может быть слабее."
            confidence = "medium"
    elif adult:
        model_id = "krea2_adult"
        reason = "Обнаружен взрослый 18+ запрос, поэтому выбран профиль для adult-фотореала."
    elif design:
        model_id = "qwen21_design"
        reason = "Обнаружена задача с типографикой или графическим дизайном, поэтому выбран Qwen-Image-2.1."
    elif anime:
        if anime_portrait and not anime_fullbody and available("anima_portrait"):
            model_id = "anima_portrait"
            reason = "Anime portrait/upper-body направлен в Anima Turbo v1.1: controlled test показал более сложную одежду, фон и лицо при меньшем времени. Для full-body Animagine остаётся безопаснее."
        else:
            model_id = "animagine_anime"
            reason = "Обнаружен anime/illustration стиль; для общего или full-body anime выбран Animagine из-за лучшей буквальной устойчивости атрибутов."
    elif product:
        model_id = "krea2_general"
        reason = "Точная предметная или объектная сцена лучше подходит Krea 2: controlled tests показали выше буквальную геометрию, чем Chroma."
    elif creative and not people:
        model_id = "chroma1_hd"
        reason = "Архитектурная/концептуальная/иллюстративная сцена без людей направлена в Chroma1-HD: он сильнее в арт-дирекшне, пространстве и editorial-композиции."
    elif creative:
        model_id = "krea2_general"
        reason = "Обычная иллюстрация с людьми не считается anime автоматически. Пока отдельный human-illustration specialist не прошёл controlled test, используется универсальный Krea 2 вместо фотопрофиля Juggernaut."
    elif editorial_photo and available("zimage_turbo_q5"):
        model_id = "zimage_turbo_q5"
        reason = "Editorial/fashion/environmental photo направлено в Z-Image Turbo Q5: controlled tests показали более выразительную композицию, натуральную микротекстуру и богатое окружение."
    elif people:
        model_id = "sdxl_people"
        reason = "Обнаружен человек или портрет без более узкой ниши, поэтому выбран Juggernaut XL v9."
    elif photo:
        model_id = "krea2_general"
        reason = "Обнаружена фотореалистичная сцена без людей; универсальный Krea 2 безопаснее people-specialist Juggernaut для пейзажей, объектов и окружения."
    else:
        model_id = "krea2_general"
        reason = "Явной узкой ниши не найдено, поэтому выбран универсальный Krea 2 Turbo."
        confidence = "medium"

    if not available(model_id):
        fallbacks = ["sdxl_people", "krea2_general", "flux2_fast"]
        fallback = next((x for x in fallbacks if available(x)), "")
        if fallback:
            warning = (warning + " " if warning else "") + f"Основная рекомендация недоступна, используется {MODEL_REGISTRY[fallback]['name']}."
            model_id = fallback
            confidence = "low"
        else:
            raise RuntimeError("Нет доступной модели Create.")

    item = MODEL_REGISTRY[model_id]
    alternatives = [
        {"id": mid, "name": data.get("name", mid)}
        for mid, data in MODEL_REGISTRY.items()
        if mid != model_id and data.get("kind") == "create" and data.get("workflow") != "character_scene" and _model_available(data)
    ][:3]
    return {
        "model_id": model_id,
        "model_name": item.get("name", model_id),
        "reason": reason,
        "warning": warning,
        "confidence": confidence,
        "detected": {"adult": adult, "anime": anime, "people": people, "photo": photo, "product": product, "creative": creative, "editorial_photo": editorial_photo, "design": design},
        "alternatives": alternatives,
    }

_MULTI_PANEL_RE = re.compile(
    r"(?:\b(?:collage|diptych|triptych|split[- ]?screen|contact sheet|storyboard|comic panels?|multi[- ]?panel"
    r"|multiple panels?|multiple views?|several views?|comparison layout|before\s*(?:and|&)\s*after"
    r"|front\s*(?:and|&)\s*(?:side|back)\s*views?|grid of (?:photos|images|shots))\b"
    r"|(?:коллаж|диптих|триптих|сплит[- ]?скрин|раскадровк\w*|комикс\w* панел\w*"
    r"|нескольк\w* (?:кадр\w*|фото\w*|изображен\w*|ракурс\w*)|сетк\w* из (?:фото\w*|изображен\w*)"
    r"|до\s*(?:и|/)\s*после|вид\w* спереди и (?:сбоку|сзади)))",
    re.I,
)

_SINGLE_FRAME_CREATE_MODELS = {
    "sdxl_people", "animagine_anime", "noobai_adult_anime",
    "flux2_fast", "qwen21_design", "qwen21_character",
}

def _requests_multi_panel(text: str) -> bool:
    return bool(_MULTI_PANEL_RE.search(str(text or "")))

def _looks_like_design_request(text: str) -> bool:
    return bool(re.search(
        r"\b(?:poster|banner|typography|lettering|flyer|brochure|logo|graphic design|social card|ad creative"
        r"|infographic|packaging design|album cover|book cover|menu design|label design)\b"
        r"|(?:постер\w*|баннер\w*|типограф\w*|надпис\w*|афиш\w*|логотип\w*"
        r"|графическ\w* дизайн\w*|обложк\w*|инфографик\w*|упаковк\w*|этикетк\w*)",
        str(text or ""), re.I,
    ))

def _single_frame_guard(text: str, model_id: str) -> str:
    if _requests_multi_panel(text):
        return ""
    if model_id not in _SINGLE_FRAME_CREATE_MODELS and not model_id.startswith("krea2"):
        return ""
    if model_id in {"animagine_anime", "noobai_adult_anime"}:
        return "single image, single panel, one scene, one camera view"
    return "single continuous image, one coherent scene, one camera view, single-frame composition"

_SINGLE_PERSON_RE = re.compile(
    r"\b(?:1girl|1boy|(?:a|an|one)\s+(?:young\s+)?(?:adult\s+)?(?:woman|man|person|female|male|girl|boy)"
    r"|(?:young\s+)?(?:adult\s+)?(?:woman|man|person|female))\b"
    r"|\b(?:девушка|женщина|парень|мужчина|человек)\b",
    re.I,
)
_MULTI_PERSON_RE = re.compile(
    r"\b(?:two|three|four|couple|pair|group|crowd|people|women|men|girls|boys|friends|twins|family"
    r"|team|multiple people|several people)\b"
    r"|\b(?:две|два|три|четыре|пара|группа|толпа|люди|несколько|двое|трое|подруги|друзья|близнецы|семья)\b",
    re.I,
)

def _single_person_guard(text: str, model_id: str) -> str:
    source = str(text or "")
    intent = re.sub(
        r"\b(?:no|not|without)\s+(?:(?:duplicate|multiple|repeated|cloned)\s+)?(?:people|persons?|subjects?)\b",
        " ", source, flags=re.I,
    )
    if _requests_multi_panel(intent) or _MULTI_PERSON_RE.search(intent) or not _SINGLE_PERSON_RE.search(intent):
        return ""
    if model_id not in _SINGLE_FRAME_CREATE_MODELS and not model_id.startswith("krea2"):
        return ""
    if model_id in {"animagine_anime", "noobai_adult_anime"}:
        return "solo, exactly one person, no clones, no duplicate person"
    return "exactly one person, one subject only, no duplicate people, no repeated subject"

def enhance_prompt(text: str, *, model_id: str, light: bool = False) -> str:
    clean = re.sub(r"\s+", " ", text.strip()).strip(" ,;.")
    if not clean:
        return ""
    low = clean.lower()
    prefixes: list[str] = []
    additions: list[str] = []
    suffixes: list[str] = []
    if model_id.startswith("krea2"):
        # Krea 2 works best with clear natural-language intent. Do not force
        # photographic/anatomy vocabulary into products, paintings or 3D art.
        people_intent = bool(re.search(
            r"\b(?:woman|women|girl|female|man|men|boy|male|person|people|portrait|face|skin|fashion model)\b"
            r"|(?:девушк\w*|женщин\w*|парн\w*|мужчин\w*|человек\w*|люд\w*|портрет\w*|лиц\w*|кож\w*)",
            clean, re.I,
        ))
        product_intent = bool(re.search(
            r"\b(?:product(?: shot| photo| photography)?|packshot|wristwatch|watch product|sneaker|shoe product"
            r"|bottle product|phone product|laptop product|camera product|jewelry product|car product)\b"
            r"|(?:предметн\w* (?:съем\w*|съём\w*)|наручн\w* час\w*|товарн\w* фото\w*|фото товар\w*)",
            clean, re.I,
        ))
        photo_intent = bool(re.search(
            r"\b(?:photo|photograph|photoreal\w*|realistic photo|camera shot|dslr|film photo|35mm|50mm|85mm)\b"
            r"|(?:фото\w*|фотореал\w*|реалистичн\w* сним\w*)",
            clean, re.I,
        ))
        art_intent = bool(re.search(
            r"\b(?:illustration|anime|manga|drawing|painting|watercolou?r|oil painting|gouache|sketch"
            r"|vector art|pixel art|3d render|cgi|clay render|digital art|concept art)\b"
            r"|(?:иллюстрац\w*|аниме|манга|рисунк\w*|живопис\w*|акварел\w*|гуаш\w*|скетч\w*"
            r"|векторн\w*|пиксельн\w*|3d[- ]?рендер\w*|цифров\w* искусств\w*)",
            clean, re.I,
        ))
        has_lighting = bool(re.search(r"\b(?:light|lighting|lit|sunlight|daylight|studio light)\b|(?:свет\w*|освещ\w*)", clean, re.I))
        has_camera = bool(re.search(r"\b(?:camera|lens|\d{2,3}mm|close-up|wide shot|medium shot|depth of field)\b|(?:камер\w*|объектив\w*|крупн\w* план\w*)", clean, re.I))

        if product_intent:
            if not light:
                additions.extend(["precise object geometry", "coherent materials and proportions", "clean product structure"])
            if photo_intent and not has_lighting:
                additions.append("controlled studio lighting")
            if photo_intent and not has_camera:
                additions.append("realistic product photography perspective")
        elif people_intent:
            if photo_intent:
                if not has_lighting:
                    additions.append("natural photographic lighting")
                if not has_camera:
                    additions.append("realistic camera perspective")
                if not light:
                    additions.extend(["natural skin texture", "coherent anatomy and facial features", "fine facial detail"])
            elif not light:
                additions.extend(["coherent anatomy and facial features", "consistent proportions", "high detail"])
        elif art_intent:
            if not light:
                additions.extend(["coherent composition", "deliberate shapes and materials", "high detail"])
        else:
            if photo_intent:
                if not has_lighting:
                    additions.append("natural photographic lighting")
                if not has_camera:
                    additions.append("realistic camera perspective")
            if not light:
                additions.extend(["coherent composition", "natural material detail", "high detail"])
    elif model_id == "sdxl_people":
        stylized_intent = bool(re.search(
            r"\b(?:anime|manga|illustration|drawing|painting|watercolou?r|gouache|oil painting|sketch|vector art|pixel art|3d render|cgi|clay render)\b"
            r"|(?:аниме|манга|иллюстрац\w*|рисунк\w*|живопис\w*|акварел\w*|гуаш\w*|скетч\w*|векторн\w*|пиксельн\w*|3d[- ]?рендер\w*)",
            clean, re.I,
        ))
        negated_photo = bool(re.search(
            r"\b(?:no|not|without)\s+(?:photorealism|photorealistic|photoreal|realistic photo(?:graphy)?|photograph(?:y)?|photo)\b"
            r"|(?:\bбез\s+|\bне\s+)(?:фотореал\w*|реалистичн\w* фото\w*|фотографичн\w*|фото\w*)",
            clean, re.I,
        ))
        photo_intent = not stylized_intent and not negated_photo
        if photo_intent:
            if not any(x in low for x in ("photo", "photograph", "photoreal")):
                additions.append("photorealistic photograph")
            if "skin" not in low:
                additions.append("natural skin texture")
            if "light" not in low and "lighting" not in low:
                additions.append("natural photographic lighting")
            if not light:
                additions.extend(["realistic anatomy", "fine facial detail", "high detail"])
        elif not light:
            additions.extend(["coherent anatomy and facial features", "consistent proportions"])
    elif model_id == "anima_portrait":
        # Anima is trained on both tags and natural-language captions.
        # Keep the user's semantic content intact and only add the official quality/safety prefix.
        prefixes.extend(["masterpiece", "best quality", "score_7", "safe"])
        if re.search(r"\b(?:woman|female|girl)\b", low) and "1girl" not in low:
            prefixes.append("1girl")
        if re.search(r"\b(?:man|male|boy)\b", low) and "1boy" not in low:
            prefixes.append("1boy")
        if not any(x in low for x in ("anime", "illustration", "manga", "drawing", "artwork")):
            additions.append("anime illustration")
        if not light:
            additions.extend(["detailed clothing", "coherent background", "clean anatomy"])
    elif model_id in ("animagine_anime", "noobai_adult_anime"):
        # These checkpoints use different caption ordering conventions.
        # Animagine 4.0 expects subject/content first and quality tags at the end;
        # NoobAI V-Pred uses its quality tags as a prompt prefix.
        if model_id == "animagine_anime":
            suffixes.extend(["masterpiece", "high score", "great score", "absurdres"])
        else:
            prefixes.extend(["masterpiece", "best quality", "newest", "absurdres", "highres"])
        if re.search(r"\b(?:woman|female|girl)\b", low) and "1girl" not in low:
            prefixes.append("1girl")
        if re.search(r"\b(?:man|male|boy)\b", low) and "1boy" not in low:
            prefixes.append("1boy")
        if any(x in low for x in ("head-to-toe", "full-length", "entire subject visible")) and "full body" not in low:
            prefixes.append("full body")
        if not any(x in low for x in ("anime", "illustration", "manga", "drawing", "artwork")):
            additions.append("anime illustration")
        additions.append("clean linework")
        if not light:
            additions.extend(["high detail", "coherent anatomy"])
    elif model_id == "flux2_fast":
        if re.search(
            r"\b(?:vector|flat graphic|flat illustration|logo|icon|pixel art|diagram)\b"
            r"|(?:вектор\w*|плоск\w* график\w*|логотип\w*|иконк\w*|пиксельн\w*|диаграмм\w*)",
            clean, re.I,
        ):
            additions.extend(["clean composition", "crisp shape relationships"])
        else:
            additions.extend(["clean composition", "coherent subject relationships"])
    elif model_id == "zimage_turbo_q5":
        # Z-Image Turbo prefers detailed natural-language prompts. Keep enrichment
        # task-specific: generic "editorial" must not imply a human/photo prompt.
        photo_text = re.sub(
            r"\b(?:no|not|without)\s+(?:photorealism|photorealistic|photoreal|realistic photo(?:graphy)?|photograph(?:y)?)\b",
            " ", clean, flags=re.I,
        )
        photo_text = re.sub(
            r"(?:\bне\s+|\bбез\s+)(?:фотореал\w*|реалистичн\w* фото\w*|фотографичн\w*)",
            " ", photo_text, flags=re.I,
        )
        people_intent = bool(re.search(
            r"\b(?:woman|women|girl|female|man|men|boy|male|person|people|portrait|face|skin|fashion model)\b"
            r"|(?:девушк\w*|женщин\w*|парн\w*|мужчин\w*|человек\w*|люд\w*|портрет\w*|лиц\w*|кож\w*|модел\w*)",
            clean, re.I,
        ))
        product_intent = bool(re.search(
            r"\b(?:product(?: shot| photo| photography)?|packshot|wristwatch|watch product|sneaker|shoe product|"
            r"bottle product|phone product|laptop product|camera product|jewelry product|car product)\b"
            r"|(?:предметн\w* (?:съем\w*|съём\w*)|наручн\w* час\w*|товарн\w* фото\w*|фото товар\w*)",
            clean, re.I,
        ))
        architecture_intent = bool(re.search(
            r"\b(?:architecture|architectural|interior|exterior|building|facade|pavilion|museum|gallery|room|house|hotel|urban space)\b"
            r"|(?:архитектур\w*|интерьер\w*|экстерьер\w*|здани\w*|фасад\w*|павильон\w*|музе\w*|галере\w*)",
            clean, re.I,
        ))
        stylized_intent = bool(re.search(
            r"\b(?:anime|manga|illustration|drawing|painting|watercolou?r|gouache|oil painting|sketch|"
            r"vector art|flat vector|pixel art|surreal\w*|abstract|collage art|paper cut|clay art)\b"
            r"|(?:аниме|манга|иллюстрац\w*|рисунк\w*|живопис\w*|акварел\w*|гуаш\w*|скетч\w*|"
            r"векторн\w*|пиксельн\w*|сюрреал\w*|абстракт\w*)",
            clean, re.I,
        ))
        photo_intent = bool(re.search(
            r"\b(?:photo|photograph|photoreal\w*|realistic photo|camera shot|dslr|35mm|50mm|85mm|"
            r"campaign photography|environmental portrait|fashion photography|editorial photo(?:graphy)?|editorial portrait)\b"
            r"|(?:фото\w*|фотореал\w*|реалистичн\w* сним\w*|редакцион\w* (?:съем\w*|съём\w*)|"
            r"фэшн[- ]?(?:съем\w*|съём\w*))",
            photo_text, re.I,
        ))
        if product_intent:
            additions.extend(["precise object geometry", "coherent materials and proportions", "clean product structure"])
            if photo_intent:
                additions.append("controlled product lighting")
        elif people_intent:
            additions.append("coherent anatomy and hands")
            if photo_intent:
                additions.extend(["natural skin texture", "realistic lighting and perspective"])
            elif not light:
                additions.append("consistent proportions")
        elif architecture_intent:
            additions.extend(["coherent spatial geometry", "consistent perspective"])
            if photo_intent:
                additions.extend(["realistic lighting", "coherent material detail"])
        elif stylized_intent:
            additions.extend(["coherent composition", "intentional color relationships"])
            if not light:
                additions.append("clear focal hierarchy")
        elif photo_intent:
            additions.extend(["realistic lighting and perspective", "coherent scene detail"])
        elif not light:
            additions.extend(["coherent composition", "clear subject relationships"])
    elif model_id == "chroma1_hd":
        architecture_intent = bool(re.search(
            r"\b(?:architecture|architectural|interior|exterior|building|facade|pavilion|museum|gallery|room|house|hotel|restaurant|urban space)\b"
            r"|(?:архитектур\w*|интерьер\w*|экстерьер\w*|здани\w*|фасад\w*|павильон\w*|музе\w*|галере\w*)",
            clean, re.I,
        ))
        photo_intent_text = re.sub(
            r"\b(?:no|not|without)\s+(?:photorealism|photorealistic|photoreal|realistic photo(?:graphy)?|photograph(?:y)?)\b",
            " ", clean, flags=re.I,
        )
        photo_intent_text = re.sub(
            r"(?:\bне\s+|\bбез\s+)(?:фотореал\w*|реалистичн\w* фото\w*|фотографичн\w*)",
            " ", photo_intent_text, flags=re.I,
        )
        photo_editorial_intent = bool(re.search(
            r"\b(?:photo|photograph|photoreal\w*|editorial|fashion campaign|campaign photography|studio photograph|camera shot)\b"
            r"|(?:фото\w*|фотореал\w*|редакцион\w*|фэшн\w* съем\w*|фэшн\w* съём\w*)",
            photo_intent_text, re.I,
        ))
        vector_intent = bool(re.search(
            r"\b(?:vector|flat graphic|flat illustration|logo|icon|poster design|geometric graphic|silkscreen)\b"
            r"|(?:вектор\w*|плоск\w* график\w*|логотип\w*|иконк\w*|постер\w*|геометрическ\w* график\w*)",
            clean, re.I,
        ))
        stylized_intent = bool(re.search(
            r"\b(?:watercolou?r|gouache|oil painting|painting|ink drawing|sketch|illustration|surreal\w*|dreamlike|neon dreamscape|abstract|collage art|paper cut|clay art|pixel art)\b"
            r"|(?:акварел\w*|гуаш\w*|живопис\w*|рисунк\w*|скетч\w*|иллюстрац\w*|сюрреал\w*|абстракт\w*|неон\w*)",
            clean, re.I,
        ))
        has_lighting = bool(re.search(
            r"\b(?:light|lighting|lit|sunlight|daylight|night|neon|backlit|rim light|studio light|artificial lighting)\b"
            r"|(?:свет\w*|освещ\w*|неон\w*|ночн\w*|подсвет\w*)",
            clean, re.I,
        ))
        if architecture_intent:
            additions.extend(["coherent spatial composition", "refined geometry", "physically plausible materials"])
            if not has_lighting:
                additions.append("controlled architectural lighting")
            if not light:
                additions.extend(["subtle material texture", "balanced negative space"])
        elif photo_editorial_intent:
            additions.extend(["editorial art direction", "coherent composition", "realistic perspective"])
            if not has_lighting:
                additions.append("controlled photographic lighting")
            if not light:
                additions.extend(["natural material detail", "balanced negative space"])
        elif vector_intent:
            additions.extend(["clear visual hierarchy", "clean shape relationships", "crisp edges"])
            if not light:
                additions.append("balanced negative space")
        elif stylized_intent:
            additions.extend(["coherent composition", "intentional color relationships"])
            if not light:
                additions.extend(["deliberate texture handling", "clear focal hierarchy"])
        else:
            additions.extend(["coherent composition", "clear focal hierarchy"])
            if not light:
                additions.append("balanced negative space")
    elif model_id == "qwen21_design":
        if _looks_like_design_request(clean):
            additions.extend(["professional graphic design", "strong visual hierarchy", "precise alignment", "clean typography", "balanced spacing"])
            if not light:
                additions.extend(["polished commercial art direction", "crisp readable text", "coherent color system"])
        else:
            photo_text = re.sub(
                r"\b(?:no|not|without)\s+(?:photorealism|photorealistic|photoreal|realistic photo(?:graphy)?|photograph(?:y)?|photo)\b"
                r"|(?:\bбез\s+|\bне\s+)(?:фотореал\w*|реалистичн\w* фото\w*|фотографичн\w*|фото\w*)",
                " ", clean, flags=re.I,
            )
            photo_intent = bool(re.search(
                r"\b(?:photo|photograph|photoreal\w*|portrait photo|camera shot|dslr|35mm|50mm|85mm)\b"
                r"|(?:фото\w*|фотореал\w*|реалистичн\w* сним\w*|портретн\w* фото\w*|камер\w*|объектив\w*)",
                photo_text, re.I,
            ))
            if photo_intent:
                additions.extend(["photorealistic image", "natural photographic lighting", "high detail"])
            elif not light:
                additions.extend(["high detail", "coherent scene"])
    elif model_id == "qwen21_character":
        additions.extend(["same recognizable subject identity", "coherent anatomy and proportions", "high detail", "follow the requested new scene precisely"])
    elif model_id in {"qwen21_edit", "qwen21_adult_edit"}:
        additions.extend(["follow the edit instruction precisely", "preserve unrequested identity, composition, lighting and background details"])
        if model_id == "qwen21_adult_edit":
            additions.extend(["coherent adult anatomy and proportions", "preserve the requested adult-only body and clothing state"])
    elif model_id == "flux2_exact":
        photo_intent = bool(re.search(
            r"\b(?:photo|photograph|photoreal\w*|camera shot|dslr|35mm|50mm|85mm)\b"
            r"|(?:фото\w*|фотореал\w*|реалистичн\w* сним\w*|камер\w*|объектив\w*)",
            clean, re.I,
        ))
        additions.append("photorealistic local edit" if photo_intent else "precise local edit")
        additions.extend(["preserve the original rendering medium and unrequested composition", "match surrounding lighting, texture, perspective and color"])
    elif model_id.startswith("wan22"):
        additions.extend(["natural continuous motion", "stable subject identity", "coherent anatomy", "consistent lighting", "temporal consistency"])
    guard = _single_frame_guard(clean, model_id)
    if guard and guard.lower() not in low:
        additions.append(guard)
    subject_guard = _single_person_guard(clean, model_id)
    if subject_guard and subject_guard.lower() not in low:
        additions.append(subject_guard)
    return ", ".join([
        *[x for x in prefixes if x.lower() not in low],
        clean,
        *[x for x in additions if x.lower() not in low],
        *[x for x in suffixes if x.lower() not in low],
    ])

def _visible_text_fragments(text: str) -> list[str]:
    fragments: list[str] = []
    pattern = re.compile(r'"([^"\n]{1,300})"|«([^»\n]{1,300})»|“([^”\n]{1,300})”')
    for match in pattern.finditer(text or ""):
        value = next((g for g in match.groups() if g is not None), "").strip()
        if value:
            fragments.append(value)
    return fragments

def _restore_visible_text_after_translation(original: str, translated: str) -> tuple[str, list[str]]:
    fragments = _visible_text_fragments(original)
    if not fragments:
        return translated, []
    index = 0
    pattern = re.compile(r'"([^"\n]{1,300})"|«([^»\n]{1,300})»|“([^”\n]{1,300})”')
    def repl(match: re.Match[str]) -> str:
        nonlocal index
        if index >= len(fragments):
            return match.group(0)
        value = fragments[index]
        index += 1
        return '"' + value + '"'
    restored = pattern.sub(repl, translated)
    if index < len(fragments):
        suffix = ", ".join(f'visible text reads exactly "{x}"' for x in fragments[index:])
        restored = (restored.rstrip(" ,") + ", " + suffix).strip(" ,")
    return restored, fragments

def prepare_prompt(text: str, mode: str, model_id: str) -> dict[str, Any]:
    original = text.strip()
    model_info = MODEL_REGISTRY.get(model_id, {})
    prompt_model_id = str(model_info.get("prompt_model_id") or model_id)
    translated, translator = translate_to_english(original)
    visible_text: list[str] = []
    if prompt_model_id == "qwen21_design":
        translated, visible_text = _restore_visible_text_after_translation(original, translated)

    # Argos can mistranslate short Russian image prompts semantically
    # (for example «девушка на улице» -> «streetgirl»). Repair only
    # subject meaning explicitly present in the source, without inventing age.
    source_low = original.lower()
    if re.search(r"девушк\w*", source_low, re.I):
        translated = re.sub(r"\bstreetgirl\b", "woman outdoors", translated, flags=re.I)
        translated = re.sub(r"\bgirl\b", "woman", translated, flags=re.I)
        if not re.search(r"\b(?:woman|female)\b", translated, re.I):
            translated = "woman, " + translated
    if re.search(r"(?:парн\w*|мужчин\w*)", source_low, re.I):
        translated = re.sub(r"\bboy\b", "man", translated, flags=re.I)
        if not re.search(r"\b(?:man|male|guy)\b", translated, re.I):
            translated = "man, " + translated

    is_adult_profile = bool(model_info.get("adult"))
    full_body_requested = bool(re.search(
        r"\b(?:full[- ]?body|full[- ]?length|head[- ]?to[- ]?toe|entire body)\b"
        r"|(?:в полный рост|полный рост|целиком в кадре)",
        f"{original}\n{translated}",
        re.I,
    ))

    if is_adult_profile:
        # Adult mode must never invent a numeric age. Preserve the user's age
        # when one is supplied, and only reject explicit under-18 wording.
        safety_text = f"{original}\n{translated}".lower()
        if re.search(
            r"\b(?:child|children|kid|kids|minor|underage|schoolgirl|schoolboy|preteen|teenager|teenage|teen|adolescent|juvenile)\b"
            r"|(?:реб[её]нок|дети|девочк\w*|мальчик\w*|несовершеннолет\w*|подрост\w*)",
            safety_text,
            re.I,
        ):
            raise ValueError("18+ режим работает только с совершеннолетними персонажами.")
        for age_match in re.finditer(r"\b(\d{1,2})[ -]?(?:year[ -]?old|years? old|yo|лет|года|год)\b", safety_text, re.I):
            if int(age_match.group(1)) < 18:
                raise ValueError("18+ режим работает только с совершеннолетними персонажами.")

        # Argos often maps Russian «девушка» to ambiguous English «girl».
        # Keep the prompt age-neutral unless the user explicitly supplied an age.
        # "woman" / "man" keep adult semantics without biasing appearance older.
        translated = re.sub(r"\byoung adult woman\b", "young woman", translated, flags=re.I)
        translated = re.sub(r"\byoung adult man\b", "young man", translated, flags=re.I)
        translated = re.sub(r"\bgirl\b", "woman", translated, flags=re.I)
        translated = re.sub(r"\bboy\b", "man", translated, flags=re.I)
        translated = re.sub(r"\badult\s+adult\b", "adult", translated, flags=re.I)

        # Short RU prompts can lose the subject noun as well as adjectives.
        # Restore only semantics that were explicitly present in the source.
        original_low = original.lower()
        if re.search(r"(?:девушк\w*|женщин\w*)", original_low, re.I) and not re.search(r"\b(?:woman|female)\b", translated, re.I):
            translated = "woman, " + translated
        if re.search(r"(?:парн\w*|мужчин\w*)", original_low, re.I) and not re.search(r"\b(?:man|male)\b", translated, re.I):
            translated = "man, " + translated

        # Argos can occasionally drop a short Russian body-state adjective
        # (for example «девушка голая» -> «girl»). Preserve that user intent.
        adult_low = translated.lower()
        source_body_request = re.search(
            r"\b(?:nude|naked|topless|fully nude|bare body)\b|(?:гол\w*|обнаж\w*|топлесс)",
            safety_text,
            re.I,
        )
        if source_body_request and not re.search(r"\b(?:nude|naked|topless|bare body)\b", adult_low, re.I):
            translated += ", nude"
            adult_low = translated.lower()

        # A body-state request does not imply a camera framing. Earlier
        # releases forced every such request into a head-to-toe shot, which
        # caused wide Krea canvases to repeat the same subject several times.
        # Only explicit user framing may enable full_body_requested.

    if full_body_requested and not re.search(r"entire (?:subject|person|body) visible within (?:the )?frame", translated, re.I):
        single_person = bool(_single_person_guard(f"{original}\n{translated}", prompt_model_id))
        if single_person:
            translated = (
                "exactly one person centered in one continuous scene, full body visible from head to toe, "
                "entire person visible within the frame, camera pulled back only enough to include the whole person, "
                "continuous background extending across the left and right sides, " + translated
            )
        else:
            translated = (
                "full-length composition, all requested subjects visible within one continuous frame, "
                "camera pulled back enough to include them, " + translated
            )

    if mode == "original":
        final = translated if is_adult_profile else original
    elif mode == "translate":
        final = translated
    elif mode == "light":
        final = enhance_prompt(translated, model_id=prompt_model_id, light=True)
    else:
        final = enhance_prompt(translated, model_id=prompt_model_id, light=False)
    if prompt_model_id == "qwen21_design" and visible_text:
        exact = "; ".join(f'"{value}"' for value in visible_text)
        final = (
            final.rstrip(" ,") +
            f'. Render only these exact visible text strings: {exact}. '
            'Do not invent placeholder text, lorem ipsum, captions, labels, small print, signatures, or extra lettering.'
        )
    return {
        "original": original,
        "detected_language": detect_language(original),
        "translator": translator,
        "translated": translated,
        "final": final,
        "visible_text": visible_text,
    }
class JobManager:
    MAX_PENDING = 20
    MAX_TERMINAL_JOBS = 128
    TERMINAL_STATES = {"succeeded", "failed", "cancelled"}

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._condition = threading.Condition(self._lock)
        self._jobs: dict[str, dict[str, Any]] = {}
        self._queue: deque[str] = deque()
        self._commands: dict[str, list[str]] = {}
        self._current_job_id = ""
        self._worker = threading.Thread(target=self._worker_loop, name="LocalGenJobWorker", daemon=True)
        self._worker.start()

    def _prune_terminal_jobs_locked(self) -> int:
        terminal: list[tuple[float, str]] = []
        for job_id, job in self._jobs.items():
            if job_id == self._current_job_id or job.get("state") not in self.TERMINAL_STATES:
                continue
            try:
                ended = float(job.get("ended_at") or job.get("created_at") or 0.0)
            except Exception:
                ended = 0.0
            terminal.append((ended, job_id))
        overflow = len(terminal) - self.MAX_TERMINAL_JOBS
        if overflow <= 0:
            return 0
        removed = 0
        for _, job_id in sorted(terminal, key=lambda item: (item[0], item[1]))[:overflow]:
            if self._jobs.pop(job_id, None) is not None:
                removed += 1
            self._commands.pop(job_id, None)
        return removed

    def create(self, kind: str, command: list[str], metadata: dict[str, Any] | None = None) -> str:
        job_id = uuid.uuid4().hex
        with self._condition:
            self._prune_terminal_jobs_locked()
            pending = sum(1 for queued_id in self._queue if self._jobs.get(queued_id, {}).get("state") == "queued")
            if pending >= self.MAX_PENDING:
                raise RuntimeError(f"Очередь заполнена: максимум {self.MAX_PENDING} ожидающих задач")
            self._jobs[job_id] = {
                "id": job_id, "kind": kind, "state": "queued",
                "created_at": time.time(), "log": [], "result": None, "error": None,
                "metadata": dict(metadata or {}),
            }
            self._commands[job_id] = list(command)
            self._queue.append(job_id)
            self._condition.notify()
        try:
            notify_lifecycle_activity()
        except Exception:
            pass
        return job_id

    def _worker_loop(self) -> None:
        while True:
            with self._condition:
                while not self._queue:
                    self._condition.wait()
                job_id = self._queue.popleft()
                command = self._commands.pop(job_id, [])
                job = self._jobs.get(job_id)
                if not job or job.get("state") == "cancelled":
                    continue
                self._current_job_id = job_id
                job["state"] = "starting_backend"
                job["started_at"] = time.time()
            try:
                self._execute(job_id, command)
            finally:
                with self._condition:
                    if self._current_job_id == job_id:
                        self._current_job_id = ""
                    self._prune_terminal_jobs_locked()
                    self._condition.notify_all()

    def _execute(self, job_id: str, command: list[str]) -> None:
        try:
            ensure_comfy()

            with self._lock:
                job = self._jobs[job_id]
                if job.get("state") == "cancelled":
                    return
                job["state"] = "running"

            proc = subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            with self._lock:
                self._jobs[job_id]["pid"] = proc.pid
            lines: list[str] = []
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip()
                lines.append(line)
                with self._lock:
                    self._jobs[job_id]["log"] = lines[-80:]
                    if line.startswith("PROMPT_ID "):
                        self._jobs[job_id]["comfy_prompt_id"] = line[10:].strip()
                if line.startswith("RESULT "):
                    try:
                        payload = json.loads(line[7:])
                        with self._lock:
                            self._jobs[job_id]["result"] = payload
                    except Exception:
                        pass
            code = proc.wait()
            completed_job = None
            failed_job = None
            with self._lock:
                job = self._jobs[job_id]
                if job.get("state") != "cancelled":
                    job["ended_at"] = time.time()
                    job["state"] = "succeeded" if code == 0 else "failed"
                    if code != 0:
                        job["exit_code"] = int(code)
                        if not job.get("error"):
                            job["error"] = lines[-1] if lines else f"exit code {code}"
                        failed_job = dict(job)
                    else:
                        completed_job = dict(job)
            if completed_job is not None:
                try:
                    record_job_history(completed_job)
                except Exception:
                    pass
            if failed_job is not None:
                try:
                    record_job_failure(failed_job)
                except Exception:
                    pass
        except Exception as exc:
            failure_trace = traceback.format_exc()
            failed_job = None
            with self._lock:
                job = self._jobs[job_id]
                if job.get("state") != "cancelled":
                    job["ended_at"] = time.time()
                    job["state"] = "failed"
                    job["error"] = str(exc)
                    job["exception_type"] = type(exc).__name__
                    failed_job = dict(job)
            if failed_job is not None:
                try:
                    record_job_failure(failed_job, exception_trace=failure_trace)
                except Exception:
                    pass

    def state(self, job_id: str) -> dict[str, Any]:
        with self._lock:
            job = dict(self._jobs.get(job_id) or {"id": job_id, "state": "missing"})
            if job.get("state") == "queued":
                try:
                    job["queue_position"] = list(self._queue).index(job_id) + 1
                except ValueError:
                    job["queue_position"] = 1
            return job

    def queue_state(self) -> dict[str, Any]:
        def public(job: dict[str, Any], queue_position: int = 0) -> dict[str, Any]:
            metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
            summary_keys = (
                "model", "source_prompt", "prompt", "width", "height", "frames", "fps",
                "create_quality", "reference_count", "character_name",
            )
            item = {
                "id": job.get("id"),
                "kind": job.get("kind"),
                "state": job.get("state"),
                "created_at": job.get("created_at"),
                "started_at": job.get("started_at"),
                "metadata": {key: metadata.get(key) for key in summary_keys if metadata.get(key) not in (None, "")},
            }
            if queue_position:
                item["queue_position"] = queue_position
            return item

        with self._lock:
            running: list[dict[str, Any]] = []
            if self._current_job_id:
                current = self._jobs.get(self._current_job_id)
                if current and current.get("state") in {"starting_backend", "running"}:
                    running.append(public(current))
            pending: list[dict[str, Any]] = []
            position = 0
            for job_id in self._queue:
                job = self._jobs.get(job_id)
                if not job or job.get("state") != "queued":
                    continue
                position += 1
                pending.append(public(job, position))
            return {
                "running": running,
                "pending": pending,
                "active_count": len(running) + len(pending),
                "max_pending": self.MAX_PENDING,
            }

    def active_jobs(self) -> list[dict[str, Any]]:
        snapshot = self.queue_state()
        return snapshot["running"] + snapshot["pending"]

    def cancel(self, job_id: str) -> bool:
        with self._condition:
            job = self._jobs.get(job_id)
            if not job or job.get("state") not in {"queued", "starting_backend", "running"}:
                return False
            previous_state = str(job.get("state") or "")
            pid = int(job.get("pid", 0) or 0)
            comfy_prompt_id = str(job.get("comfy_prompt_id") or "").strip()
            job["state"] = "cancelled"
            job["ended_at"] = time.time()
            if previous_state == "queued":
                try:
                    self._queue.remove(job_id)
                except ValueError:
                    pass
                self._commands.pop(job_id, None)
                self._prune_terminal_jobs_locked()
                self._condition.notify_all()
                return True

        if comfy_prompt_id and _port_open(8188):
            try:
                response = requests.post(
                    f"{COMFY_URL}/api/jobs/{comfy_prompt_id}/cancel",
                    json={}, timeout=4,
                )
                response.raise_for_status()
            except Exception:
                try:
                    requests.post(
                        COMFY_URL + "/interrupt",
                        json={"prompt_id": comfy_prompt_id}, timeout=4,
                    )
                except Exception:
                    pass

        if pid:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        return True

JOBS = JobManager()
COMFY_START_LOG = APP / "logs" / "comfy-startup.log"
COMFY_START_LOG_MAX_BYTES = 2 * 1024 * 1024
_COMFY_CONTROL_LOCK = threading.RLock()

def _rotate_comfy_start_log() -> None:
    try:
        if not COMFY_START_LOG.is_file() or COMFY_START_LOG.stat().st_size <= COMFY_START_LOG_MAX_BYTES:
            return
        backup = COMFY_START_LOG.with_name(COMFY_START_LOG.name + ".1")
        backup.unlink(missing_ok=True)
        os.replace(COMFY_START_LOG, backup)
    except Exception:
        pass

def _comfy_start_log_tail(limit: int = 2400) -> str:
    try:
        text = COMFY_START_LOG.read_text(encoding="utf-8", errors="replace").strip()
        text = re.sub(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])", "", text)
        return text[-max(200, int(limit)):].strip()
    except Exception:
        return ""

def _launch_comfy_backend() -> subprocess.Popen:
    COMFY_START_LOG.parent.mkdir(parents=True, exist_ok=True)
    _rotate_comfy_start_log()
    env = dict(os.environ)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    with COMFY_START_LOG.open("a", encoding="utf-8", newline="\n") as log:
        log.write(f"\n=== LocalGen ComfyUI start {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        log.flush()
        return subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "start-auto.ps1")],
            stdout=log, stderr=subprocess.STDOUT, env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )

def _startup_failure_message(prefix: str, returncode: int | None = None) -> str:
    suffix = f" (код {returncode})" if returncode is not None else ""
    tail = _comfy_start_log_tail()
    if tail:
        return f"{prefix}{suffix}. Последние строки startup-лога:\n{tail}"
    return f"{prefix}{suffix}. Лог: {COMFY_START_LOG}"

def ensure_comfy() -> None:
    if _port_open(8188):
        return
    with _COMFY_CONTROL_LOCK:
        if _port_open(8188):
            return
        launcher = _launch_comfy_backend()
        deadline = time.time() + 300
        while time.time() < deadline:
            if _port_open(8188):
                return
            returncode = launcher.poll()
            if returncode is not None:
                raise RuntimeError(_startup_failure_message("ComfyUI завершился во время запуска", returncode))
            time.sleep(0.5)
        try:
            subprocess.run(
                ["taskkill", "/PID", str(launcher.pid), "/T", "/F"],
                capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=15,
            )
        except Exception:
            pass
        raise RuntimeError(_startup_failure_message("ComfyUI не открыл порт 8188 за 5 минут"))

def _require_existing_file(value: Any, label: str, *, suffixes: set[str] | None = None) -> Path:
    raw = str(value or "").strip()
    if not raw:
        raise ValueError(f"Не выбран файл: {label}")
    path = Path(raw)
    if not path.is_file():
        raise ValueError(f"Файл не найден: {path}")
    if suffixes and path.suffix.lower() not in suffixes:
        allowed = ", ".join(sorted(suffixes))
        raise ValueError(f"Неподдерживаемый формат {label}: {path.suffix or '(без расширения)'}. Разрешены: {allowed}")
    return path

def _cache_reference_image(path: Path) -> Path:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    suffix = path.suffix.lower() or ".png"
    REFERENCE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    target = REFERENCE_CACHE_DIR / f"{digest.hexdigest()}{suffix}"
    if target.is_file():
        return target
    temp = REFERENCE_CACHE_DIR / f".{target.name}.{uuid.uuid4().hex}.tmp"
    try:
        shutil.copy2(path, temp)
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)
    return target

_REFERENCE_REACHABILITY_SUFFIXES = {".json", ".jsonl", ".txt"}

def _reference_cache_reachable_names() -> set[str]:
    if not REFERENCE_CACHE_DIR.is_dir():
        return set()
    candidates = {p.name for p in REFERENCE_CACHE_DIR.iterdir() if p.is_file() and not p.name.startswith(".")}
    if not candidates:
        return set()
    reachable: set[str] = set()
    data_root = APP / "data"
    if not data_root.is_dir():
        return reachable
    for path in data_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in _REFERENCE_REACHABILITY_SUFFIXES:
            continue
        if REFERENCE_CACHE_DIR == path.parent or REFERENCE_CACHE_DIR in path.parents:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for name in candidates - reachable:
            if name in text:
                reachable.add(name)
        if len(reachable) == len(candidates):
            break
    return reachable

def clean_orphan_reference_cache(max_age_seconds: float | None = None) -> dict[str, Any]:
    _require_all_queues_idle("??????? ??? ??????????")
    if not REFERENCE_CACHE_DIR.is_dir():
        return {"ok": True, "removed": 0, "freed": 0, "pinned": 0, "skipped": 0}
    reachable = _reference_cache_reachable_names()
    threshold = None if max_age_seconds is None else max(0.0, float(max_age_seconds))
    now = time.time()
    removed = 0
    freed = 0
    pinned = 0
    skipped = 0
    for path in list(REFERENCE_CACHE_DIR.iterdir()):
        if not path.is_file():
            continue
        if not path.name.startswith(".") and path.name in reachable:
            pinned += 1
            continue
        try:
            stat = path.stat()
            if threshold is not None and max(0.0, now - stat.st_mtime) < threshold:
                skipped += 1
                continue
            size = stat.st_size
            path.unlink()
            removed += 1
            freed += size
        except Exception:
            pass
    return {"ok": True, "removed": removed, "freed": freed, "pinned": pinned, "skipped": skipped}

def clean_stale_orphan_reference_cache(max_age_seconds: float = REFERENCE_ORPHAN_STALE_SECONDS) -> dict[str, Any]:
    return clean_orphan_reference_cache(max_age_seconds)


def _checked_int(value: Any, *, name: str, default: int, low: int, high: int) -> int:
    try:
        result = int(value if value not in (None, "") else default)
    except Exception as exc:
        raise ValueError(f"{name}: требуется целое число") from exc
    if result < low or result > high:
        raise ValueError(f"{name}: допустимый диапазон {low}–{high}")
    return result

def _checked_float(value: Any, *, name: str, default: float, low: float, high: float) -> float:
    try:
        result = float(value if value not in (None, "") else default)
    except Exception as exc:
        raise ValueError(f"{name}: требуется число") from exc
    if result < low or result > high:
        raise ValueError(f"{name}: допустимый диапазон {low:g}–{high:g}")
    return result

def _validate_image_dimensions(width: int, height: int, *, max_pixels: int = 1_600_000) -> None:
    if width % 8 or height % 8:
        raise ValueError("Ширина и высота должны быть кратны 8")
    if width * height > max_pixels:
        raise ValueError(
            f"Слишком большое разрешение для RTX 3070 8 ГБ: {width}×{height}. "
            f"РСЃРїРѕР»СЊР·СѓР№ РїСЂРµСЃРµС‚ РґРѕ ~1.6 РњРї, Р·Р°С‚РµРј Upscale."
        )

def _repair_engine_for_prompt(prompt: str) -> str:
    text = str(prompt or "").lower()
    identity_sensitive = bool(re.search(
        r"\b(?:face|facial|eye|eyes|iris|pupil|eyelid|eyebrow|hand|hands|finger|fingers|thumb|skin|anatomy|"
        r"mouth|lips|teeth|ear|ears|nose|identity|portrait|person|woman|man)\b"
        r"|(?:лиц\w*|глаз\w*|радуж\w*|зрач\w*|век\w*|бров\w*|рук\w*|кист\w*|пальц\w*|"
        r"кож\w*|анатом\w*|рот\w*|губ\w*|зуб\w*|ух\w*|нос\w*|личност\w*|портрет\w*)",
        text, re.I,
    ))
    simple_local = bool(re.search(
        r"\b(?:tattoo|logo|recolor|colour|color|fabric|shirt|dress|jacket|clothing|material|stain|scratch|object|label)\b"
        r"|(?:тату\w*|логотип\w*|цвет\w*|ткан\w*|футбол\w*|плать\w*|куртк\w*|одежд\w*|"
        r"материал\w*|пятн\w*|царап\w*|предмет\w*|этикет\w*)",
        text, re.I,
    ))
    if identity_sensitive:
        return "qwen"
    if simple_local:
        return "flux"
    return "flux"


def build_job(kind: str, payload: dict[str, Any]) -> list[str]:
    image_suffixes = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    video_suffixes = {".mp4", ".mkv", ".webm", ".mov"}

    if kind == "create":
        model_id = str(payload.get("model") or "krea2_general")
        model = MODEL_REGISTRY.get(model_id)
        if not model or model.get("kind") != "create":
            raise ValueError("Неизвестная модель генерации")
        if not _model_available(model):
            raise ValueError("Выбранная модель сейчас не установлена полностью или повреждена")
        prompt = str(payload.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Опиши, что нужно создать")
        prompt_model_id = str(model.get("prompt_model_id") or model_id)
        exact_text_plan = None
        source_prompt = str(payload.get("source_prompt") or "").strip()
        try:
            exact_text_width = int(payload.get("width") or 1024)
            exact_text_height = int(payload.get("height") or 1024)
        except Exception:
            exact_text_width = exact_text_height = 0
        if model_id == "qwen21_design" and source_prompt and exact_text_width >= 512 and exact_text_height >= 512:
            candidate_plan = exact_text.build_plan(source_prompt)
            if candidate_plan.get("qualified"):
                prompt_mode = str(payload.get("prompt_mode") or "strong")
                layout_source = exact_text.build_text_free_source(source_prompt, candidate_plan)
                layout_prepared = prepare_prompt(layout_source, prompt_mode, "qwen21_design")
                if layout_prepared.get("visible_text"):
                    raise RuntimeError("Exact-text layout preparation retained visible text")
                prompt = exact_text.sanitize_text_free_final(str(layout_prepared.get("final") or ""))
                for item in candidate_plan.get("items") or []:
                    if str(item.get("text") or "") in prompt:
                        raise RuntimeError("Exact visible text leaked into AI layout prompt")
                exact_text_plan = candidate_plan
                payload["exact_text_plan"] = candidate_plan
                payload["exact_text_layout_source"] = layout_source
        layout_intent_text = " ".join([
            str(payload.get("source_prompt") or ""),
            prompt,
        ]).strip()
        guard = _single_frame_guard(layout_intent_text, prompt_model_id)
        if guard:
            if guard.lower() not in prompt.lower():
                prompt = f"{prompt}, {guard}"
            anti_layout = "not a collage, not split-screen, not a contact sheet, not multiple panels"
            if "not a collage" not in prompt.lower():
                prompt = f"{prompt}, {anti_layout}"
            payload["single_frame_guard"] = True
        else:
            payload["single_frame_guard"] = False
        subject_guard = _single_person_guard(layout_intent_text, prompt_model_id)
        if subject_guard:
            if subject_guard.lower() not in prompt.lower():
                prompt = f"{prompt}, {subject_guard}"
            payload["single_subject_guard"] = True
        else:
            payload["single_subject_guard"] = False
        payload["prompt"] = prompt
        create_quality = str(payload.get("create_quality") or "standard").strip().lower()
        if create_quality not in {"standard", "max", "custom"}:
            raise ValueError("Неизвестный режим качества генерации")
        max_quality = create_quality == "max" and bool(model.get("max_quality"))
        expert_raw = payload.get("expert") or {}
        if not isinstance(expert_raw, dict):
            raise ValueError("Экспертные параметры должны быть объектом")
        expert_allowed = set(_model_expert_info(model).get("editable") or [])
        expert = {str(k): v for k, v in expert_raw.items() if str(k) in expert_allowed and v not in (None, "")}
        if max_quality:
            max_expert = model.get("max_expert") if isinstance(model.get("max_expert"), dict) else {}
            for key, value in max_expert.items():
                if str(key) in expert_allowed and str(key) not in expert and value not in (None, ""):
                    expert[str(key)] = value
        max_side = int(model.get("max_native_side") or CREATE_NATIVE_MAX_SIDE)
        max_pixels = int(model.get("max_native_pixels") or CREATE_NATIVE_MAX_PIXELS)
        width = _checked_int(payload.get("width"), name="Ширина", default=1024, low=256, high=max_side)
        height = _checked_int(payload.get("height"), name="Высота", default=1024, low=256, high=max_side)
        _validate_image_dimensions(width, height, max_pixels=max_pixels)
        raw_seed = payload.get("seed")
        if raw_seed in (None, "", 0, "0"):
            raw_seed = secrets.randbelow(2_147_483_648)
        seed = _checked_int(
            raw_seed,
            name="Seed", default=260925, low=0, high=2_147_483_647,
        )
        raw_refs = payload.get("references") or []
        if not isinstance(raw_refs, list):
            raise ValueError("Референсы должны быть списком файлов")
        refs: list[Path] = []
        for raw in raw_refs:
            if str(raw or "").strip():
                refs.append(_require_existing_file(raw, "референс", suffixes=image_suffixes))
        if len(refs) > 9:
            raise ValueError("Create поддерживает до 9 визуальных референсов")
        raw_roles = payload.get("reference_roles") or []
        if not isinstance(raw_roles, list):
            raise ValueError("Роли референсов должны быть списком")
        allowed_reference_roles = {"auto", "identity", "clothing", "object", "style", "composition"}
        reference_roles = [str(x or "auto") for x in raw_roles[:len(refs)]]
        while len(reference_roles) < len(refs):
            reference_roles.append("auto")
        if any(role not in allowed_reference_roles for role in reference_roles):
            raise ValueError("Неизвестная роль референса")
        if refs:
            if model.get("workflow") != "qwen_t2i":
                if model.get("workflow") == "qwen_pdd4_t2i":
                    raise ValueError("PDD4 Fast проверен только для text-to-image. Для визуальных референсов выбери обычный Qwen-Image-2.1.")
                raise ValueError("Визуальные референсы в Create поддерживает Qwen-Image-2.1. Выбери Qwen или включи авто-подбор.")
            refs = [_cache_reference_image(path) for path in refs]
            payload["references"] = [str(path) for path in refs]
            payload["reference_roles"] = reference_roles
            payload["reference_count"] = len(refs)
            payload["reference_mode"] = "qwen21_multi_reference"
        if model.get("workflow") == "character_scene":
            character = _require_existing_file(payload.get("character_image"), "профиль персонажа", suffixes=image_suffixes)
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 25))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=80)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 1.0)), low=0.1, high=20)
            sampler = str(expert.get("sampler") or model.get("sampler", "euler"))
            scheduler = str(expert.get("scheduler") or model.get("scheduler", "simple"))
            if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS:
                raise ValueError("Неподдерживаемый sampler или scheduler")
            command = [
                str(COMFY_PY), str(TOOLS / "character_scene.py"), str(character), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler, "--scheduler", scheduler,
            ]
        elif model.get("workflow") == "anima_t2i":
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 10))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=40)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 1.0)), low=0.1, high=10.0)
            sampler = str(expert.get("sampler") or model.get("sampler", "euler"))
            scheduler = str(expert.get("scheduler") or model.get("scheduler", "simple"))
            if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS:
                raise ValueError("Неподдерживаемый sampler или scheduler")
            negative = str(expert.get("negative") if "negative" in expert else model.get("negative", ""))
            command = [
                str(COMFY_PY), str(TOOLS / "generate_anima.py"), prompt,
                "--model", str(model.get("model_file") or "anima-turbo-v1.1.safetensors"),
                "--text-encoder", str(model.get("text_encoder") or "qwen_3_06b_base.safetensors"),
                "--vae", str(model.get("vae") or "qwen_image_vae.safetensors"),
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler, "--scheduler", scheduler,
                "--negative", negative, "--prefix", f"LocalGen/{model_id}",
            ]
        elif model.get("workflow") == "chroma_t2i":
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 12))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=80)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 3.8)), low=0.1, high=20)
            sampler = str(expert.get("sampler") or model.get("sampler", "euler"))
            if sampler not in EXPERT_SAMPLERS:
                raise ValueError("Неподдерживаемый sampler")
            shift = _checked_float(expert.get("shift"), name="Flow shift", default=float(model.get("shift", 1.0)), low=0.0, high=4.0)
            beta_alpha = _checked_float(expert.get("beta_alpha"), name="Beta alpha", default=float(model.get("beta_alpha", 0.45)), low=0.05, high=2.0)
            beta_beta = _checked_float(expert.get("beta_beta"), name="Beta beta", default=float(model.get("beta_beta", 0.45)), low=0.05, high=2.0)
            negative = str(expert.get("negative") if "negative" in expert else model.get("negative", ""))
            command = [
                str(COMFY_PY), str(TOOLS / "generate_chroma.py"), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler,
                "--shift", str(shift), "--beta-alpha", str(beta_alpha), "--beta-beta", str(beta_beta),
                "--negative", negative, "--prefix", f"LocalGen/{model_id}",
                "--model", str(model.get("model_file") or "Chroma1-HD-Q5_K_M.gguf"),
                "--text-encoder", str(model.get("text_encoder") or "t5xxl_fp8_e4m3fn.safetensors"),
                "--vae", str(model.get("vae") or "ae.safetensors"),
            ]
        elif model.get("workflow") == "zimage_t2i":
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 8))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=40)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 1.0)), low=0.1, high=10.0)
            sampler = str(expert.get("sampler") or model.get("sampler", "res_multistep"))
            scheduler = str(expert.get("scheduler") or model.get("scheduler", "simple"))
            if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS:
                raise ValueError("Неподдерживаемый sampler или scheduler")
            shift = _checked_float(expert.get("shift"), name="Flow shift", default=float(model.get("shift", 3.0)), low=0.0, high=10.0)
            command = [
                str(COMFY_PY), str(TOOLS / "generate_zimage.py"), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler,
                "--scheduler", scheduler, "--shift", str(shift),
                "--prefix", f"LocalGen/{model_id}",
                "--model", str(model.get("model_file") or "z-image-turbo-Q5_K_M.gguf"),
                "--text-encoder", str(model.get("text_encoder") or "qwen_3_4b.safetensors"),
                "--vae", str(model.get("vae") or "ae.safetensors"),
            ]
            control_image = str(payload.get("structure_control") or "").strip()
            if control_image:
                control_path = Path(control_image)
                if not control_path.is_file() or control_path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                    raise ValueError("Выбери существующее изображение для контроля структуры")
                control_name = str(model.get("structure_control_model") or "")
                control_model = _structure_control_path(model)
                control_expected = int(model.get("structure_control_expected_bytes") or 0)
                if not control_name or not control_model.is_file() or (control_expected and control_model.stat().st_size != control_expected):
                    raise ValueError("Structure Control не установлен или повреждён")
                control_mode = str(payload.get("structure_mode") or "canny").strip().lower()
                available_modes = _structure_control_modes(model)
                if control_mode not in available_modes:
                    raise ValueError(f"Режим Structure Control недоступен: {control_mode}")
                control_strength = _checked_float(payload.get("structure_strength"), name="Control strength", default=1.0, low=0.1, high=1.5)
                command.extend([
                    "--control-image", str(control_path),
                    "--control-mode", control_mode,
                    "--control-strength", str(control_strength),
                    "--control-model", control_name,
                ])
        elif model.get("workflow") == "qwen_fix_t2i":
            if str(payload.get("structure_control") or "").strip():
                raise ValueError(
                    "Qwen Detail / Anatomy Fix не поддерживает Structure Control. "
                    "Для точной композиции используй обычный Qwen-Image-2.1 с Qwen Union или Z-Image."
                )
            command = [
                str(COMFY_PY), str(TOOLS / "generate_qwen21_fix.py"), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--prefix", f"LocalGen/{model_id}",
            ]
        elif model.get("workflow") == "qwen_pdd4_t2i":
            if expert:
                forbidden = sorted(set(expert) & {"steps", "cfg", "sampler", "scheduler"})
                if forbidden:
                    raise ValueError("PDD4 Fast использует фиксированный 4-step PDD workflow; Steps/CFG/Sampler/Scheduler не настраиваются.")
            command = [
                str(COMFY_PY), str(TOOLS / "generate_qwen21_pdd4.py"), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--prefix", f"LocalGen/{model_id}",
            ]
        elif model.get("workflow") == "qwen_t2i":
            control_image = str(payload.get("structure_control") or "").strip()
            control_mode = str(payload.get("structure_mode") or "canny").strip().lower()
            control_strength = 0.85
            if control_image:
                control_strength = _checked_float(
                    payload.get("structure_strength"), name="Control strength", default=0.85, low=0.1, high=1.5
                )
                if refs:
                    raise ValueError("Qwen Structure Control и визуальные референсы пока нельзя использовать одновременно")
                control_path = _require_existing_file(control_image, "контроль структуры", suffixes=image_suffixes)
                if str(model.get("structure_control_backend") or "") != "qwen21_union":
                    raise ValueError("Для этой Qwen-модели Structure Control не настроен")
                control_name = str(model.get("structure_control_model") or "")
                control_model = _structure_control_path(model)
                control_expected = int(model.get("structure_control_expected_bytes") or 0)
                if not control_name or not control_model.is_file() or (control_expected and control_model.stat().st_size != control_expected):
                    raise ValueError("Qwen Structure Control не установлен или повреждён")
                available_modes = _structure_control_modes(model)
                if control_mode not in available_modes:
                    raise ValueError(f"Режим Qwen Structure Control недоступен: {control_mode}")
                control_max_pixels = int(model.get("structure_control_max_pixels") or 1100000)
                if width * height > control_max_pixels:
                    raise ValueError(
                        "Qwen Structure Control на RTX 3070 8 ГБ проверен примерно до 1.1 Мп. "
                        "Выбери меньший native-размер, затем используй Delivery upscale или AI Restore. "
                        "Без Structure Control обычный Qwen по-прежнему поддерживает Full HD."
                    )
                control_steps = int(model.get("structure_control_max_steps") if max_quality else model.get("structure_control_steps", 20))
                steps_default = control_steps
            else:
                steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 28))
            steps_high = int(model.get("structure_control_max_steps", 40)) if control_image else 80
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=steps_high)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 1.0)), low=0.1, high=20)
            sampler = str(expert.get("sampler") or model.get("sampler", "euler"))
            scheduler = str(expert.get("scheduler") or model.get("scheduler", "simple"))
            if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS:
                raise ValueError("Неподдерживаемый sampler или scheduler")
            tool = "generate_qwen21_union.py" if control_image else ("generate_qwen21_refs.py" if refs else "generate_qwen21.py")
            command = [
                str(COMFY_PY), str(TOOLS / tool), prompt,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler, "--scheduler", scheduler,
                "--prefix", f"LocalGen/{model_id}",
            ]
            if model.get("model_file"):
                command.extend(["--model", str(model["model_file"])])
            if control_image:
                command.extend([
                    "--control-image", str(control_path),
                    "--control-mode", control_mode,
                    "--control-strength", str(control_strength),
                    "--control-model", control_name,
                ])
            elif refs:
                for ref, role in zip(refs, reference_roles):
                    command.extend(["--reference", str(ref), "--reference-role", role])
        elif model.get("workflow") == "sdxl":
            checkpoint = str(model.get("checkpoint") or "").strip()
            if not checkpoint:
                raise ValueError("Для SDXL-профиля не указан checkpoint")
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 30))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=80)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 5.0)), low=0.1, high=20)
            sampler = str(expert.get("sampler") or model.get("sampler", "dpmpp_2m"))
            scheduler = str(expert.get("scheduler") or model.get("scheduler", "karras"))
            if sampler not in EXPERT_SAMPLERS or scheduler not in EXPERT_SCHEDULERS:
                raise ValueError("Неподдерживаемый sampler или scheduler")
            clip_skip = _checked_int(expert.get("clip_skip"), name="CLIP skip", default=int(model.get("clip_skip", 1)), low=1, high=4)
            prediction = str(expert.get("prediction") or model.get("prediction", "eps"))
            if prediction not in {"eps", "v_prediction"}:
                raise ValueError("Неподдерживаемый Prediction")
            negative = str(expert.get("negative") if "negative" in expert else model.get("negative", ""))
            if payload.get("single_frame_guard"):
                layout_negative = "collage, diptych, triptych, split screen, contact sheet, storyboard, comic panels, multiple panels, multiple views, tiled image, picture-in-picture"
                if "collage" not in negative.lower():
                    negative = layout_negative + (", " + negative if negative else "")
            if payload.get("single_subject_guard"):
                subject_negative = "multiple people, crowd, group, twins, cloned person, duplicate person, repeated subject"
                if "multiple people" not in negative.lower():
                    negative = subject_negative + (", " + negative if negative else "")
            if "entire subject visible within the frame" in prompt.lower():
                framing_negative = "close-up, headshot, portrait crop, cropped head, cropped feet"
                if framing_negative not in negative:
                    negative = framing_negative + (", " + negative if negative else "")
            command = [
                str(COMFY_PY), str(TOOLS / "generate_sdxl.py"), prompt,
                "--checkpoint", checkpoint,
                "--width", str(width), "--height", str(height), "--seed", str(seed),
                "--steps", str(steps),
                "--cfg", str(cfg),
                "--sampler", sampler,
                "--scheduler", scheduler,
                "--negative", negative,
                "--clip-skip", str(clip_skip),
                "--prediction", prediction,
                "--prefix", f"LocalGen/{model_id}",
            ]
            zsnr = bool(expert.get("zsnr")) if "zsnr" in expert else bool(model.get("zsnr"))
            if zsnr:
                command.append("--zsnr")
            # Latent second-pass refine is intentionally opt-in. The previous
            # Maximum mode enabled it automatically and could repaint skin, eyes,
            # line art and small expression details. Maximum now raises only the
            # model-native step count; manual expert overrides can still request
            # latent refine explicitly.
            if "hires_scale" in expert and float(expert.get("hires_scale") or 1.0) > 1.001:
                hires_scale = _checked_float(expert.get("hires_scale"), name="Hires scale", default=1.0, low=1.0, high=1.6)
                hires_steps = _checked_int(expert.get("hires_steps"), name="Hires steps", default=int(model.get("hires_steps", 10)), low=1, high=40)
                hires_denoise = _checked_float(expert.get("hires_denoise"), name="Hires denoise", default=float(model.get("hires_denoise", 0.22)), low=0.05, high=0.6)
                command.extend([
                    "--hires-scale", str(hires_scale),
                    "--hires-steps", str(hires_steps),
                    "--hires-denoise", str(hires_denoise),
                ])
        else:
            steps_default = int(model.get("max_steps") if max_quality and "steps" not in expert else model.get("steps", 8))
            steps = _checked_int(expert.get("steps"), name="Steps", default=steps_default, low=1, high=80)
            cfg = _checked_float(expert.get("cfg"), name="CFG", default=float(model.get("cfg", 1.0)), low=0.1, high=20)
            sampler = str(expert.get("sampler") or model.get("sampler", "euler"))
            if sampler not in EXPERT_SAMPLERS:
                raise ValueError("Неподдерживаемый sampler")
            command = [
                str(COMFY_PY), str(TOOLS / "generate_image.py"), prompt,
                "--profile", str(model["profile"]), "--width", str(width), "--height", str(height),
                "--seed", str(seed), "--steps", str(steps), "--cfg", str(cfg), "--sampler", sampler,
            ]
            if model.get("profile") in {"general", "adult"}:
                scheduler = str(expert.get("scheduler") or model.get("scheduler", "simple"))
                if scheduler not in EXPERT_SCHEDULERS:
                    raise ValueError("Неподдерживаемый scheduler")
                command.extend(["--scheduler", scheduler])
            if model.get("profile") == "adult":
                lora_strength = _checked_float(expert.get("lora_strength"), name="LoRA strength", default=float(model.get("lora_strength", 1.0)), low=0.0, high=2.0)
                command.extend(["--lora-strength", str(lora_strength)])
            if model.get("model_file"):
                command.extend(["--model", str(model["model_file"])])

        output_width = int(payload.get("output_width") or 0)
        output_height = int(payload.get("output_height") or 0)
        if output_width or output_height:
            if not output_width or not output_height:
                raise ValueError("Финальный размер должен содержать ширину и высоту")
            if output_width < width or output_height < height:
                raise ValueError("Финальный размер не должен быть меньше базового рендера")
            if output_width > 4096 or output_height > 4096:
                raise ValueError("Автоматический финальный вывод ограничен 4096 px по каждой стороне")
            upscale_factor = max(output_width / width, output_height / height)
            if upscale_factor > 4.0:
                raise ValueError("Финальный размер требует увеличения больше ×4. Выбери больший базовый render preset.")
            base_ratio = width / height
            target_ratio = output_width / output_height
            if abs(base_ratio - target_ratio) / max(base_ratio, target_ratio) > 0.025:
                raise ValueError("Финальный размер должен сохранять пропорции базового рендера")
            if output_width != width or output_height != height:
                command = [
                    str(COMFY_PY), str(TOOLS / "create_delivery.py"),
                    "--target-width", str(output_width), "--target-height", str(output_height),
                    "--model", "4x_NMKD-Superscale-SP_178000_G.pth", "--",
                    *command,
                ]

        if exact_text_plan:
            command = [
                str(COMFY_PY), str(HYBRID_EXACT_TEXT_WRAPPER),
                "--source-prompt", str(payload.get("source_prompt") or ""), "--",
                *command,
            ]

    elif kind == "edit_smart":
        image = _require_existing_file(payload.get("image"), "изображение", suffixes=image_suffixes)
        prompt = str(payload.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Напиши, что нужно изменить")
        raw_refs = payload.get("references") or []
        if not isinstance(raw_refs, list):
            raise ValueError("Референсы должны быть списком файлов")
        refs: list[Path] = []
        for raw in raw_refs:
            if str(raw or "").strip():
                refs.append(_require_existing_file(raw, "референс", suffixes=image_suffixes))
        if len(refs) > 3:
            raise ValueError("В интерфейсе поддерживается до 3 дополнительных референсов")
        raw_roles = payload.get("reference_roles") or []
        if not isinstance(raw_roles, list):
            raise ValueError("Роли референсов должны быть списком")
        allowed_roles = {"auto","identity","clothing","object","style"}
        roles = [str(x or "auto") for x in raw_roles[:len(refs)]]
        while len(roles) < len(refs):
            roles.append("auto")
        if any(role not in allowed_roles for role in roles):
            raise ValueError("Неизвестная роль референса")
        edit_encoder = "zen" if _use_zen_smart_edit(payload, refs) else "native"
        command = [
            str(COMFY_PY), str(TOOLS / "smart_edit.py"), str(image), prompt,
            "--encoder", edit_encoder,
        ]
        for ref, role in zip(refs, roles):
            command.extend(["--reference", str(ref), "--reference-role", role])

    elif kind == "edit_exact":
        image = _require_existing_file(payload.get("image"), "изображение", suffixes=image_suffixes)
        mask = _require_existing_file(payload.get("mask"), "маска", suffixes=image_suffixes)
        prompt = str(payload.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Напиши, что должно появиться в выделенной области")
        try:
            with Image.open(image) as src_im, Image.open(mask) as mask_im:
                if src_im.size != mask_im.size:
                    raise ValueError(
                        f"Размер маски {mask_im.size[0]}×{mask_im.size[1]} не совпадает "
                        f"с изображением {src_im.size[0]}×{src_im.size[1]}"
                    )
        except ValueError:
            raise
        except Exception as exc:
            raise ValueError("Не удалось прочитать изображение или маску") from exc
        routing_text = str(payload.get("source_prompt") or prompt).strip()
        repair_engine = _repair_engine_for_prompt(routing_text)
        command = [
            str(COMFY_PY), str(TOOLS / "exact_edit.py"), str(image), str(mask), prompt,
            "--engine", repair_engine,
            "--output-root", str(current_output_root()),
        ]

    elif kind == "animate":
        model_id = str(payload.get("model") or "wan22_preview")
        model = MODEL_REGISTRY.get(model_id)
        if not model or model.get("kind") != "animate":
            raise ValueError("Неизвестная видеомодель")
        if not model.get("enabled", True) or not Path(model["installed"]).exists():
            raise ValueError("Выбранная видеомодель сейчас не установлена")
        image = _require_existing_file(payload.get("image"), "исходное фото", suffixes=image_suffixes)
        prompt = str(payload.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("Опиши движение")
        controls = model.get("video_controls") if isinstance(model.get("video_controls"), dict) else {}
        defaults = controls.get("defaults") if isinstance(controls.get("defaults"), dict) else {}
        ranges = controls.get("ranges") if isinstance(controls.get("ranges"), dict) else {}
        width_range = ranges.get("width") if isinstance(ranges.get("width"), dict) else {}
        height_range = ranges.get("height") if isinstance(ranges.get("height"), dict) else {}
        fps_range = ranges.get("fps") if isinstance(ranges.get("fps"), dict) else {}
        width = _checked_int(
            payload.get("width"), name="Ширина видео", default=int(defaults.get("width", 640)),
            low=int(width_range.get("min", 320)), high=int(width_range.get("max", 1280)),
        )
        height = _checked_int(
            payload.get("height"), name="Высота видео", default=int(defaults.get("height", 640)),
            low=int(height_range.get("min", 320)), high=int(height_range.get("max", 1280)),
        )
        if width % 16 or height % 16:
            raise ValueError("Для видео ширина и высота должны быть кратны 16")
        max_pixels = int(controls.get("max_pixels") or (460_000 if model_id == "wan22_quality" else 920_000))
        if width * height > max_pixels:
            label = "Quality A14B" if model_id == "wan22_quality" else "Preview 5B"
            raise ValueError(
                f"Слишком большое разрешение для {label} на RTX 3070 8 ГБ: {width}×{height}. "
                f"Максимальный безопасный бюджет текущего профиля: {max_pixels:,} пикс.".replace(",", " ")
            )
        max_frames = int(controls.get("max_frames") or 81)
        frames = _checked_int(payload.get("frames"), name="Кадры", default=33, low=9, high=max_frames)
        if (frames - 1) % 4:
            raise ValueError("Количество кадров Wan должно иметь вид 4N+1, например 17, 33, 41 или 81")
        fps = _checked_float(
            payload.get("fps"), name="FPS", default=float(defaults.get("fps", 16)),
            low=float(fps_range.get("min", 8)), high=float(fps_range.get("max", 30)),
        )
        seed = _checked_int(payload.get("seed"), name="Seed", default=260925, low=0, high=2_147_483_647)

        expert = payload.get("expert") if isinstance(payload.get("expert"), dict) else {}
        steps_range = ranges.get("steps") if isinstance(ranges.get("steps"), dict) else {}
        cfg_range = ranges.get("cfg") if isinstance(ranges.get("cfg"), dict) else {}
        shift_range = ranges.get("shift") if isinstance(ranges.get("shift"), dict) else {}
        steps = _checked_int(
            expert.get("steps"), name="Video steps", default=int(defaults.get("steps", 12)),
            low=int(steps_range.get("min", 2)), high=int(steps_range.get("max", 40)),
        )
        cfg = _checked_float(
            expert.get("cfg"), name="Video CFG", default=float(defaults.get("cfg", 5.0)),
            low=float(cfg_range.get("min", 0.1)), high=float(cfg_range.get("max", 20.0)),
        )
        shift = _checked_float(
            expert.get("shift"), name="Video shift", default=float(defaults.get("shift", 5.0)),
            low=float(shift_range.get("min", 0.0)), high=float(shift_range.get("max", 20.0)),
        )
        sampler = str(expert.get("sampler") or defaults.get("sampler") or "euler").strip()
        allowed_samplers = [str(x) for x in (controls.get("samplers") or ["euler", "uni_pc"])]
        if sampler not in allowed_samplers:
            raise ValueError("Неподдерживаемый sampler для выбранной видеомодели")
        negative = str(expert.get("negative") if expert.get("negative") is not None else defaults.get("negative", "")).strip()
        if len(negative) > 4000:
            raise ValueError("Negative prompt для видео слишком длинный")

        mode = "quality" if model_id == "wan22_quality" else "preview"
        command = [
            str(COMFY_PY), str(TOOLS / "animate_photo.py"),
            str(image), prompt, "--mode", mode,
            "--width", str(width), "--height", str(height),
            "--frames", str(frames), "--fps", str(fps), "--seed", str(seed),
            "--steps", str(steps), "--cfg", str(cfg), "--shift", str(shift),
            "--sampler", sampler, "--negative", negative,
        ]

    elif kind == "upscale_image":
        path = _require_existing_file(payload.get("path"), "изображение", suffixes=image_suffixes)
        scale = _checked_float(payload.get("scale"), name="Увеличение", default=2, low=1, high=4)
        mode = str(payload.get("model") or "omnisr").strip().lower()
        if mode == "omnisr":
            if abs(scale - 2.0) > 1e-6:
                raise ValueError("OmniSR установлен в версии ×2. Для ×4 выбери NMKD Detail Boost или VOSR2 AI Restore.")
            model_name = "OmniSR_X2_DIV2K.safetensors"
        elif mode == "nmkd":
            model_name = "4x_NMKD-Superscale-SP_178000_G.pth"
        elif mode == "vosr2":
            if not (abs(scale - 2.0) < 1e-6 or abs(scale - 4.0) < 1e-6):
                raise ValueError("VOSR2 в LocalGen поддерживает проверенные режимы ×2 и ×4.")
            bundle = ROOT / "ComfyUI" / "models" / "vosr2" / "VOSR2"
            required = [
                bundle / "checkpoints" / "ema_model.safetensors",
                bundle / "Qwen-Image-vae-2d" / "config.json",
                bundle / "Qwen-Image-vae-2d" / "diffusion_pytorch_model.safetensors",
                bundle / "dinov2_vitl14.safetensors",
            ]
            if any(not p.is_file() for p in required):
                raise ValueError("VOSR2 установлен не полностью: отсутствует часть DiT/VAE/DINOv2 bundle.")
            command = [
                str(COMFY_PY), str(TOOLS / "vosr2_restore_image.py"), str(path),
                "--scale", str(int(round(scale))), "--prefix", "LocalGen/upscaled_vosr2",
            ]
            model_name = ""
        else:
            raise ValueError("Неизвестный режим улучшения изображения")
        if mode != "vosr2":
            model_path = ROOT / "Models" / "upscale_models" / model_name
            if not model_path.is_file():
                raise ValueError(f"Модель upscale не установлена: {model_name}")
            command = [
                str(COMFY_PY), str(TOOLS / "upscale_image.py"), str(path),
                "--scale", str(scale), "--model", model_name,
                "--prefix", "LocalGen/upscaled_" + mode,
            ]

    elif kind == "upscale_video":
        path = _require_existing_file(payload.get("path"), "видео", suffixes=video_suffixes)
        scale = _checked_float(payload.get("scale"), name="Увеличение", default=2, low=1, high=4)
        command = [str(COMFY_PY), str(TOOLS / "upscale_video.py"), str(path), "--scale", str(scale)]

    elif kind == "restore_video_seedvr2":
        path = _require_existing_file(payload.get("path"), "видео", suffixes=video_suffixes)
        scale = _checked_float(payload.get("scale"), name="Увеличение", default=2, low=1, high=2)
        model = MODEL_REGISTRY["seedvr2_video"]
        vae = ROOT / "Models" / "SEEDVR2" / "ema_vae_fp16.safetensors"
        if not Path(model["installed"]).exists() or not vae.exists():
            raise ValueError("SeedVR2 ещё не установлен полностью")
        command = [
            str(COMFY_PY), str(TOOLS / "seedvr2_enhance_video.py"), str(path),
            "--scale", str(scale), "--batch-size", "5",
        ]

    else:
        raise ValueError(f"Неизвестная операция: {kind}")

    return command

def output_path_from_result(result: dict[str, Any] | None) -> Path | None:
    if not result:
        return None
    if isinstance(result.get("output"), str):
        p = Path(result["output"])
        return p if p.exists() else None
    for item in result.get("outputs") or []:
        name = item.get("filename")
        if not name:
            continue
        sub = item.get("subfolder") or ""
        p = current_output_root() / sub / name
        if p.exists():
            return p
    return None
JOB_HISTORY_FILE = APP / "data" / "job-history.jsonl"
_HISTORY_LOCK = threading.Lock()
JOB_HISTORY_MAX_BYTES = 4 * 1024 * 1024
JOB_HISTORY_KEEP_LINES = 1000
JOB_FAILURE_FILE = APP / "logs" / "job-failures.jsonl"
_FAILURE_LOG_LOCK = threading.Lock()
JOB_FAILURE_MAX_BYTES = 1 * 1024 * 1024
JOB_FAILURE_KEEP_LINES = 200

def _sanitize_failure_text(value: Any, metadata: dict[str, Any], limit: int = 2400) -> str:
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])", "", text)
    secrets_to_remove: list[str] = []
    for key in ("prompt", "source_prompt", "image", "path", "mask"):
        item = metadata.get(key)
        if item not in (None, ""):
            secrets_to_remove.append(str(item))
    for key in ("references", "reference_roles"):
        item = metadata.get(key)
        if isinstance(item, (list, tuple)):
            secrets_to_remove.extend(str(x) for x in item if str(x))
    for secret in sorted(set(secrets_to_remove), key=len, reverse=True):
        if secret:
            text = text.replace(secret, "<redacted>")
    text = text.strip()
    return text[-max(200, int(limit)):]

def record_job_failure(job: dict[str, Any], *, exception_trace: str = "") -> None:
    metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
    record = {
        "id": str(job.get("id") or ""),
        "kind": str(job.get("kind") or ""),
        "state": "failed",
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "ended_at": job.get("ended_at"),
        "model": str(metadata.get("model") or ""),
        "exit_code": job.get("exit_code"),
        "exception_type": str(job.get("exception_type") or ""),
        "error": _sanitize_failure_text(job.get("error"), metadata, 1600),
    }
    trace = _sanitize_failure_text(exception_trace, metadata, 2400)
    if trace:
        record["traceback_tail"] = trace
    JOB_FAILURE_FILE.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    with _FAILURE_LOG_LOCK:
        with JOB_FAILURE_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        try:
            if JOB_FAILURE_FILE.stat().st_size > JOB_FAILURE_MAX_BYTES:
                lines = JOB_FAILURE_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()[-JOB_FAILURE_KEEP_LINES:]
                temp = JOB_FAILURE_FILE.with_name(f".{JOB_FAILURE_FILE.name}.{uuid.uuid4().hex}.tmp")
                try:
                    temp.write_text(("\n".join(lines) + "\n") if lines else "", encoding="utf-8")
                    os.replace(temp, JOB_FAILURE_FILE)
                finally:
                    temp.unlink(missing_ok=True)
        except Exception:
            pass

def record_job_history(job: dict[str, Any]) -> None:
    output = output_path_from_result(job.get("result"))
    if not output:
        return
    record = {
        "id": job.get("id"),
        "kind": job.get("kind"),
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "ended_at": job.get("ended_at"),
        "output": str(output.resolve()),
        "metadata": dict(job.get("metadata") or {}),
    }
    JOB_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
    with _HISTORY_LOCK:
        with JOB_HISTORY_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        try:
            if JOB_HISTORY_FILE.stat().st_size > JOB_HISTORY_MAX_BYTES:
                lines = JOB_HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()[-JOB_HISTORY_KEEP_LINES:]
                temp = JOB_HISTORY_FILE.with_name(f".{JOB_HISTORY_FILE.name}.{uuid.uuid4().hex}.tmp")
                try:
                    with temp.open("w", encoding="utf-8", newline="\n") as fh:
                        if lines:
                            fh.write("\n".join(lines) + "\n")
                        fh.flush()
                        os.fsync(fh.fileno())
                    os.replace(temp, JOB_HISTORY_FILE)
                finally:
                    temp.unlink(missing_ok=True)
        except Exception:
            pass

def delete_output_file(path_value: Any) -> dict[str, Any]:
    raw = str(path_value or "").strip()
    if not raw:
        raise ValueError("Файл результата не указан")
    path = Path(raw).expanduser().resolve()
    allowed_suffixes = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".mp4", ".mkv", ".webm", ".mov"}
    if path.suffix.lower() not in allowed_suffixes:
        raise ValueError("Этот тип файла нельзя удалять через LocalGen")
    roots = [root.resolve() for root in known_output_roots()]
    allowed = False
    for root in roots:
        try:
            path.relative_to(root)
            allowed = True
            break
        except ValueError:
            continue
    if not allowed:
        raise ValueError("Удаление разрешено только внутри папок результатов LocalGen")
    if not path.is_file():
        return {"ok": False, "message": "Файл уже не существует", "missing": True}

    resolved_key = str(path).lower()
    path.unlink()
    removed_history = 0
    if JOB_HISTORY_FILE.exists():
        with _HISTORY_LOCK:
            lines = JOB_HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
            kept: list[str] = []
            for line in lines:
                try:
                    item = json.loads(line)
                    item_path = str(Path(item.get("output") or "").resolve()).lower()
                    if item_path == resolved_key:
                        removed_history += 1
                        continue
                except Exception:
                    pass
                kept.append(line)
            temp = JOB_HISTORY_FILE.with_name(f".{JOB_HISTORY_FILE.name}.{uuid.uuid4().hex}.tmp")
            try:
                temp.write_text(("\n".join(kept) + "\n") if kept else "", encoding="utf-8")
                os.replace(temp, JOB_HISTORY_FILE)
            finally:
                temp.unlink(missing_ok=True)
    return {"ok": True, "path": str(path), "history_removed": removed_history}

def _job_history_index() -> dict[str, dict[str, Any]]:
    if not JOB_HISTORY_FILE.exists():
        return {}
    try:
        lines = JOB_HISTORY_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()[-1200:]
    except Exception:
        return {}
    out: dict[str, dict[str, Any]] = {}
    for line in lines:
        try:
            item = json.loads(line)
            p = str(Path(item.get("output") or "").resolve()).lower()
            if p:
                out[p] = item
        except Exception:
            continue
    return out

def clipboard_image_to_file() -> str | None:
    data = ImageGrab.grabclipboard()
    if isinstance(data, Image.Image):
        target = APP / "data" / f"clipboard_{uuid.uuid4().hex[:10]}.png"
        target.parent.mkdir(parents=True, exist_ok=True)
        data.convert("RGBA").save(target)
        return str(target)
    if isinstance(data, list) and data:
        p = Path(str(data[0]))
        if p.exists() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
            return str(p)
    return None

def copy_image_to_clipboard(path: str) -> bool:
    import win32clipboard
    img = Image.open(path).convert("RGB")
    buf = io.BytesIO()
    img.save(buf, "BMP")
    dib = buf.getvalue()[14:]
    buf.close()
    win32clipboard.OpenClipboard()
    try:
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32clipboard.CF_DIB, dib)
    finally:
        win32clipboard.CloseClipboard()
    return True

def _translator_installed() -> bool:
    packages = APP / "data" / "argos-packages"
    return any(packages.glob("translate-ru_en-*/model/model.bin"))

def _temp_file_candidates() -> list[Path]:
    data = APP / "data"
    if not data.exists():
        return []
    out: list[Path] = []
    for pattern in ("clipboard_*", "drop_*", "mask_*", "quality_region_mask_*"):
        out.extend(p for p in data.glob(pattern) if p.is_file())
    return out

def health_report() -> dict[str, Any]:
    online = _port_open(8188)
    stats: dict[str, Any] = {}
    if online:
        try:
            stats = requests.get(COMFY_URL + "/system_stats", timeout=2).json()
        except Exception:
            stats = {}
    models = [_model_public(v, k) for k, v in MODEL_REGISTRY.items()]
    missing = [m["name"] for m in models if not m["installed"] and not m.get("optional")]
    optional_missing = [m["name"] for m in models if not m["installed"] and m.get("optional")]
    integrity = production_asset_integrity()
    settings = runtime_settings()
    output_root = Path(settings["output_directory"])
    output_writable = True
    try:
        output_root, _ = _validate_output_directory(output_root)
        disk = shutil.disk_usage(output_root)
    except Exception:
        output_writable = False
        disk = shutil.disk_usage(ROOT)
    data = APP / "data"
    data.mkdir(parents=True, exist_ok=True)
    writable = True
    probe = data / ".health-write-test"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
    except Exception:
        writable = False
    active = JOBS.active_jobs()
    checks = [
        {"id": "backend", "label": "AI-движок", "ok": online, "detail": "ComfyUI доступен" if online else "Запустится автоматически перед задачей"},
        {"id": "translator", "label": "Перевод RU→EN", "ok": _translator_installed(), "detail": "Argos Translate установлен" if _translator_installed() else "Локальный переводчик не найден"},
        {"id": "models", "label": "Модели", "ok": not missing, "detail": (
            "Все основные модели доступны" + (" · опционально не установлено: " + ", ".join(optional_missing[:3]) if optional_missing else "")
            if not missing else "Не установлены обязательные модели: " + ", ".join(missing[:4])
        )},
        {"id": "assets", "label": "Файлы моделей", "ok": integrity["ok"], "detail": (
            f'{integrity["valid"]}/{integrity["total"]} production-файлов целы'
            if integrity["ok"]
            else "Проблема: " + ", ".join(x["name"] for x in integrity["bad"][:4])
        )},
        {"id": "data", "label": "Папка приложения", "ok": writable, "detail": "Доступ на запись есть" if writable else "Нет доступа на запись"},
        {"id": "output", "label": "Папка результатов", "ok": output_writable, "detail": str(output_root) if output_writable else "Нет доступа на запись"},
        {"id": "disk", "label": "Свободное место для результатов", "ok": disk.free >= 20 * 1024**3, "detail": f"{disk.free / 1024**3:.1f} ГБ свободно"},
    ]
    overall = "ok"
    if any(not c["ok"] and c["id"] in {"translator","models","assets","data","output"} for c in checks):
        overall = "error"
    elif any(not c["ok"] for c in checks):
        overall = "warning"
    return {
        "overall": overall,
        "checks": checks,
        "active_jobs": len(active),
        "temp_files": len(_temp_file_candidates()),
        "temp_bytes": sum(p.stat().st_size for p in _temp_file_candidates()),
        "disk_free": disk.free,
        "output_directory": str(output_root),
        "runtime_settings": settings,
        "asset_integrity": integrity,
        "system": stats,
    }

def comfy_queue_snapshot() -> dict[str, Any]:
    online = _port_open(8188)
    if not online:
        return {"online": False, "known": True, "running": 0, "pending": 0, "idle": True}
    try:
        payload = requests.get(COMFY_URL + "/queue", timeout=3).json()
        running = len(payload.get("queue_running") or [])
        pending = len(payload.get("queue_pending") or [])
        return {
            "online": True,
            "known": True,
            "running": running,
            "pending": pending,
            "idle": running == 0 and pending == 0,
        }
    except Exception as exc:
        return {
            "online": True,
            "known": False,
            "running": 0,
            "pending": 0,
            "idle": False,
            "error": str(exc),
        }

def _require_all_queues_idle(action: str) -> dict[str, Any]:
    if JOBS.active_jobs():
        raise RuntimeError(f"Нельзя {action} во время активной или ожидающей задачи LocalGen")
    snapshot = comfy_queue_snapshot()
    if snapshot["online"] and not snapshot["known"]:
        raise RuntimeError(f"Нельзя {action}: состояние очереди ComfyUI неизвестно")
    if snapshot["running"] or snapshot["pending"]:
        raise RuntimeError(f"Нельзя {action}: в ComfyUI есть активная или ожидающая задача")
    return snapshot

def _stop_comfy_listener() -> bool:
    if not _port_open(8188):
        return True
    command = (
        "$c=Get-NetTCPConnection -LocalPort 8188 -State Listen -ErrorAction SilentlyContinue | "
        "Select-Object -First 1; if($c){Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue}"
    )
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-Command", command],
        capture_output=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        timeout=15,
    )
    deadline = time.time() + 20
    while time.time() < deadline:
        if not _port_open(8188):
            return True
        time.sleep(0.25)
    return not _port_open(8188)

def free_comfy_memory() -> dict[str, Any]:
    with _COMFY_CONTROL_LOCK:
        snapshot = _require_all_queues_idle("освобождать VRAM")
        if not snapshot["online"]:
            return {"ok": True, "already_offline": True}
        response = requests.post(
            COMFY_URL + "/free",
            json={"unload_models": True, "free_memory": True},
            timeout=15,
        )
        response.raise_for_status()
        time.sleep(1)
        return {"ok": True, "queue": snapshot}

def stop_comfy_backend() -> dict[str, Any]:
    with _COMFY_CONTROL_LOCK:
        snapshot = _require_all_queues_idle("останавливать AI-движок")
        if not snapshot["online"]:
            return {"ok": True, "already_offline": True}
        stopped = _stop_comfy_listener()
        if not stopped:
            raise RuntimeError("AI-движок не остановился за отведённое время")
        return {"ok": True, "online": False}

def restart_comfy_backend() -> dict[str, Any]:
    with _COMFY_CONTROL_LOCK:
        _require_all_queues_idle("перезапускать AI-движок")
        if _port_open(8188) and not _stop_comfy_listener():
            raise RuntimeError("AI-движок не остановился перед перезапуском")
        ensure_comfy()
        return {"ok": True, "online": _port_open(8188)}

def apply_runtime_settings(
    output_directory: Any,
    performance_profile: Any,
    vram_policy: Any = None,
    vram_idle_minutes: Any = None,
    backend_policy: Any = None,
    backend_idle_minutes: Any = None,
) -> dict[str, Any]:
    if JOBS.active_jobs():
        raise RuntimeError("Нельзя менять runtime-настройки во время активной задачи")
    profile = str(performance_profile or "auto").strip().lower()
    if profile not in _PERFORMANCE_PROFILES:
        raise ValueError("Неизвестный профиль производительности")
    target, free = _validate_output_directory(output_directory)
    with _RUNTIME_SETTINGS_LOCK:
        previous = _runtime_settings_unlocked()
        policy_input = {
            "vram_policy": previous.get("vram_policy") if vram_policy is None else vram_policy,
            "vram_idle_minutes": previous.get("vram_idle_minutes") if vram_idle_minutes is None else vram_idle_minutes,
            "backend_policy": previous.get("backend_policy") if backend_policy is None else backend_policy,
            "backend_idle_minutes": previous.get("backend_idle_minutes") if backend_idle_minutes is None else backend_idle_minutes,
        }
        lifecycle = lifecycle_policy.normalize_policy_settings(policy_input)
        known = list(previous.get("known_output_directories") or [])
        for value in (previous.get("output_directory"), str(target), str(DEFAULT_OUTPUT.resolve())):
            if not value:
                continue
            canonical = str(_canonical_directory(value))
            if canonical.lower() not in {str(x).lower() for x in known}:
                known.append(canonical)
        updated = {
            "version": 2,
            "output_directory": str(target),
            "performance_profile": profile,
            "known_output_directories": known,
            **lifecycle,
        }
        restart_required = (
            str(previous.get("output_directory", "")).lower() != str(target).lower()
            or str(previous.get("performance_profile", "auto")) != profile
        )
        policy_changed = any(
            previous.get(key) != updated.get(key)
            for key in ("vram_policy", "vram_idle_minutes", "backend_policy", "backend_idle_minutes")
        )
        changed = restart_required or policy_changed
        if changed:
            _write_runtime_settings_unlocked(updated)
    restarted = False
    if restart_required and _port_open(8188):
        try:
            restart_comfy_backend()
            restarted = True
        except Exception as exc:
            with _RUNTIME_SETTINGS_LOCK:
                _write_runtime_settings_unlocked(previous)
            try:
                restart_comfy_backend()
            except Exception:
                pass
            raise RuntimeError(f"Не удалось применить runtime-настройки; предыдущие восстановлены: {exc}") from exc
    current = runtime_settings()
    current.update({
        "changed": changed,
        "restart_required": restart_required,
        "policy_changed": policy_changed,
        "restarted": restarted,
        "output_free_bytes": free,
    })
    return current

class LifecycleController:
    POLL_SECONDS = 2.0

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_activity = time.monotonic()
        self._vram_done = False
        self._backend_done = False
        self._last_action = "none"
        self._last_error = ""

    def start(self) -> None:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._last_activity = time.monotonic()
            self._vram_done = False
            self._backend_done = False
            self._last_error = ""
            self._thread = threading.Thread(
                target=self._loop,
                name="LocalGenLifecycleController",
                daemon=True,
            )
            self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        with self._lock:
            thread = self._thread
            self._stop.set()
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=max(0.0, float(timeout)))
        with self._lock:
            if self._thread is thread and (not thread or not thread.is_alive()):
                self._thread = None

    def note_activity(self) -> None:
        with self._lock:
            self._last_activity = time.monotonic()
            self._vram_done = False
            self._backend_done = False
            self._last_action = "activity"
            self._last_error = ""

    def status(self) -> dict[str, Any]:
        with self._lock:
            thread = self._thread
            return {
                "running": bool(thread and thread.is_alive()),
                "last_action": self._last_action,
                "last_error": self._last_error,
                "idle_seconds": max(0.0, time.monotonic() - self._last_activity),
                "vram_done": self._vram_done,
                "backend_done": self._backend_done,
            }

    def _snapshot(self) -> lifecycle_policy.QueueSnapshot:
        comfy = comfy_queue_snapshot()
        return lifecycle_policy.QueueSnapshot(
            local_active=len(JOBS.active_jobs()),
            comfy_running=int(comfy.get("running") or 0),
            comfy_pending=int(comfy.get("pending") or 0),
            comfy_known=bool(comfy.get("known")),
            backend_online=bool(comfy.get("online")),
        )

    def _loop(self) -> None:
        while not self._stop.wait(self.POLL_SECONDS):
            try:
                snapshot = self._snapshot()
                now = time.monotonic()
                if not snapshot.idle:
                    self.note_activity()
                    continue

                with self._lock:
                    idle_seconds = max(0.0, now - self._last_activity)
                    vram_done = self._vram_done
                    backend_done = self._backend_done

                decision = lifecycle_policy.decide_idle_actions(
                    runtime_settings(),
                    snapshot,
                    idle_seconds,
                    vram_done=vram_done,
                    backend_done=backend_done,
                )
                if decision.stop_backend:
                    stop_comfy_backend()
                    with self._lock:
                        self._backend_done = True
                        self._vram_done = True
                        self._last_action = "backend_stopped"
                        self._last_error = ""
                elif decision.free_vram:
                    free_comfy_memory()
                    with self._lock:
                        self._vram_done = True
                        self._last_action = "vram_freed"
                        self._last_error = ""
            except Exception as exc:
                with self._lock:
                    self._last_error = str(exc)
                self._stop.wait(self.POLL_SECONDS)


LIFECYCLE_CONTROLLER = LifecycleController()


def start_lifecycle_controller() -> dict[str, Any]:
    LIFECYCLE_CONTROLLER.start()
    return LIFECYCLE_CONTROLLER.status()


def stop_lifecycle_controller(timeout: float = 5.0) -> dict[str, Any]:
    LIFECYCLE_CONTROLLER.stop(timeout)
    return LIFECYCLE_CONTROLLER.status()


def notify_lifecycle_activity() -> None:
    LIFECYCLE_CONTROLLER.note_activity()


def lifecycle_state() -> dict[str, Any]:
    return LIFECYCLE_CONTROLLER.status()

def inspect_quality_regions(image_path: str) -> dict[str, Any]:
    image = _require_existing_file(image_path, "изображение", suffixes={".png",".jpg",".jpeg",".webp",".bmp"})
    if JOBS.active_jobs():
        raise RuntimeError("Проверку деталей можно запустить после завершения текущей очереди")
    command = [str(COMFY_PY), str(TOOLS / "inspect_quality_regions.py"), str(image)]
    completed = subprocess.run(
        command,
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=240,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "DWPose inspection failed").strip()
        raise RuntimeError(detail[-1800:])
    payload = None
    for line in reversed(completed.stdout.splitlines()):
        if line.startswith("QUALITY_REGIONS "):
            payload = json.loads(line.split(" ", 1)[1])
            break
    if not isinstance(payload, dict) or not payload.get("ok"):
        raise RuntimeError("DWPose не вернул список областей")
    return payload


def create_quality_region_mask(image_path: str, bbox: list[Any], kind: str) -> dict[str, Any]:
    from PIL import ImageDraw, ImageFilter
    image = _require_existing_file(image_path, "изображение", suffixes={".png",".jpg",".jpeg",".webp",".bmp"})
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        raise ValueError("Некорректная область")
    try:
        x0, y0, x1, y1 = [float(v) for v in bbox]
    except Exception as exc:
        raise ValueError("Некорректная область") from exc
    if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
        raise ValueError("Область должна быть нормализована от 0 до 1")
    kind = str(kind or "face")
    if kind not in {"face", "left_hand", "right_hand"}:
        raise ValueError("Неизвестный тип области")
    with Image.open(image) as src:
        width, height = src.size
    bx0, by0, bx1, by1 = x0 * width, y0 * height, x1 * width, y1 * height
    bw, bh = max(1.0, bx1 - bx0), max(1.0, by1 - by0)
    if kind == "face":
        pad_x, pad_y = bw * 0.24, bh * 0.24
    else:
        pad_x, pad_y = bw * 0.42, bh * 0.42
    px0=max(0,int(round(bx0-pad_x))); py0=max(0,int(round(by0-pad_y)))
    px1=min(width,int(round(bx1+pad_x))); py1=min(height,int(round(by1+pad_y)))
    if px1-px0 < 8 or py1-py0 < 8:
        raise ValueError("Найденная область слишком мала для ремонта")
    mask=Image.new("L",(width,height),0)
    draw=ImageDraw.Draw(mask)
    box=(px0,py0,px1,py1)
    if kind=="face":
        draw.ellipse(box,fill=255)
    else:
        radius=max(4,int(min(px1-px0,py1-py0)*0.28))
        draw.rounded_rectangle(box,radius=radius,fill=255)
    blur=max(2.0,min(10.0,min(width,height)*0.004))
    mask=mask.filter(ImageFilter.GaussianBlur(radius=blur))
    target=APP/"data"/f"quality_region_mask_{uuid.uuid4().hex[:10]}.png"
    target.parent.mkdir(parents=True,exist_ok=True)
    mask.save(target)
    return {
        "ok": True,
        "path": str(target),
        "kind": kind,
        "bbox_px": [px0,py0,px1,py1],
        "bbox": [round(px0/width,6),round(py0/height,6),round(px1/width,6),round(py1/height,6)],
        "width": width,
        "height": height,
    }


TEMP_STALE_SECONDS = 24 * 60 * 60

def _clean_temp_files(max_age_seconds: float | None = None) -> dict[str, Any]:
    _require_all_queues_idle("очищать временные файлы")
    threshold = None if max_age_seconds is None else max(0.0, float(max_age_seconds))
    now = time.time()
    removed = 0
    freed = 0
    skipped = 0
    for p in _temp_file_candidates():
        try:
            stat = p.stat()
            if threshold is not None and max(0.0, now - stat.st_mtime) < threshold:
                skipped += 1
                continue
            size = stat.st_size
            p.unlink()
            removed += 1
            freed += size
        except Exception:
            pass
    return {"ok": True, "removed": removed, "freed": freed, "skipped": skipped}

def clean_temp_files() -> dict[str, Any]:
    return _clean_temp_files(None)

def clean_stale_temp_files(max_age_seconds: float = TEMP_STALE_SECONDS) -> dict[str, Any]:
    return _clean_temp_files(max_age_seconds)

def backend_state() -> dict[str, Any]:
    stats: dict[str, Any] = {}
    online = _port_open(8188)
    if online:
        try:
            stats = requests.get(COMFY_URL + "/system_stats", timeout=1.5).json()
        except Exception:
            stats = {}
    return {
        "app_version": APP_VERSION,
        "comfy_online": online,
        "models": [_model_public(v, k) for k, v in MODEL_REGISTRY.items()],
        "aspect_presets": ASPECT_PRESETS,
        "system": stats,
        "translator_available": _translator_installed(),
        "runtime_settings": runtime_settings(),
        "lifecycle": lifecycle_state(),
    }
def save_data_url(data_url: str, *, prefix: str = "input", suffix: str = ".png") -> str:
    if "," not in data_url:
        raise ValueError("Некорректные данные изображения")
    header, encoded = data_url.split(",", 1)
    raw = base64.b64decode(encoded)
    target = APP / "data" / f"{prefix}_{uuid.uuid4().hex[:10]}{suffix}"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    return str(target)

def list_recent_outputs(limit: int = 60) -> list[dict[str, Any]]:
    roots: list[Path] = []
    for output_root in known_output_roots():
        for candidate in (output_root / "LocalGen", output_root / "video" / "LocalGen"):
            if str(candidate).lower() not in {str(x).lower() for x in roots}:
                roots.append(candidate)
    items: list[Path] = []
    for root in roots:
        if root.exists():
            items.extend(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in {".png",".jpg",".jpeg",".webp",".mp4",".webm",".mov"})
    items.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    history = _job_history_index()
    out: list[dict[str, Any]] = []
    for p in items[:max(1, min(int(limit), 200))]:
        st = p.stat()
        key = str(p.resolve()).lower()
        job = history.get(key)
        out.append({
            "path": str(p), "url": p.resolve().as_uri(), "name": p.name,
            "type": "video" if p.suffix.lower() in {".mp4",".webm",".mov"} else "image",
            "modified": st.st_mtime, "bytes": st.st_size,
            "job": job,
        })
    return out

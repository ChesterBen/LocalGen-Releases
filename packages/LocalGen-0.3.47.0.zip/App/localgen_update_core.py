from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import re
import shutil
import stat
import uuid
import zipfile
from pathlib import Path

if os.name == "nt":
    import msvcrt
else:
    import fcntl
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

UPDATE_FORMAT = "localgen-update"
UPDATE_SCHEMA = 1
_ALLOWED_ROOTS = ("App/", "Tools/")
_FORBIDDEN_PREFIXES = (
    "App/data/",
    "App/.venv/",
    "App/build/",
    "App/__pycache__/",
    "Tools/__pycache__/",
)
_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")
_WINDOWS_FORBIDDEN_CHARS = frozenset('<>:"|?*')
_WINDOWS_RESERVED_BASENAMES = frozenset({
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
    "COM¹", "COM²", "COM³", "LPT¹", "LPT²", "LPT³",
})


class UpdateError(RuntimeError):
    pass


def _acquire_apply_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open("a+b")
    try:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"\0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            raise UpdateError("Другое применение обновления уже выполняется") from exc
        stream.seek(0)
        stream.truncate()
        stream.write(str(os.getpid()).encode("ascii"))
        stream.flush()
        return stream
    except Exception:
        stream.close()
        raise


def _release_apply_lock(stream) -> None:
    try:
        stream.seek(0)
        if os.name == "nt":
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
    finally:
        stream.close()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _parse_version(value: Any) -> tuple[int, int, int, int]:
    raw = str(value or "").strip()
    parts = raw.split(".")
    if not 2 <= len(parts) <= 4 or any(not p.isdigit() for p in parts):
        raise UpdateError(f"Некорректная версия: {raw!r}")
    nums = [int(p) for p in parts]
    nums.extend([0] * (4 - len(nums)))
    if any(n < 0 or n > 65535 for n in nums):
        raise UpdateError(f"Версия вне допустимого диапазона: {raw!r}")
    return tuple(nums)  # type: ignore[return-value]


def _canonical_payload(manifest: dict[str, Any]) -> bytes:
    payload = copy.deepcopy(manifest)
    payload.pop("signature", None)
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
def _normalize_relative_path(value: Any) -> str:
    raw = str(value or "").replace("\\", "/")
    if raw != raw.strip():
        raise UpdateError(f"Недопустимый путь обновления: {value!r}")
    while "//" in raw:
        raw = raw.replace("//", "/")
    if not raw or raw.startswith("/") or re.match(r"^[A-Za-z]:", raw):
        raise UpdateError(f"Недопустимый путь обновления: {value!r}")
    parts = raw.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise UpdateError(f"Недопустимый путь обновления: {value!r}")
    for part in parts:
        if part.startswith(" ") or part.endswith((" ", ".")):
            raise UpdateError(f"Недопустимое Windows-имя в пути обновления: {part!r}")
        if any(ord(ch) < 32 or ch in _WINDOWS_FORBIDDEN_CHARS for ch in part):
            raise UpdateError(f"Недопустимое Windows-имя в пути обновления: {part!r}")
        basename = part.split(".", 1)[0].upper()
        if basename in _WINDOWS_RESERVED_BASENAMES:
            raise UpdateError(f"Зарезервированное Windows-имя в пути обновления: {part!r}")
    normalized = "/".join(parts)
    if not normalized.startswith(_ALLOWED_ROOTS):
        raise UpdateError(f"Обновление не может менять этот путь: {normalized}")
    folded = normalized.casefold()
    if any(folded.startswith(prefix.casefold()) for prefix in _FORBIDDEN_PREFIXES):
        raise UpdateError(f"Защищённый путь нельзя обновлять: {normalized}")
    return normalized


def _decode_public_key(value: bytes | str) -> bytes:
    if isinstance(value, bytes):
        raw = value
    else:
        try:
            raw = base64.b64decode(str(value), validate=True)
        except Exception as exc:
            raise UpdateError("Некорректный публичный ключ обновлений") from exc
    if len(raw) != 32:
        raise UpdateError("Ed25519 public key должен содержать 32 байта")
    return raw
def verify_manifest_signature(
    manifest: dict[str, Any],
    public_keys: dict[str, bytes | str],
) -> str:
    signature = manifest.get("signature")
    if not isinstance(signature, dict):
        raise UpdateError("Манифест обновления не подписан")
    if str(signature.get("algorithm") or "").lower() != "ed25519":
        raise UpdateError("Поддерживается только подпись Ed25519")
    key_id = str(signature.get("key_id") or "").strip()
    if not key_id or key_id not in public_keys:
        raise UpdateError("Неизвестный ключ подписи обновления")
    try:
        signature_bytes = base64.b64decode(
            str(signature.get("value") or ""),
            validate=True,
        )
    except Exception as exc:
        raise UpdateError("Некорректная подпись обновления") from exc
    try:
        Ed25519PublicKey.from_public_bytes(
            _decode_public_key(public_keys[key_id])
        ).verify(signature_bytes, _canonical_payload(manifest))
    except InvalidSignature as exc:
        raise UpdateError("Подпись обновления не прошла проверку") from exc
    except ValueError as exc:
        raise UpdateError("Некорректная Ed25519 подпись обновления") from exc
    return key_id
def validate_manifest(
    manifest: dict[str, Any],
    *,
    current_version: str,
    public_keys: dict[str, bytes | str],
    require_newer: bool = False,
    allow_non_https: bool = False,
) -> dict[str, Any]:
    if not isinstance(manifest, dict):
        raise UpdateError("Манифест обновления должен быть JSON-объектом")
    if manifest.get("format") != UPDATE_FORMAT:
        raise UpdateError("Неизвестный формат обновления")
    if int(manifest.get("schema") or 0) != UPDATE_SCHEMA:
        raise UpdateError("Неподдерживаемая версия схемы обновления")
    channel = str(manifest.get("channel") or "").strip().lower()
    if channel not in {"stable"}:
        raise UpdateError("Неподдерживаемый канал обновлений")
    version = str(manifest.get("version") or "").strip()
    parsed_target = _parse_version(version)
    parsed_current = _parse_version(current_version)
    is_newer = parsed_target > parsed_current
    if require_newer and not is_newer:
        raise UpdateError("Пакет не новее установленной версии")
    key_id = verify_manifest_signature(manifest, public_keys)
    package = manifest.get("package")
    if not isinstance(package, dict):
        raise UpdateError("В манифесте отсутствует описание пакета")
    url = str(package.get("url") or "").strip()
    if not allow_non_https and not url.lower().startswith("https://"):
        raise UpdateError("Пакет обновления должен загружаться только по HTTPS")
    package_size = int(package.get("size") or 0)
    package_sha = str(package.get("sha256") or "").lower()
    if package_size <= 0:
        raise UpdateError("Некорректный размер пакета обновления")
    if not _SHA256_RE.fullmatch(package_sha):
        raise UpdateError("Некорректный SHA-256 пакета обновления")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise UpdateError("Манифест не содержит файлов обновления")
    normalized_files: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in files:
        if not isinstance(item, dict):
            raise UpdateError("Некорректная запись файла в манифесте")
        rel = _normalize_relative_path(item.get("path"))
        folded = rel.casefold()
        if folded in seen:
            raise UpdateError(f"Путь повторяется в манифесте: {rel}")
        seen.add(folded)
        size = int(item.get("size") if item.get("size") is not None else -1)
        sha = str(item.get("sha256") or "").lower()
        if size < 0 or not _SHA256_RE.fullmatch(sha):
            raise UpdateError(f"Некорректные метаданные файла: {rel}")
        normalized_files.append({"path": rel, "size": size, "sha256": sha})
    return {
        "version": version,
        "current_version": current_version,
        "is_newer": is_newer,
        "channel": channel,
        "key_id": key_id,
        "package": {"url": url, "size": package_size, "sha256": package_sha},
        "files": normalized_files,
        "notes": str(manifest.get("notes") or ""),
    }


def _assert_within(root: Path, path: Path) -> None:
    root_real = root.resolve()
    candidate = path.resolve(strict=False)
    try:
        candidate.relative_to(root_real)
    except ValueError as exc:
        raise UpdateError(f"Путь выходит за корень обновления: {path}") from exc


def _zip_member_is_symlink(info: zipfile.ZipInfo) -> bool:
    unix_mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_IFMT(unix_mode) == stat.S_IFLNK


def verify_and_extract_package(
    package_path: Path,
    manifest_info: dict[str, Any],
    staging_root: Path,
) -> list[str]:
    package_path = package_path.resolve()
    expected_package = manifest_info["package"]
    if package_path.stat().st_size != int(expected_package["size"]):
        raise UpdateError("Размер пакета обновления не совпадает с манифестом")
    if sha256_file(package_path) != str(expected_package["sha256"]).lower():
        raise UpdateError("SHA-256 пакета обновления не совпадает с манифестом")
    expected = {item["path"]: item for item in manifest_info["files"]}
    staging_root.mkdir(parents=True, exist_ok=True)
    extracted: list[str] = []
    with zipfile.ZipFile(package_path, "r") as archive:
        actual_files: dict[str, zipfile.ZipInfo] = {}
        for info in archive.infolist():
            name = info.filename.replace("\\", "/")
            if info.is_dir():
                continue
            rel = _normalize_relative_path(name)
            if _zip_member_is_symlink(info):
                raise UpdateError(f"Символические ссылки запрещены в пакете: {rel}")
            if rel in actual_files:
                raise UpdateError(f"Файл повторяется в ZIP: {rel}")
            actual_files[rel] = info
        if set(actual_files) != set(expected):
            missing = sorted(set(expected) - set(actual_files))
            extra = sorted(set(actual_files) - set(expected))
            raise UpdateError(f"Состав ZIP не совпадает: missing={missing}, extra={extra}")
        for rel, item in expected.items():
            info = actual_files[rel]
            if info.file_size != int(item["size"]):
                raise UpdateError(f"Размер файла в ZIP не совпадает: {rel}")
            target = staging_root / Path(rel)
            _assert_within(staging_root, target)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            if sha256_file(target) != str(item["sha256"]).lower():
                raise UpdateError(f"SHA-256 файла не совпадает после распаковки: {rel}")
            extracted.append(rel)
    return extracted
def _copy_replace(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(f".{target.name}.localgen-update-{uuid.uuid4().hex}.tmp")
    try:
        shutil.copy2(source, temp)
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)


def apply_transaction(
    project_root: Path,
    staging_root: Path,
    manifest_info: dict[str, Any],
    backup_root: Path,
    *,
    fail_after: int | None = None,
) -> dict[str, Any]:
    project_root = project_root.resolve()
    staging_root = staging_root.resolve()
    backup_root = backup_root.resolve()
    backup_root.mkdir(parents=True, exist_ok=True)
    lock = backup_root.parent / ".apply.lock"
    lock_stream = _acquire_apply_lock(lock)
    records: list[dict[str, Any]] = []
    try:
        for index, item in enumerate(manifest_info["files"], start=1):
            rel = str(item["path"])
            source = staging_root / Path(rel)
            target = project_root / Path(rel)
            backup = backup_root / Path(rel)
            _assert_within(staging_root, source)
            _assert_within(project_root, target)
            _assert_within(backup_root, backup)
            if not source.is_file():
                raise UpdateError(f"Не найден staged файл: {rel}")
            target_parent = target.parent.resolve(strict=False)
            _assert_within(project_root, target_parent)
            existed = target.exists()
            if existed and not target.is_file():
                raise UpdateError(f"Целевой путь не является файлом: {rel}")
            old_sha = sha256_file(target) if existed else None
            if existed:
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup)
            records.append({
                "path": rel,
                "existed": existed,
                "old_sha256": old_sha,
                "backup": str(backup) if existed else "",
            })
            _copy_replace(source, target)
            if sha256_file(target) != str(item["sha256"]).lower():
                raise UpdateError(f"Проверка установленного файла не пройдена: {rel}")
            if fail_after is not None and index >= fail_after:
                raise UpdateError("Искусственная ошибка применения для проверки rollback")
        return {"ok": True, "applied": [r["path"] for r in records], "rollback": False}
    except Exception as exc:
        rollback_errors: list[str] = []
        for record in reversed(records):
            rel = record["path"]
            target = project_root / Path(rel)
            try:
                if record["existed"]:
                    backup = Path(record["backup"])
                    _copy_replace(backup, target)
                    if sha256_file(target) != record["old_sha256"]:
                        raise UpdateError("hash mismatch after rollback")
                else:
                    target.unlink(missing_ok=True)
            except Exception as rollback_exc:
                rollback_errors.append(f"{rel}: {rollback_exc}")
        if rollback_errors:
            raise UpdateError(
                f"Применение не удалось: {exc}; rollback неполный: {rollback_errors}"
            ) from exc
        raise UpdateError(f"Применение отменено, rollback выполнен: {exc}") from exc
    finally:
        _release_apply_lock(lock_stream)

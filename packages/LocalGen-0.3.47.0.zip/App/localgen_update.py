from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

import requests

from localgen_update_core import (
    UpdateError,
    apply_transaction,
    sha256_file,
    validate_manifest,
)

MANIFEST_MAX_BYTES = 512 * 1024
DOWNLOAD_CHUNK = 1024 * 1024
MIN_DISK_HEADROOM = 64 * 1024 * 1024


def _manifest_file_bytes(info: dict[str, Any]) -> int:
    return sum(max(0, int(item.get("size") or 0)) for item in info.get("files") or [])


def _existing_target_bytes(project_root: Path, info: dict[str, Any]) -> tuple[int, int]:
    total = 0
    largest = 0
    for item in info.get("files") or []:
        target = project_root / Path(str(item.get("path") or ""))
        try:
            size = target.stat().st_size if target.is_file() else 0
        except OSError:
            size = 0
        total += max(0, int(size))
        largest = max(largest, max(0, int(size)))
    return total, largest


def _ensure_disk_space(path: Path, required_bytes: int, phase: str) -> int:
    path.mkdir(parents=True, exist_ok=True)
    free = int(shutil.disk_usage(path).free)
    required = max(0, int(required_bytes))
    if free < required:
        raise UpdateError(
            f"Недостаточно места для {phase}: нужно примерно {required / 1024**3:.2f} ГБ, "
            f"свободно {free / 1024**3:.2f} ГБ"
        )
    return free


def _ensure_apply_disk_space(project_root: Path, backup_root: Path, info: dict[str, Any]) -> None:
    backup_total, largest_old = _existing_target_bytes(project_root, info)
    largest_new = max([0, *(max(0, int(item.get("size") or 0)) for item in info.get("files") or [])])
    temp_peak = max(largest_old, largest_new)
    backup_parent = backup_root.parent
    backup_parent.mkdir(parents=True, exist_ok=True)
    project_drive = project_root.resolve().drive.casefold()
    backup_drive = backup_parent.resolve().drive.casefold()
    if project_drive and backup_drive and project_drive != backup_drive:
        _ensure_disk_space(backup_parent, backup_total + MIN_DISK_HEADROOM, "rollback backup")
        _ensure_disk_space(project_root, temp_peak + MIN_DISK_HEADROOM, "atomic replace")
    else:
        _ensure_disk_space(project_root, backup_total + temp_peak + MIN_DISK_HEADROOM, "применения обновления")


def write_json_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)
def fetch_manifest_https(url: str, *, timeout: tuple[int, int] = (5, 20)) -> dict[str, Any]:
    url = str(url or "").strip()
    if not url.lower().startswith("https://"):
        raise UpdateError("Манифест обновлений должен загружаться только по HTTPS")
    with requests.get(
        url,
        stream=True,
        timeout=timeout,
        allow_redirects=True,
        headers={"User-Agent": "LocalGen-Updater/1.0", "Accept-Encoding": "identity"},
    ) as response:
        response.raise_for_status()
        if not str(response.url).lower().startswith("https://"):
            raise UpdateError("HTTPS-запрос обновления был перенаправлен на небезопасный адрес")
        raw_length = response.headers.get("Content-Length")
        try:
            length = int(raw_length) if raw_length not in {None, ""} else 0
        except (TypeError, ValueError) as exc:
            raise UpdateError("Сервер сообщил некорректный размер манифеста") from exc
        if length < 0 or length > MANIFEST_MAX_BYTES:
            raise UpdateError("Манифест обновления слишком большой")
        content = bytearray()
        for chunk in response.iter_content(chunk_size=64 * 1024):
            if not chunk:
                continue
            if len(content) + len(chunk) > MANIFEST_MAX_BYTES:
                raise UpdateError("Манифест обновления слишком большой")
            content.extend(chunk)
        content = bytes(content)
    try:
        data = json.loads(content.decode("utf-8"))
    except Exception as exc:
        raise UpdateError("Манифест обновления не является корректным UTF-8 JSON") from exc
    if not isinstance(data, dict):
        raise UpdateError("Манифест обновления должен быть JSON-объектом")
    return data
def download_verified_package(
    url: str,
    target: Path,
    *,
    expected_size: int,
    expected_sha256: str,
    timeout: tuple[int, int] = (5, 60),
) -> Path:
    url = str(url or "").strip()
    if not url.lower().startswith("https://"):
        raise UpdateError("Пакет обновления должен загружаться только по HTTPS")
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_suffix(target.suffix + ".part")
    part.unlink(missing_ok=True)
    total = 0
    import hashlib
    digest = hashlib.sha256()
    try:
        with requests.get(
            url,
            stream=True,
            timeout=timeout,
            allow_redirects=True,
            headers={"User-Agent": "LocalGen-Updater/1.0", "Accept-Encoding": "identity"},
        ) as response:
            response.raise_for_status()
            if not str(response.url).lower().startswith("https://"):
                raise UpdateError("HTTPS-загрузка обновления была перенаправлена на небезопасный адрес")
            announced = int(response.headers.get("Content-Length") or 0)
            if announced and announced != int(expected_size):
                raise UpdateError("Сервер сообщил неожиданный размер пакета обновления")
            for chunk in response.iter_content(chunk_size=DOWNLOAD_CHUNK):
                if not chunk:
                    continue
                total += len(chunk)
                if total > int(expected_size):
                    raise UpdateError("Пакет обновления превысил ожидаемый размер")
                digest.update(chunk)
                with part.open("ab") as stream:
                    stream.write(chunk)
        if total != int(expected_size):
            raise UpdateError("Загружен неполный пакет обновления")
        if digest.hexdigest().lower() != str(expected_sha256).lower():
            raise UpdateError("SHA-256 загруженного пакета не совпадает")
        os.replace(part, target)
        return target
    except Exception:
        part.unlink(missing_ok=True)
        raise


def verify_staged_files(staging_root: Path, manifest_info: dict[str, Any]) -> None:
    for item in manifest_info["files"]:
        rel = str(item["path"])
        path = staging_root / Path(rel)
        if not path.is_file():
            raise UpdateError(f"В staging отсутствует файл: {rel}")
        if path.stat().st_size != int(item["size"]):
            raise UpdateError(f"Размер staged файла не совпадает: {rel}")
        if sha256_file(path) != str(item["sha256"]).lower():
            raise UpdateError(f"SHA-256 staged файла не совпадает: {rel}")
def wait_for_pids(pids: list[int], timeout_seconds: int = 120) -> None:
    pending = {int(pid) for pid in pids if int(pid) > 0 and int(pid) != os.getpid()}
    if not pending:
        return
    deadline = time.monotonic() + max(1, int(timeout_seconds))
    kernel32 = ctypes.windll.kernel32 if os.name == "nt" else None
    SYNCHRONIZE = 0x00100000
    while pending:
        if time.monotonic() >= deadline:
            raise UpdateError(f"Процессы LocalGen не завершились: {sorted(pending)}")
        finished: list[int] = []
        for pid in pending:
            if kernel32 is None:
                try:
                    os.kill(pid, 0)
                except OSError:
                    finished.append(pid)
                continue
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if not handle:
                finished.append(pid)
                continue
            try:
                result = kernel32.WaitForSingleObject(handle, 0)
                if result == 0:
                    finished.append(pid)
            finally:
                kernel32.CloseHandle(handle)
        pending.difference_update(finished)
        if pending:
            time.sleep(0.1)
def run_apply_plan(plan_path: Path) -> dict[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    project_root = Path(plan["project_root"])
    staging_root = Path(plan["staging_root"])
    backup_root = Path(plan["backup_root"])
    manifest_path = Path(plan["manifest_path"])
    result_path = Path(plan["result_path"])
    current_version = str(plan["current_version"])
    public_keys = dict(plan["public_keys"])
    wait_pids = [int(x) for x in plan.get("wait_pids") or []]
    relaunch = str(plan.get("relaunch") or "").strip()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    info = validate_manifest(
        manifest,
        current_version=current_version,
        public_keys=public_keys,
        require_newer=True,
    )
    wait_for_pids(wait_pids, int(plan.get("wait_timeout_seconds") or 120))
    verify_staged_files(staging_root, info)
    _ensure_apply_disk_space(project_root, backup_root, info)
    started = time.time()
    try:
        outcome = apply_transaction(project_root, staging_root, info, backup_root)
        result = {
            "ok": True,
            "version": info["version"],
            "applied": outcome["applied"],
            "elapsed_seconds": round(time.time() - started, 3),
        }
    except Exception as exc:
        result = {
            "ok": False,
            "version": info["version"],
            "message": str(exc),
            "elapsed_seconds": round(time.time() - started, 3),
        }
    write_json_atomic(result_path, result)
    if relaunch:
        try:
            subprocess.Popen(
                [relaunch],
                cwd=str(Path(relaunch).parent),
                close_fds=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as exc:
            result["relaunch_error"] = str(exc)
            write_json_atomic(result_path, result)
    return result


def main(argv: list[str]) -> int:
    if len(argv) == 3 and argv[1] == "--apply-plan":
        try:
            result = run_apply_plan(Path(argv[2]))
            return 0 if result.get("ok") else 2
        except Exception as exc:
            try:
                plan = json.loads(Path(argv[2]).read_text(encoding="utf-8"))
                result_path = Path(plan["result_path"])
                write_json_atomic(result_path, {"ok": False, "message": str(exc)})
            except Exception:
                pass
            return 2
    print("LocalGen update runtime: no command", file=sys.stderr)
    return 64


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))


def _manager_synchronized(method):
    def wrapped(self, *args, **kwargs):
        with self._operation_lock:
            return method(self, *args, **kwargs)
    return wrapped


class UpdateManager:
    def __init__(
        self,
        project_root: Path,
        *,
        config_path: Path | None = None,
        data_dir: Path | None = None,
        module_path: Path | None = None,
    ) -> None:
        self.project_root = project_root.resolve()
        self.app_dir = self.project_root / "App"
        self.config_path = config_path or (self.app_dir / "update-source.json")
        self.data_dir = data_dir or (self.app_dir / "data" / "updates")
        self.module_path = module_path or Path(__file__).resolve()
        self.state_path = self.data_dir / "state.json"
        self.result_path = self.data_dir / "update-result.json"
        self._operation_lock = threading.RLock()

    def _config(self) -> dict[str, Any]:
        if not self.config_path.is_file():
            return {"manifest_url": "", "channel": "stable", "public_keys": {}}
        try:
            data = json.loads(self.config_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise UpdateError("Конфигурация обновлений повреждена") from exc
        if not isinstance(data, dict):
            raise UpdateError("Конфигурация обновлений должна быть JSON-объектом")
        keys = data.get("public_keys")
        return {
            "manifest_url": str(data.get("manifest_url") or "").strip(),
            "channel": str(data.get("channel") or "stable").strip().lower(),
            "public_keys": dict(keys) if isinstance(keys, dict) else {},
        }

    def _read_state(self) -> dict[str, Any]:
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except Exception:
            return {}

    def _write_state(self, payload: dict[str, Any]) -> None:
        write_json_atomic(self.state_path, payload)

    def _read_result(self) -> dict[str, Any]:
        try:
            data = json.loads(self.result_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except Exception:
            return {}

    def _ensure_not_applying(self) -> None:
        state = self._read_state()
        if str(state.get("status") or "") != "applying":
            return
        result = self._read_result()
        if isinstance(result.get("ok"), bool):
            return
        raise UpdateError("Применение обновления уже запущено")

    @_manager_synchronized
    def status(self, current_version: str) -> dict[str, Any]:
        config = self._config()
        state = self._read_state()
        result = self._read_result()
        source_configured = bool(
            config["manifest_url"].lower().startswith("https://")
            and config["public_keys"]
        )
        pending_version = str(state.get("version") or "")
        installed = bool(
            pending_version
            and _version_not_newer(pending_version, current_version)
            and result.get("ok") is True
        )
        status = str(state.get("status") or "idle")
        if result.get("ok") is False:
            status = "failed"
        elif installed:
            status = "installed"
        return {
            "ok": True,
            "current_version": current_version,
            "source_configured": source_configured,
            "channel": config["channel"],
            "status": status,
            "version": pending_version,
            "notes": str(state.get("notes") or ""),
            "last_result": result,
        }

    def _accept_manifest(self, manifest: dict[str, Any], current_version: str) -> dict[str, Any]:
        config = self._config()
        info = validate_manifest(
            manifest,
            current_version=current_version,
            public_keys=config["public_keys"],
        )
        if not info["is_newer"]:
            self._write_state({
                "status": "current",
                "version": info["version"],
                "notes": info["notes"],
            })
            return {"ok": True, "update_available": False, **info}
        workspace = self.data_dir / info["version"]
        workspace.mkdir(parents=True, exist_ok=True)
        manifest_path = workspace / "manifest.json"
        write_json_atomic(manifest_path, manifest)
        self._write_state({
            "status": "available",
            "version": info["version"],
            "notes": info["notes"],
            "manifest_path": str(manifest_path),
        })
        return {"ok": True, "update_available": True, **info}

    @_manager_synchronized
    def check(self, current_version: str) -> dict[str, Any]:
        self._ensure_not_applying()
        config = self._config()
        url = config["manifest_url"]
        if not url:
            return {
                "ok": False,
                "code": "source_not_configured",
                "message": "Источник обновлений ещё не настроен",
            }
        manifest = fetch_manifest_https(url)
        return self._accept_manifest(manifest, current_version)

    def _pending(self, current_version: str) -> tuple[dict[str, Any], dict[str, Any], Path]:
        state = self._read_state()
        manifest_path = Path(str(state.get("manifest_path") or ""))
        if not manifest_path.is_file():
            raise UpdateError("Сначала нужно проверить наличие обновлений")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        config = self._config()
        info = validate_manifest(
            manifest,
            current_version=current_version,
            public_keys=config["public_keys"],
            require_newer=True,
        )
        return state, info, manifest_path

    @_manager_synchronized
    def stage_from_file(self, current_version: str, package_path: Path) -> dict[str, Any]:
        self._ensure_not_applying()
        state, info, manifest_path = self._pending(current_version)
        workspace = manifest_path.parent
        staging = workspace / "staging"
        if staging.exists():
            shutil.rmtree(staging)
        _ensure_disk_space(workspace, _manifest_file_bytes(info) + MIN_DISK_HEADROOM, "распаковки обновления")
        from localgen_update_core import verify_and_extract_package
        try:
            extracted = verify_and_extract_package(package_path, info, staging)
        except Exception:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        self._write_state({
            **state,
            "status": "staged",
            "staging_root": str(staging),
            "package_path": str(package_path),
        })
        return {"ok": True, "status": "staged", "version": info["version"], "files": len(extracted)}

    @_manager_synchronized
    def download(self, current_version: str) -> dict[str, Any]:
        self._ensure_not_applying()
        state, info, manifest_path = self._pending(current_version)
        workspace = manifest_path.parent
        package_path = workspace / "package.zip"
        package = info["package"]
        _ensure_disk_space(workspace, int(package["size"]) + MIN_DISK_HEADROOM, "скачивания обновления")
        download_verified_package(
            package["url"],
            package_path,
            expected_size=int(package["size"]),
            expected_sha256=str(package["sha256"]),
        )
        return self.stage_from_file(current_version, package_path)

    @_manager_synchronized
    def launch_apply(
        self,
        current_version: str,
        *,
        wait_pids: list[int],
        relaunch: str,
    ) -> dict[str, Any]:
        self._ensure_not_applying()
        state, info, manifest_path = self._pending(current_version)
        if str(state.get("status") or "") != "staged":
            raise UpdateError("Обновление ещё не загружено и не проверено")
        staging_root = Path(str(state.get("staging_root") or ""))
        verify_staged_files(staging_root, info)
        config = self._config()
        workspace = manifest_path.parent
        backup_root = self.data_dir / "backups" / info["version"]
        _ensure_apply_disk_space(self.project_root, backup_root, info)
        plan_path = workspace / "apply-plan.json"
        plan = {
            "project_root": str(self.project_root),
            "staging_root": str(staging_root),
            "backup_root": str(backup_root),
            "manifest_path": str(manifest_path),
            "result_path": str(self.result_path),
            "current_version": current_version,
            "public_keys": config["public_keys"],
            "wait_pids": [int(x) for x in wait_pids if int(x) > 0],
            "wait_timeout_seconds": 120,
            "relaunch": str(relaunch or ""),
        }
        write_json_atomic(plan_path, plan)
        self.result_path.unlink(missing_ok=True)
        pythonw = self.app_dir / ".venv" / "Scripts" / "pythonw.exe"
        if not pythonw.is_file():
            raise UpdateError("Не найден Python runtime для применения обновления")
        proc = subprocess.Popen(
            [str(pythonw), str(self.module_path), "--apply-plan", str(plan_path)],
            cwd=str(self.app_dir),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            close_fds=True,
        )
        self._write_state({**state, "status": "applying", "helper_pid": proc.pid})
        return {"ok": True, "status": "applying", "version": info["version"], "helper_pid": proc.pid}


def _version_not_newer(target: str, current: str) -> bool:
    def parts(value: str) -> tuple[int, ...]:
        values = [int(x) for x in str(value).split(".") if x.isdigit()]
        return tuple((values + [0, 0, 0, 0])[:4])
    try:
        return parts(target) <= parts(current)
    except Exception:
        return False

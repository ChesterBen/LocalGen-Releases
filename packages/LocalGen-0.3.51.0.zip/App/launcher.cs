using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;

[assembly: AssemblyTitle("LocalGen")]
[assembly: AssemblyProduct("LocalGen")]
[assembly: AssemblyDescription("LocalGen AI Studio")]
[assembly: AssemblyCompany("LocalGen")]
[assembly: AssemblyVersion("0.3.51.0")]
[assembly: AssemblyFileVersion("0.3.51.0")]

static class LocalGenLauncher
{
    const string MutexName = @"Local\LocalGen.App.Singleton.v1";
    const int SW_RESTORE = 9;

    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    static void ActivateExisting()
    {
        var h = FindWindow(null, "LocalGen");
        if (h != IntPtr.Zero)
        {
            ShowWindow(h, SW_RESTORE);
            SetForegroundWindow(h);
        }
    }

    [STAThread]
    static void Main()
    {
        bool created;
        using (var mutex = new Mutex(true, MutexName, out created))
        {
            if (!created)
            {
                ActivateExisting();
                return;
            }

            string app = @"C:\AI\LocalGen\App";
            string pythonw = Path.Combine(app, @".venv\Scripts\pythonw.exe");
            string script = Path.Combine(app, "localgen_app.py");

            if (!File.Exists(pythonw) || !File.Exists(script))
            {
                MessageBox.Show(
                    "Не найден runtime LocalGen.\nОжидался путь: " + app,
                    "LocalGen",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return;
            }

            var psi = new ProcessStartInfo
            {
                FileName = pythonw,
                Arguments = "\"" + script + "\"",
                WorkingDirectory = app,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            psi.EnvironmentVariables["PYTHONUTF8"] = "1";
            psi.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
            psi.EnvironmentVariables["LOCALGEN_LAUNCHER_PID"] = Process.GetCurrentProcess().Id.ToString();
            var child = Process.Start(psi);
            if (child == null) return;

            while (!child.HasExited)
            {
                Thread.Sleep(500);
            }
        }
    }
}



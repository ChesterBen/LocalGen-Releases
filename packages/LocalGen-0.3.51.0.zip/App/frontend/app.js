const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const PREF_KEY='localgen.preferences.v1';
const HISTORY_KEY='localgen.promptHistory.v1';
const USER_PRESET_KEY='localgen.userPresets.v1';
const FAVORITES_KEY='localgen.libraryFavorites.v1';
const UI_SCALE_DEFAULT=120,UI_SCALE_MIN=80,UI_SCALE_MAX=160,UI_SCALE_STEP=5;
let uiScaleWheelAccum=0,uiScaleToastTimer=0;
const state = {
  backend:null, view:'create', createModel:'sdxl_people', autoModel:true, autoRecommendation:null, autoRequestSeq:0, autoTimer:null, createCharacter:'', createReferences:[], createReferenceRoles:[], structureControl:'', structureMode:'canny', structureStrength:0.85, aspect:'square', createWidth:null, createHeight:null, createQuality:'standard', deliveryPreset:'native', expertOverrides:{}, batchCount:1, batchActive:false, batchCancelled:false,
  promptStyle:'auto', promptLighting:'auto', promptCamera:'auto', promptFraming:'auto',
  editMode:'smart', editSource:'', editMask:'', editReferences:['','',''], editReferenceRoles:['auto','auto','auto'], characters:[], animateSource:'',
  animateModel:'wan22_preview', frames:33, fps:16, animateSeconds:2, animateWidth:640, animateHeight:640, animateSeed:'', animateExpertOverrides:{}, enhanceType:'image',
  imageEnhanceMode:'omnisr', videoEnhanceMode:'seedvr2', enhanceSource:'', scale:2, lastOutput:'', lastOutputUrl:'', compareSource:'', pendingCompareSource:'', jobCompareSources:{},
  queueSnapshot:{running:[],pending:[],active_count:0,max_pending:20}, queuePollBusy:false,
  runtimeSettings:null, pendingRuntimeOutput:'', pendingPerformanceProfile:'auto', pendingVramPolicy:'keep', pendingVramIdleMinutes:10, pendingBackendPolicy:'keep', pendingBackendIdleMinutes:30, runtimeApplying:false,
  libraryFilter:'all', libraryQuery:'', libraryItems:[], lastJob:null, currentResultJob:null, modelInventory:null, modelInspection:null,
  qualityRegions:[], qualityRegionSelected:'', qualityInspectSource:'', qualityInspectBusy:false,
  variantScoreCache:{}, variantScoreRequestSeq:0,
  modelHubCandidates:[], modelHubCandidateId:'', modelDownloadJobId:'', modelDownloadHandled:'', modelDownloadPollTimer:0,
  updateState:null, updateBusy:false, updateCheckOnStart:false, updateAutoChecked:false,
  preserveFace:true, preserveBackground:true,
  motionStrength:'natural', cameraMotion:'static', preserveIdentity:true,
  historyTarget:'create', pendingCharacterSave:null,
  uiScale:UI_SCALE_DEFAULT,
  jobId:'', promptTimer:null, maximized:false,
};
function loadPrefs(){
  try{
    const p=JSON.parse(localStorage.getItem(PREF_KEY)||'{}');
    for(const k of ['createModel','autoModel','createCharacter','aspect','createWidth','createHeight','createQuality','deliveryPreset','expertOverrides','batchCount','structureMode','promptStyle','promptLighting','promptCamera','promptFraming','editMode','animateModel','frames','fps','animateSeconds','animateWidth','animateHeight','animateSeed','animateExpertOverrides','enhanceType','imageEnhanceMode','videoEnhanceMode','scale','preserveFace','preserveBackground','motionStrength','cameraMotion','preserveIdentity','uiScale','updateCheckOnStart']){
      if(p[k]!==undefined)state[k]=p[k];
    }
    if(p.promptMode)$('#promptMode').value=p.promptMode;
    if(p.editPromptMode)$('#editPromptMode').value=p.editPromptMode;
    if(p.motionPromptMode)$('#motionPromptMode').value=p.motionPromptMode;
  }catch{}
}
function savePrefs(){
  try{
    localStorage.setItem(PREF_KEY,JSON.stringify({
      createModel:state.createModel,autoModel:state.autoModel,createCharacter:state.createCharacter,aspect:state.aspect,createWidth:+$('#createWidth')?.value||state.createWidth||1024,createHeight:+$('#createHeight')?.value||state.createHeight||1024,createQuality:state.createQuality,deliveryPreset:state.deliveryPreset,expertOverrides:state.expertOverrides,batchCount:state.batchCount,structureMode:state.structureMode,
      promptStyle:state.promptStyle,promptLighting:state.promptLighting,promptCamera:state.promptCamera,promptFraming:state.promptFraming,
      editMode:state.editMode,
      animateModel:state.animateModel,frames:state.frames,fps:state.fps,animateSeconds:state.animateSeconds,animateWidth:state.animateWidth,animateHeight:state.animateHeight,animateSeed:state.animateSeed,animateExpertOverrides:state.animateExpertOverrides,
      enhanceType:state.enhanceType,imageEnhanceMode:state.imageEnhanceMode,videoEnhanceMode:state.videoEnhanceMode,scale:state.scale,
      preserveFace:state.preserveFace,preserveBackground:state.preserveBackground,
      motionStrength:state.motionStrength,cameraMotion:state.cameraMotion,preserveIdentity:state.preserveIdentity,
      uiScale:state.uiScale,updateCheckOnStart:state.updateCheckOnStart,
      promptMode:$('#promptMode').value,editPromptMode:$('#editPromptMode').value,motionPromptMode:$('#motionPromptMode').value
    }));
  }catch{}
}
function clampUiScale(value){
  const n=Math.round(Number(value)||UI_SCALE_DEFAULT);
  return Math.max(UI_SCALE_MIN,Math.min(UI_SCALE_MAX,n));
}
function syncUiScaleLayout(){
  const factor=Math.max(.01,state.uiScale/100);
  const logicalWidth=(window.innerWidth||1200)/factor;
  const root=document.documentElement;
  root.classList.toggle('ui-layout-narrow',logicalWidth<1050);
  root.classList.toggle('ui-layout-compact',logicalWidth<780);
}
function renderUiScaleControl(){
  const range=$('#uiScaleRange'),value=$('#uiScaleValue');
  if(range)range.value=String(state.uiScale);
  if(value)value.textContent=state.uiScale+'%';
  $$('[data-ui-scale-preset]').forEach(b=>b.classList.toggle('active',+b.dataset.uiScalePreset===state.uiScale));
}
function applyUiScale(value,{persist=true,announce=false}={}){
  state.uiScale=clampUiScale(value);
  const factor=state.uiScale/100;
  document.documentElement.style.setProperty('--ui-scale',String(factor));
  // NTE Helper donor pattern: keep the physical document at the exact WebView
  // viewport size and scale one compensated inner layer. Chromium CSS zoom on
  // body plus inverse body width/height produced right/bottom dead space.
  if(document.body){
    document.body.style.zoom='';
    document.body.style.width='';
    document.body.style.height='';
    document.body.style.transform='';
  }
  const layer=$('#scaleLayer');
  if(layer){
    layer.style.zoom='';
    layer.style.width=(100/factor).toFixed(4)+'%';
    layer.style.height=(100/factor).toFixed(4)+'%';
    layer.style.transform='scale('+factor+')';
  }
  syncUiScaleLayout();
  renderUiScaleControl();
  if(persist)savePrefs();
  if(announce){
    clearTimeout(uiScaleToastTimer);
    toast('Масштаб интерфейса: '+state.uiScale+'%');
    uiScaleToastTimer=setTimeout(()=>{},250);
  }
}
function stepUiScale(direction,announce=true){
  const next=clampUiScale(state.uiScale+(direction>0?UI_SCALE_STEP:-UI_SCALE_STEP));
  if(next===state.uiScale)return;
  applyUiScale(next,{persist:true,announce});
}
function isTextEntryTarget(target){
  const tag=String(target?.tagName||'').toLowerCase();
  return !!target?.isContentEditable||tag==='input'||tag==='textarea'||tag==='select';
}
function handleUiScaleWheel(event){
  if(!event.ctrlKey)return;
  const delta=Math.abs(event.deltaY)>=Math.abs(event.deltaX)?event.deltaY:event.deltaX;
  if(!delta)return;
  event.preventDefault();event.stopPropagation();
  uiScaleWheelAccum+=delta;
  if(Math.abs(uiScaleWheelAccum)<24)return;
  stepUiScale(uiScaleWheelAccum<0?1:-1,true);
  uiScaleWheelAccum=0;
}
function profileSnapshot(){
  let preferences={};try{preferences=JSON.parse(localStorage.getItem(PREF_KEY)||'{}')}catch{}
  return {
    preferences,
    prompt_history:promptHistory(),
    user_presets:userPresets(),
    favorites:[...favoritePaths()]
  };
}
async function exportProfile(){
  const r=await api('export_profile',profileSnapshot());
  if(r.ok)toast('Профиль сохранён');else if(!r.cancelled)toast(r.message||'Не удалось экспортировать профиль',true);
}
async function importProfile(){
  const r=await api('import_profile');
  if(!r.ok){if(!r.cancelled)toast(r.message||'Не удалось импортировать профиль',true);return}
  const p=r.profile||{};
  localStorage.setItem(PREF_KEY,JSON.stringify(p.preferences||{}));
  localStorage.setItem(HISTORY_KEY,JSON.stringify(p.prompt_history||[]));
  localStorage.setItem(USER_PRESET_KEY,JSON.stringify(p.user_presets||[]));
  localStorage.setItem(FAVORITES_KEY,JSON.stringify(p.favorites||[]));
  toast('Профиль импортирован');
  setTimeout(()=>location.reload(),350);
}
function clearPromptHistory(){
  localStorage.removeItem(HISTORY_KEY);
  toast('История запросов очищена');
}
function userPresets(){
  try{return JSON.parse(localStorage.getItem(USER_PRESET_KEY)||'[]')}catch{return []}
}
function renderUserPresets(){
  const select=$('#userPresetSelect'); if(!select)return;
  const items=userPresets();
  select.innerHTML='<option value="">Выбрать сохранённый пресет…</option>'+items.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>').join('');
  $('#deleteUserPreset').disabled=!select.value;
}
function applyUserPreset(id){
  const p=userPresets().find(x=>x.id===id); if(!p)return;
  if(p.model)state.createModel=p.model;
  state.autoModel=p.autoModel===true;
  state.autoRecommendation=null;state.autoRequestSeq++;
  if(p.aspect)state.aspect=p.aspect;
  if(p.createQuality)state.createQuality=p.createQuality;
  if(p.deliveryPreset)state.deliveryPreset=p.deliveryPreset;
  if(p.expert&&p.model){
    if(!state.expertOverrides||typeof state.expertOverrides!=='object')state.expertOverrides={};
    if(Object.keys(p.expert).length)state.expertOverrides[p.model]={...p.expert};else delete state.expertOverrides[p.model];
  }
  if(p.width){$('#createWidth').value=p.width;state.createWidth=+p.width}
  if(p.height){$('#createHeight').value=p.height;state.createHeight=+p.height}
  if(p.width&&p.height)syncAspectFromCurrentSize({persist:false,render:false});
  if(p.promptMode)$('#promptMode').value=p.promptMode;
  if(p.promptStudio){
    state.promptStyle=p.promptStudio.style||'auto';
    state.promptLighting=p.promptStudio.lighting||'auto';
    state.promptCamera=p.promptStudio.camera||'auto';
    state.promptFraming=p.promptStudio.framing||'auto';
    applyPromptStudioControls();
  }
  renderModels();renderAutoModelStatus();renderExpertModelControls();renderAspects();renderDeliveryPresets();renderCreateQuality();updateGenerateHint();schedulePrompt();savePrefs();
  toast('Пресет применён');
}
function saveUserPreset(){
  const input=$('#userPresetName'); const name=(input.value||'').trim();
  if(!name){toast('Введи название пресета',true);input.focus();return}
  const items=userPresets().filter(x=>x.name.toLowerCase()!==name.toLowerCase());
  items.unshift({
    id:'p_'+Date.now(),name,
    model:state.createModel,autoModel:!!state.autoModel,aspect:state.aspect,createQuality:state.createQuality,deliveryPreset:state.deliveryPreset,
    width:+$('#createWidth').value||1024,height:+$('#createHeight').value||1024,expert:currentExpertOverrides(),
    promptMode:$('#promptMode').value,promptStudio:promptStudioState()
  });
  localStorage.setItem(USER_PRESET_KEY,JSON.stringify(items.slice(0,20)));
  input.value='';renderUserPresets();toast('Пресет сохранён');
}
function deleteUserPreset(){
  const id=$('#userPresetSelect').value;if(!id)return;
  const items=userPresets().filter(x=>x.id!==id);
  localStorage.setItem(USER_PRESET_KEY,JSON.stringify(items));
  renderUserPresets();toast('Пресет удалён');
}
function esc(value){
  return String(value??'').replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function favoritePaths(){
  try{return new Set(JSON.parse(localStorage.getItem(FAVORITES_KEY)||'[]').map(x=>String(x).toLowerCase()))}catch{return new Set()}
}
function toggleFavorite(path){
  const key=String(path||'').toLowerCase();if(!key)return;
  const set=favoritePaths();
  if(set.has(key))set.delete(key);else set.add(key);
  localStorage.setItem(FAVORITES_KEY,JSON.stringify([...set]));
  renderLibrary();
}
function promptHistory(){
  try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')}catch{return []}
}
function rememberPrompt(kind,text){
  const clean=(text||'').trim();if(!clean)return;
  const items=promptHistory().filter(x=>!(x.kind===kind&&x.text===clean));
  items.unshift({kind,text:clean,at:Date.now()});
  localStorage.setItem(HISTORY_KEY,JSON.stringify(items.slice(0,40)));
}
function historyTargetInfo(kind){
  if(kind==='edit')return {selector:'#editPrompt',label:'EDIT',schedule:scheduleEditPrompt};
  if(kind==='motion')return {selector:'#motionPrompt',label:'VIDEO',schedule:scheduleMotionPrompt};
  return {selector:'#createPrompt',label:'CREATE',schedule:schedulePrompt};
}
function renderPromptHistory(){
  const all=promptHistory();
  const items=all.filter(x=>x.kind===state.historyTarget);
  const box=$('#historyList');
  if(!items.length){box.innerHTML='<div class="history-empty">Здесь пока нет сохранённых запросов.</div>';return}
  box.innerHTML=items.map((x,i)=>'<div class="history-item"><span class="history-kind">'+esc(historyTargetInfo(x.kind).label)+'</span><span class="history-text" title="'+esc(x.text)+'">'+esc(x.text)+'</span><button data-history-use="'+i+'">Использовать</button></div>').join('');
  $$('[data-history-use]').forEach(b=>b.onclick=()=>{
    const item=items[+b.dataset.historyUse];if(!item)return;
    const info=historyTargetInfo(item.kind);$(info.selector).value=item.text;info.schedule();
    closePromptHistory();
  });
}
function openPromptHistory(kind){
  state.historyTarget=kind;renderPromptHistory();$('#historyModal').classList.remove('hidden');
}
function closePromptHistory(){$('#historyModal').classList.add('hidden')}
function clearPromptHistoryModal(){
  clearPromptHistory();
  renderPromptHistory();
}
function toast(message,bad=false){
  const el=$('#toast'); el.textContent=message; el.classList.toggle('bad',bad);
  el.classList.add('show'); clearTimeout(toast.t);
  toast.t=setTimeout(()=>el.classList.remove('show'),2800);
}
async function api(name,...args){
  try{return await window.pywebview.api[name](...args)}
  catch(e){toast(String(e),true);return {ok:false,message:String(e)}}
}
window.addEventListener('error',e=>{
  if(window.pywebview?.api?.log_frontend_error) window.pywebview.api.log_frontend_error(String(e.message||'Frontend error'),String(e.error?.stack||''));
});
window.addEventListener('unhandledrejection',e=>{
  const reason=e.reason; const msg=reason?.message||String(reason||'Unhandled promise rejection');
  if(window.pywebview?.api?.log_frontend_error) window.pywebview.api.log_frontend_error(msg,String(reason?.stack||''));
});
function switchView(name){
  state.view=name;
  $$('.nav-item[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===name));
  $$('.view').forEach(x=>x.classList.toggle('active',x.id==='view-'+name));
  if(name==='library')loadLibrary();
  if(name==='settings'){runHealthCheck(true);pollModelDownloadState();}
}
function modelById(id){return state.backend?.models?.find(x=>x.id===id)}

const DELIVERY_LONG_EDGE={hd:1280,fhd:1920,qhd:2560,uhd4k:3840};
const DELIVERY_NAMES={native:'Нативный',hd:'HD',fhd:'Full HD',qhd:'2K / QHD',uhd4k:'4K'};
const EXPERT_LABELS={
  steps:'Steps',cfg:'CFG',sampler:'Sampler',scheduler:'Scheduler',clip_skip:'CLIP skip',prediction:'Prediction',
  zsnr:'Zero Terminal SNR',negative:'Negative prompt',lora_strength:'LoRA strength',
  hires_scale:'Hires scale',hires_steps:'Hires steps',hires_denoise:'Hires denoise',
  shift:'Flow shift',beta_alpha:'Beta α',beta_beta:'Beta β'
};
function deliveryTarget(width=+$('#createWidth')?.value||1024,height=+$('#createHeight')?.value||1024,preset=state.deliveryPreset){
  if(!preset||preset==='native'||!DELIVERY_LONG_EDGE[preset])return {width,height,preset:'native',label:'Нативный'};
  const long=DELIVERY_LONG_EDGE[preset];
  let w,h;
  if(width>=height){w=long;h=Math.max(2,Math.round((long*height/width)/2)*2)}
  else{h=long;w=Math.max(2,Math.round((long*width/height)/2)*2)}
  return {width:w,height:h,preset,label:DELIVERY_NAMES[preset]||preset};
}
function renderDeliveryPresets(){
  $$('[data-delivery]').forEach(b=>b.classList.toggle('active',b.dataset.delivery===state.deliveryPreset));
  const baseW=+$('#createWidth')?.value||1024,baseH=+$('#createHeight')?.value||1024;
  const d=deliveryTarget(baseW,baseH);
  const help=$('#deliveryHelp');
  if(help){
    help.textContent=d.preset==='native'
      ?'Нативный AI-рендер '+baseW+'×'+baseH+'. Это рабочее разрешение модели без дополнительного upscale.'
      :'AI рендерит '+baseW+'×'+baseH+' в оптимальном диапазоне, затем NMKD Superscale доводит файл точно до '+d.width+'×'+d.height+' ('+d.label+').';
  }
}
function modelExpertOverrides(modelId=state.createModel){
  if(!state.expertOverrides||typeof state.expertOverrides!=='object')state.expertOverrides={};
  const value=state.expertOverrides[modelId];
  return value&&typeof value==='object'?value:{};
}
function currentExpertOverrides(){return {...modelExpertOverrides(state.createModel)}}
function activeRenderParams(model=modelById(state.createModel),mode=state.createQuality){
  const defaults={...(model?.expert?.defaults||{})};
  if(mode==='max'&&model?.max_quality){
    if(model?.max_steps!==undefined)defaults.steps=model.max_steps;
    if(model?.max_expert&&typeof model.max_expert==='object')Object.assign(defaults,model.max_expert);
  }
  if(mode==='custom')Object.assign(defaults,modelExpertOverrides(model?.id||state.createModel));
  return defaults;
}
function compactRenderParams(values){
  const out=[];
  if(values.steps!==undefined)out.push(values.steps+' steps');
  if(values.cfg!==undefined)out.push('CFG '+values.cfg);
  if(values.sampler)out.push(String(values.sampler).replaceAll('_',' '));
  if(values.scheduler)out.push(String(values.scheduler).replaceAll('_',' '));
  if(values.lora_strength!==undefined)out.push('LoRA '+values.lora_strength);
  if(values.shift!==undefined)out.push('Shift '+values.shift);
  if(values.beta_alpha!==undefined&&values.beta_beta!==undefined)out.push('Beta '+values.beta_alpha+'/'+values.beta_beta);
  return out.join(' · ')||'параметры модели';
}
function setExpertParam(key,value){
  if(!state.expertOverrides||typeof state.expertOverrides!=='object')state.expertOverrides={};
  const current={...modelExpertOverrides(state.createModel)};
  const model=modelById(state.createModel),def=model?.expert?.defaults?.[key];
  const same=(typeof def==='number')?Math.abs(Number(value)-Number(def))<1e-9:String(value)===String(def);
  if(value===''||value===null||value===undefined||same)delete current[key];else current[key]=value;
  if(Object.keys(current).length)state.expertOverrides[state.createModel]=current;else delete state.expertOverrides[state.createModel];
  state.createQuality='custom';
  savePrefs();renderExpertModelControls();renderCreateQuality();updateGenerateHint();
}
function resetExpertModel(){
  if(state.expertOverrides&&state.expertOverrides[state.createModel])delete state.expertOverrides[state.createModel];
  state.createQuality='standard';
  savePrefs();renderExpertModelControls();renderCreateQuality();updateGenerateHint();toast('Параметры модели сброшены к рекомендуемым');
}
function renderExpertModelControls(){
  const model=modelById(state.createModel),root=$('#expertModelControls'),summary=$('#expertModelSummary'),help=$('#expertModelHelp');
  if(!root||!summary||!help)return;
  const info=model?.expert||{},defaults=info.defaults||{},editable=info.editable||[],over=modelExpertOverrides();
  const dirty=Object.keys(over).length;
  summary.textContent=state.createQuality==='custom'?(dirty?'Активно: '+dirty+' изм.':'Вручную · рекомендуемые'):(dirty?'Сохранено вручную: '+dirty:'Рекомендуемые');
  summary.classList.toggle('expert-dirty',state.createQuality==='custom');
  const tech=[
    model?.family?'Семейство: '+model.family:'',
    model?.workflow?'Workflow: '+model.workflow:(model?.profile?'Profile: '+model.profile:''),
    model?.checkpoint?'Checkpoint: '+model.checkpoint:'',
    defaults.prediction?'Prediction: '+defaults.prediction:'',
    defaults.zsnr!==undefined?'ZSNR: '+(defaults.zsnr?'on':'off'):''
  ].filter(Boolean);
  help.textContent=(model?.name||'Модель')+'. '+(tech.join(' · ')||'Параметры генерации доступны ниже.')+
    (state.createQuality==='custom'
      ?' Режим «Вручную» активен: эти значения реально попадут в workflow.'
      :(dirty?' Ручной набор сохранён, но сейчас не активен: выбран готовый пресет.':' Сейчас используются параметры выбранного готового пресета.'))+
    (model?.id==='qwen21_design'?' Текст, который должен быть виден на картинке, пиши в кавычках: "СКИДКА 50%". LocalGen сохранит его на русском и попросит модель не придумывать лишние надписи.':'');
  const field=key=>{
    if(!editable.includes(key))return '';
    const value=(over[key]!==undefined?over[key]:defaults[key]);
    const label=EXPERT_LABELS[key]||key;
    if(key==='sampler'||key==='scheduler'||key==='prediction'){
      const options=(info.options?.[key]||[]).map(x=>'<option value="'+esc(x)+'" '+(String(x)===String(value)?'selected':'')+'>'+esc(x)+'</option>').join('');
      return '<label class="expert-field"><span>'+esc(label)+'</span><select data-expert-param="'+esc(key)+'">'+options+'</select></label>';
    }
    if(key==='zsnr'){
      return '<label class="expert-field expert-toggle"><span>'+esc(label)+'</span><input type="checkbox" data-expert-param="'+esc(key)+'" '+(value?'checked':'')+'></label>';
    }
    if(key==='negative'){
      return '<label class="expert-field wide"><span>'+esc(label)+'</span><textarea data-expert-param="'+esc(key)+'">'+esc(value??'')+'</textarea></label>';
    }
    const range=info.ranges?.[key]||{min:0,max:100,step:1};
    return '<label class="expert-field"><span>'+esc(label)+'</span><div class="expert-number-row">'+
      '<input type="range" min="'+range.min+'" max="'+range.max+'" step="'+range.step+'" value="'+esc(value)+'" data-expert-range="'+esc(key)+'">'+
      '<input type="number" min="'+range.min+'" max="'+range.max+'" step="'+range.step+'" value="'+esc(value)+'" data-expert-param="'+esc(key)+'"></div></label>';
  };
  const active=activeRenderParams(model,state.createQuality);
  const effective={
    model:model?.name||state.createModel,
    family:model?.family||'',
    workflow:model?.workflow||model?.profile||'',
    selected_quality:state.createQuality,
    active_values:active,
    preset_values:{
      optimal:activeRenderParams(model,'standard'),
      maximum:activeRenderParams(model,'max'),
      manual_saved:{...defaults,...over}
    },
    latent_refine:{
      automatic_in_maximum:false,
      active_scale:active.hires_scale??1.0,
      active_steps:active.hires_steps??defaults.hires_steps??null,
      active_denoise:active.hires_denoise??defaults.hires_denoise??null
    },
    native_limit:{
      max_side:+model?.max_native_side||2048,
      max_pixels:+model?.max_native_pixels||2200000
    },
    saved_manual_overrides:over
  };
  root.innerHTML=editable.map(field).join('')+
    (tech.length?'<div class="expert-fixed wide"><strong>Технический профиль</strong><span>'+tech.map(esc).join(' · ')+'</span></div>':'')+
    '<details class="expert-effective wide"><summary>Полная эффективная конфигурация</summary><pre>'+esc(JSON.stringify(effective,null,2))+'</pre></details>';
  $$('[data-expert-param]',root).forEach(el=>{
    const commit=()=>{const key=el.dataset.expertParam;let val=el.type==='checkbox'?el.checked:(el.type==='number'?Number(el.value):el.value);setExpertParam(key,val)};
    el.addEventListener(el.tagName==='TEXTAREA'?'change':'change',commit);
  });
  $$('[data-expert-range]',root).forEach(el=>el.addEventListener('input',()=>{
    const key=el.dataset.expertRange,num=$('[data-expert-param="'+key+'"]',root);if(num)num.value=el.value;
  }));
  $$('[data-expert-range]',root).forEach(el=>el.addEventListener('change',()=>setExpertParam(el.dataset.expertRange,Number(el.value))));
}
const CREATE_REFERENCE_MAX=9;
const CREATE_REFERENCE_ROLES={
  auto:'Авто',identity:'Лицо / персонаж',clothing:'Одежда',object:'Объект / товар',style:'Стиль',composition:'Композиция'
};
function referenceQwenModel(){
  const models=state.backend?.models||[];
  return models.find(m=>m.id==='qwen21_design'&&m.installed)||models.find(m=>m.kind==='create'&&m.installed&&m.workflow==='qwen_t2i')||null;
}
function createReferenceCapable(modelId=state.createModel){
  const model=modelById(modelId);
  return !!(model?.installed&&model.workflow==='qwen_t2i');
}
function createReferencePairs(){
  return state.createReferences.map((path,i)=>({path,role:state.createReferenceRoles[i]||'auto'})).filter(x=>x.path);
}
function renderCreateReferences(){
  const list=$('#createReferenceList'),empty=$('#createReferenceEmpty'),count=$('#createReferenceCount'),status=$('#createReferenceStatus');
  if(!list||!empty||!count||!status)return;
  const pairs=createReferencePairs();
  count.textContent=pairs.length+' / '+CREATE_REFERENCE_MAX;
  empty.classList.toggle('hidden',pairs.length>0);
  list.innerHTML=pairs.map((item,i)=>{
    const options=Object.entries(CREATE_REFERENCE_ROLES).map(([value,label])=>'<option value="'+esc(value)+'" '+(value===item.role?'selected':'')+'>'+esc(label)+'</option>').join('');
    const name=item.path.split(/[\\/]/).pop()||('Референс '+(i+1));
    return '<div class="create-reference-item" data-create-reference="'+i+'">'+
      '<div class="create-reference-preview"><img src="'+esc(localFileUrl(item.path))+'" alt=""><span>REF '+(i+1)+'</span></div>'+
      '<strong title="'+esc(item.path)+'">'+esc(name)+'</strong>'+
      '<select data-create-reference-role="'+i+'">'+options+'</select>'+
      '<button class="ghost" data-remove-create-reference="'+i+'">Удалить</button></div>';
  }).join('');
  $$('[data-create-reference-role]',list).forEach(sel=>sel.onchange=()=>{state.createReferenceRoles[+sel.dataset.createReferenceRole]=sel.value;renderCreateReferences()});
  $$('[data-remove-create-reference]',list).forEach(btn=>btn.onclick=()=>removeCreateReference(+btn.dataset.removeCreateReference));
  $('#clearCreateReferences').disabled=!pairs.length;
  $('#addCreateReferences').disabled=pairs.length>=CREATE_REFERENCE_MAX;
  $('#pasteCreateReference').disabled=pairs.length>=CREATE_REFERENCE_MAX;
  const qwen=referenceQwenModel(),compatible=createReferenceCapable();
  status.classList.remove('warning');
  if(!pairs.length)status.textContent='Без референсов LocalGen использует обычный Create workflow.';
  else if(compatible)status.textContent='Референсы активны · '+(modelById(state.createModel)?.name||'Qwen-Image-2.1')+' использует их как visual guidance.';
  else{
    status.textContent='Текущая модель не умеет этот Reference workflow. Выбери Qwen-Image-2.1 или включи авто-подбор.';
    status.classList.add('warning');
  }
  const switcher=$('#useQwenForReferences');
  switcher.classList.toggle('hidden',!pairs.length||compatible||!qwen);
  const shootout=$('#modelShootoutBtn');
  if(shootout){
    const blocked=pairs.length>0||!!state.structureControl;
    shootout.disabled=blocked;
    shootout.title=pairs.length?'Model Shootout отключён для reference-generation: референсы требуют Qwen-Image-2.1.':(state.structureControl?'Model Shootout отключён при активном контроле структуры.':'');
  }
}
async function selectQwenForReferences(){
  const qwen=referenceQwenModel();
  if(!qwen){toast('Qwen-Image-2.1 сейчас недоступен',true);return}
  state.autoModel=false;state.autoRecommendation=null;state.autoRequestSeq++;state.createModel=qwen.id;
  savePrefs();renderModels();renderAutoModelStatus();renderExpertModelControls();renderCreateQuality();renderCreateReferences();schedulePrompt();updateGenerateHint();
}
function renderAutoModelStatus(){
  const toggle=$('#autoModelToggle'),box=$('#autoModelStatus');
  if(!toggle||!box)return;
  toggle.classList.toggle('active',!!state.autoModel);
  const flag=toggle.querySelector('b');if(flag)flag.textContent=state.autoModel?'Вкл':'Выкл';
  box.classList.remove('warning');
  if(!state.autoModel){
    const m=modelById(state.createModel);
    box.querySelector('strong').textContent='Ручной выбор: '+(m?.name||'модель');
    box.querySelector('span').textContent='Нажми «Авто-подбор модели», чтобы LocalGen снова выбирал профиль по запросу.';
    return;
  }
  if(state.structureControl){
    const rec=state.autoRecommendation,provider=preferredStructureControlModel(),label=structureModeLabel();
    box.querySelector('strong').textContent=rec?.model_name?'Авто: '+rec.model_name:'Структура → '+(provider?.name||'structural backend');
    box.querySelector('span').textContent='Активен режим «'+label+'». Авто использует Z-Image как более быстрый structural backend; Qwen Union можно выбрать вручную для более точного Canny.';
    return;
  }
  if(state.createReferences.length){
    const rec=state.autoRecommendation,qwen=referenceQwenModel();
    box.querySelector('strong').textContent=rec?.model_name?'Авто: '+rec.model_name:'Референсы → '+(qwen?.name||'Qwen-Image-2.1');
    box.querySelector('span').textContent='Прикреплены визуальные референсы, поэтому LocalGen использует Qwen-Image-2.1 reference workflow.';
    return;
  }
  const text=$('#createPrompt')?.value.trim()||'';
  if(!text){
    box.querySelector('strong').textContent='Напиши запрос';
    box.querySelector('span').textContent='LocalGen определит нишу и выберет подходящую установленную модель.';
    return;
  }
  const rec=state.autoRecommendation;
  if(!rec){
    box.querySelector('strong').textContent='Анализ запроса…';
    box.querySelector('span').textContent='Подбираю профиль под задачу.';
    return;
  }
  box.querySelector('strong').textContent='Авто: '+rec.model_name;
  box.querySelector('span').textContent=rec.reason+(rec.warning?' '+rec.warning:'');
  box.classList.toggle('warning',!!rec.warning);
}
async function updateAutoModelRecommendation(){
  renderAutoModelStatus();
  if(!state.autoModel)return null;
  if(state.structureControl){
    const provider=preferredStructureControlModel();
    if(!provider){
      state.autoRecommendation=null;renderAutoModelStatus();renderStructureControl();return null;
    }
    const result={ok:true,model_id:provider.id,model_name:provider.name,reason:'Auto Structure Control использует Z-Image: он быстрее и выше по standalone visual-quality score. Qwen Union доступен вручную для более точного Canny.',confidence:'high',warning:''};
    state.autoRecommendation=result;state.autoRequestSeq++;
    if(state.createModel!==provider.id){
      state.createModel=provider.id;renderModels();renderExpertModelControls();renderCreateQuality();updateGenerateHint();savePrefs();
    }
    renderAutoModelStatus();renderCreateReferences();renderStructureControl();
    return result;
  }
  if(state.createReferences.length){
    const qwen=referenceQwenModel();
    if(!qwen){
      state.autoRecommendation=null;renderAutoModelStatus();renderCreateReferences();return null;
    }
    const result={ok:true,model_id:qwen.id,model_name:qwen.name,reason:'Визуальные референсы требуют Qwen-Image-2.1 reference workflow.',confidence:'high',warning:''};
    state.autoRecommendation=result;state.autoRequestSeq++;
    if(state.createModel!==qwen.id){
      state.createModel=qwen.id;renderModels();renderExpertModelControls();renderCreateQuality();updateGenerateHint();savePrefs();
    }
    renderAutoModelStatus();renderCreateReferences();
    return result;
  }
  const text=$('#createPrompt')?.value.trim()||'';
  if(!text){state.autoRecommendation=null;renderAutoModelStatus();return null}
  const style=state.promptStyle||'auto';
  const seq=++state.autoRequestSeq;
  const result=await api('recommend_create_model',text,style);
  if(seq!==state.autoRequestSeq||text!==($('#createPrompt')?.value.trim()||'')||style!==(state.promptStyle||'auto'))return null;
  if(!result.ok){
    state.autoRecommendation=null;
    const box=$('#autoModelStatus');
    if(box){box.classList.add('warning');box.querySelector('strong').textContent='Авто-подбор недоступен';box.querySelector('span').textContent=result.message||'Выбери модель вручную.'}
    return null;
  }
  state.autoRecommendation=result;
  const model=modelById(result.model_id);
  if(model?.installed&&state.createModel!==result.model_id){
    state.createModel=result.model_id;
    renderModels();
    renderExpertModelControls();
    renderCreateQuality();
    updateGenerateHint();
    savePrefs();
  }
  renderAutoModelStatus();
  return result;
}
function renderModelCard(m,selected){
  return '<button class="model-card '+(selected?'selected ':'')+(m.installed?'':'missing')+'" data-model="'+esc(m.id)+'" '+(m.installed?'':'disabled aria-disabled="true"')+' title="'+esc(m.limitations||'')+'">'+
    '<div class="model-top"><strong>'+esc(m.name)+'</strong>'+(m.recommended?'<span class="badge">Рекомендуем</span>':'')+'</div>'+
    (m.best_for?'<div class="model-best">Лучше всего: '+esc(m.best_for)+'</div>':'')+
    '<p>'+esc(m.strengths||'')+'</p>'+
    '<div class="model-meta"><span>'+esc(m.speed||'')+'</span>'+(m.estimate?'<span>'+esc(m.estimate)+'</span>':'')+'<span>Нагрузка: '+esc((m.memory||'').toLowerCase())+'</span>'+(m.installed?'':'<span>Не установлена</span>')+'</div>'+
    (m.limitations?'<div class="model-limit">Важно: '+esc(m.limitations)+'</div>':'')+
    '</button>';
}
const CREATE_CATEGORY_ORDER=['photo','adult_photo','anime','adult_anime','design','universal','character','draft'];
function renderModels(){
  const create=state.backend.models.filter(x=>x.kind==='create');
  const grouped=new Map();
  for(const model of create){
    const key=model.category||'other';
    if(!grouped.has(key))grouped.set(key,[]);
    grouped.get(key).push(model);
  }
  const keys=[...CREATE_CATEGORY_ORDER.filter(x=>grouped.has(x)),...([...grouped.keys()].filter(x=>!CREATE_CATEGORY_ORDER.includes(x)))];
  $('#createModels').innerHTML=keys.map(key=>{
    const items=grouped.get(key)||[];
    const label=items[0]?.category_label||'Другие модели';
    return '<section class="model-category"><div class="model-category-title">'+esc(label)+'</div><div class="model-grid">'+items.map(m=>renderModelCard(m,m.id===state.createModel)).join('')+'</div></section>';
  }).join('');
  $('#createModels').onclick=e=>{
    const card=e.target.closest('[data-model]'); if(!card||card.disabled)return;
    state.autoModel=false;state.autoRecommendation=null;state.autoRequestSeq++;state.createModel=card.dataset.model;savePrefs();renderModels();renderAutoModelStatus();renderExpertModelControls();renderCreateQuality();renderCreateReferences();renderStructureControl();schedulePrompt();updateGenerateHint();
  };
  syncCreateSizeLimits();
  renderResolutionPlanner();
  updateCreateCharacterUI();
  const animate=state.backend.models.filter(x=>x.kind==='animate');
  $('#animateModels').innerHTML=animate.map(m=>renderModelCard(m,m.id===state.animateModel)).join('');
  $('#animateModels').onclick=e=>{
    const card=e.target.closest('[data-model]'); if(!card)return;
    state.animateModel=card.dataset.model; savePrefs(); renderModels(); renderAnimateControls({modelChanged:true}); scheduleMotionPrompt();
  };
}
function syncAspectFromCurrentSize({persist=true,render=true}={}){
  const w=Math.max(0,+$('#createWidth')?.value||0),h=Math.max(0,+$('#createHeight')?.value||0);
  if(!w||!h||!state.backend?.aspect_presets)return;
  state.createWidth=w;state.createHeight=h;
  const match=Object.entries(state.backend.aspect_presets).find(([,p])=>+p.width===w&&+p.height===h);
  state.aspect=match?match[0]:'custom';
  if(persist)savePrefs();
  if(render)renderAspects();
}
function restoreCreateSize(){
  const presets=state.backend?.aspect_presets||{};
  const preset=presets[state.aspect]||presets.square;
  let w=+state.createWidth||0,h=+state.createHeight||0;
  if(!w||!h){
    w=+preset?.width||1024;h=+preset?.height||1024;
  }
  $('#createWidth').value=w;$('#createHeight').value=h;
  state.createWidth=w;state.createHeight=h;
  const exact=Object.entries(presets).find(([,p])=>+p.width===w&&+p.height===h);
  if(exact)state.aspect=exact[0];
  else if(state.aspect!=='custom'&&preset&&(+preset.width!==w||+preset.height!==h))state.aspect='custom';
}
function currentCreateSize(){
  const width=+$('#createWidth').value||1024,height=+$('#createHeight').value||1024;
  const match=Object.entries(state.backend?.aspect_presets||{}).find(([,p])=>+p.width===width&&+p.height===height);
  return {width,height,aspect:match?match[0]:'custom'};
}
function modelNativeLimits(model=modelById(state.createModel)){
  return {
    side:+model?.max_native_side||2048,
    pixels:+model?.max_native_pixels||2200000
  };
}
function modelSupportsNativeSize(width,height,model=modelById(state.createModel)){
  const lim=modelNativeLimits(model);
  return width>=256&&height>=256&&width<=lim.side&&height<=lim.side&&width*height<=lim.pixels&&width%8===0&&height%8===0;
}
function syncCreateSizeLimits(){
  const lim=modelNativeLimits();
  for(const id of ['createWidth','createHeight']){
    const input=$('#'+id);if(input)input.max=String(lim.side);
  }
  const help=$('#createNativeLimitHelp');
  if(help)help.textContent='Нативный лимит текущей модели: до '+lim.side+' px по стороне · '+(lim.pixels/1000000).toFixed(1)+' Мп.';
}
function currentResolutionPlan(model=modelById(state.createModel)){
  const meta=model?.resolution_planner;
  const buckets=Array.isArray(meta?.buckets)?meta.buckets:[];
  const size=currentCreateSize();
  if(!buckets.length||!size.width||!size.height)return null;
  const ratio=size.width/size.height;
  const distance=b=>Math.abs((+b.width/+b.height)-ratio)/Math.max(ratio,1e-9);
  const recommended=[...buckets].sort((a,b)=>distance(a)-distance(b)||((+b.width*+b.height)-(+a.width*+a.height)))[0];
  const refs=Array.isArray(meta.native_reference_buckets)?meta.native_reference_buckets:[];
  const reference=refs.length?[...refs].sort((a,b)=>distance(a)-distance(b)||((+b.width*+b.height)-(+a.width*+a.height)))[0]:null;
  return {
    model,meta,size,recommended,reference,
    changed:+recommended.width!==size.width||+recommended.height!==size.height,
    aspectError:distance(recommended)
  };
}
function renderResolutionPlanner(){
  const box=$('#resolutionPlanner');if(!box)return;
  const plan=currentResolutionPlan();
  if(!plan){box.classList.add('hidden');return}
  box.classList.remove('hidden');
  const {model,meta,size,recommended,reference,changed}=plan;
  const confidenceLabels={high:'проверено',medium:'средняя уверенность',research:'требует A/B'};
  const confidence=confidenceLabels[meta.confidence]||meta.confidence||'исследование';
  $('#resolutionPlannerTitle').textContent=changed
    ?(model?.name||'Модель')+': '+recommended.width+'×'+recommended.height
    :'Текущий размер совпадает с рекомендацией';
  let text=changed
    ?'Сейчас '+size.width+'×'+size.height+'. Для рабочего рендера на RTX 3070 8 ГБ рекомендуется '+recommended.width+'×'+recommended.height+'. Размер не меняется автоматически.'
    :'Текущий рабочий размер '+size.width+'×'+size.height+' входит в рекомендованный профиль этой модели.';
  if(meta.evidence)text+=' Основа: '+meta.evidence+'.';
  $('#resolutionPlannerText').textContent=text;
  const tags=[
    '<span class="confidence-'+esc(meta.confidence||'research')+'">'+esc(confidence)+'</span>',
    '<span>'+esc(meta.label||meta.profile_id||'профиль модели')+'</span>',
    '<span>выбрано '+size.width+'×'+size.height+'</span>',
    '<span>рекомендация '+recommended.width+'×'+recommended.height+'</span>'
  ];
  if(reference)tags.push('<span title="Архитектурный/native ориентир модели">native-ориентир '+reference.width+'×'+reference.height+'</span>');
  tags.push('<span>ручной Full HD не заблокирован</span>');
  $('#resolutionPlannerMeta').innerHTML=tags.join('');
  const apply=$('#applyResolutionPlan');
  apply.disabled=!changed;
  apply.textContent=changed?'Применить '+recommended.width+'×'+recommended.height:'Уже применено';
  apply.onclick=()=>{
    if(!changed)return;
    $('#createWidth').value=recommended.width;$('#createHeight').value=recommended.height;
    state.createWidth=+recommended.width;state.createHeight=+recommended.height;
    syncAspectFromCurrentSize({persist:true,render:false});
    renderAspects();renderDeliveryPresets();updateGenerateHint();
    toast('Рабочее разрешение: '+recommended.width+'×'+recommended.height+'. Финальный размер выбирается отдельно.');
  };
}
function renderAspects(){
  const shapes={square:[38,38],portrait:[32,43],portrait_hq:[29,44],social:[32,40],landscape:[45,34],wide:[48,27],fhd_native:[48,27],story:[27,48]};
  const presetCards=Object.entries(state.backend.aspect_presets).map(([id,p])=>{
    const sh=shapes[id]||[38,38],supported=modelSupportsNativeSize(+p.width,+p.height);
    const note=id==='fhd_native'&&!supported?' · текущая модель требует upscale':'';
    return '<button class="aspect-card '+(id===state.aspect?'selected':'')+(supported?'':' unsupported')+'" data-aspect="'+id+'" '+(supported?'':'disabled')+' title="'+(supported?'Нативный рендер':'Нативный размер выше безопасного лимита выбранной модели')+'">'+
      '<div class="aspect-shape" style="width:'+sh[0]+'px;height:'+sh[1]+'px"></div>'+
      '<strong>'+p.name+'</strong><small>'+p.ratio+' · '+p.width+'×'+p.height+note+'</small></button>';
  }).join('');
  const custom=state.aspect==='custom'?'<button class="aspect-card selected custom-aspect" disabled><div class="aspect-shape" style="width:43px;height:31px"></div><strong>Свои</strong><small>'+esc($('#createWidth').value)+'×'+esc($('#createHeight').value)+'</small></button>':'';
  $('#aspectGrid').innerHTML=presetCards+custom;
  $('#aspectGrid').onclick=e=>{
    const card=e.target.closest('[data-aspect]'); if(!card)return;
    state.aspect=card.dataset.aspect; const p=state.backend.aspect_presets[state.aspect];
    $('#createWidth').value=p.width; $('#createHeight').value=p.height;state.createWidth=+p.width;state.createHeight=+p.height;
    savePrefs(); renderAspects(); renderDeliveryPresets(); updateGenerateHint();
  };
  renderResolutionPlanner();
}
function updateCreateCharacterUI(){
  const active=state.createModel==='qwen21_character';
  const card=$('#createCharacterCard');
  if(card)card.classList.toggle('hidden',!active);
  const item=characterById(state.createCharacter);
  if($('#createCharacterHelp')){
    $('#createCharacterHelp').textContent=item
      ?'Используется профиль «'+item.name+'». Identity сохраняется по эталону; сильная смена ракурса или стилизация всё ещё может немного изменить лицо.'
      :'Сначала сохрани удачный портрет кнопкой «Сохранить персонажа», затем выбери его здесь.';
  }
}
function renderCreateQuality(){
  const model=modelById(state.createModel);
  if(!['standard','max','custom'].includes(state.createQuality))state.createQuality='standard';
  $$('[data-create-quality]').forEach(b=>b.classList.toggle('active',b.dataset.createQuality===state.createQuality));
  const standard=activeRenderParams(model,'standard');
  const maximum=activeRenderParams(model,'max');
  const manual=activeRenderParams(model,'custom');
  const standardLabel=$('#standardQualityLabel'),maxLabel=$('#maxQualityLabel'),customLabel=$('#customQualityLabel');
  if(standardLabel)standardLabel.textContent=compactRenderParams(standard);
  if(maxLabel)maxLabel.textContent=compactRenderParams(maximum);
  if(customLabel)customLabel.textContent=Object.keys(modelExpertOverrides()).length?compactRenderParams(manual):'сейчас как Оптимально · измени параметры ниже';
  const panel=$('#expertModelPanel');
  if(panel&&state.createQuality==='custom')panel.open=true;
  const help=$('#createQualityHelp');
  if(!help)return;
  if(state.createQuality==='max'){
    help.textContent=(model?.max_quality_note||'Максимальный режим использует финальные настройки выбранной модели.')+' Сейчас: '+compactRenderParams(maximum)+'.';
  }else if(state.createQuality==='custom'){
    help.textContent='Ручной режим. В workflow пойдут именно значения ниже: '+compactRenderParams(manual)+'. Их можно сохранить вместе с моделью и форматом в «Мои пресеты».';
  }else{
    help.textContent='Рекомендуемый профиль модели: '+compactRenderParams(standard)+'. Ручные значения, если они сохранены, в этом режиме не применяются.';
  }
}
function updateGenerateHint(){
  const m=modelById(state.createModel);
  const count=Math.max(1,Math.min(4,+($('#createVariants')?.value||state.batchCount||1)));
  const item=characterById(state.createCharacter);
  const charPart=state.createModel==='qwen21_character'?' · '+(item?item.name:'выбери персонажа'):'';
  const qualityPart=state.createQuality==='max'?' · Максимум':(state.createQuality==='custom'?' · Вручную':'');
  const baseW=+$('#createWidth').value||1024,baseH=+$('#createHeight').value||1024;
  const delivery=deliveryTarget(baseW,baseH);
  const deliveryPart=delivery.preset==='native'?'':(' → '+delivery.width+'×'+delivery.height);
  const expertPart=state.createQuality==='custom'&&Object.keys(modelExpertOverrides()).length?' · ручные параметры':'';
  $('#generateHint').textContent=(state.autoModel?'Авто → ':'')+(m?.name||'')+charPart+' · '+baseW+'×'+baseH+deliveryPart+qualityPart+expertPart+(count>1?' · '+count+' варианта':'');
}
function animateControls(){return modelById(state.animateModel)?.video_controls||{}}
function animateExpertOverridesFor(modelId=state.animateModel){
  if(!state.animateExpertOverrides||typeof state.animateExpertOverrides!=='object')state.animateExpertOverrides={};
  const value=state.animateExpertOverrides[modelId];
  return value&&typeof value==='object'?value:{};
}
function nearestWanFrames(seconds,fps,maxFrames=81){
  const raw=Math.max(9,Math.min(maxFrames,Math.round(Math.max(.1,seconds)*Math.max(1,fps))));
  let frames=4*Math.round((raw-1)/4)+1;
  if(frames<9)frames=9;
  if(frames>maxFrames)frames=4*Math.floor((maxFrames-1)/4)+1;
  return frames;
}
function currentAnimateExpert(){
  const controls=animateControls(),defaults=controls.defaults||{},over=animateExpertOverridesFor();
  return {
    steps:over.steps??defaults.steps,
    cfg:over.cfg??defaults.cfg,
    shift:over.shift??defaults.shift,
    sampler:over.sampler??defaults.sampler,
    negative:over.negative??defaults.negative
  };
}
function setAnimateExpert(key,value){
  const controls=animateControls(),defaults=controls.defaults||{},current={...animateExpertOverridesFor()};
  const def=defaults[key];
  const same=typeof def==='number'?Math.abs(Number(value)-Number(def))<1e-9:String(value)===String(def??'');
  if(value===''||value===null||value===undefined||same)delete current[key];else current[key]=value;
  if(Object.keys(current).length)state.animateExpertOverrides[state.animateModel]=current;else delete state.animateExpertOverrides[state.animateModel];
  savePrefs();renderAnimateControls();
}
function resetAnimateExpert(){
  if(state.animateExpertOverrides&&state.animateExpertOverrides[state.animateModel])delete state.animateExpertOverrides[state.animateModel];
  savePrefs();renderAnimateControls();toast('Параметры видео сброшены к рекомендуемым');
}
function animateResolutionValid(width,height){
  const c=animateControls(),maxPixels=+c.max_pixels||460000,rw=c.ranges?.width||{},rh=c.ranges?.height||{};
  return width>=+(rw.min||320)&&width<=+(rw.max||1280)&&height>=+(rh.min||320)&&height<=+(rh.max||1280)&&width%16===0&&height%16===0&&width*height<=maxPixels;
}
function chooseClosestAnimatePreset(width,height){
  const presets=animateControls().resolutions||[];
  if(!presets.length)return null;
  const ratio=width>0&&height>0?width/height:1;
  return [...presets].sort((a,b)=>Math.abs(a.width/a.height-ratio)-Math.abs(b.width/b.height-ratio))[0];
}
function syncAnimateTemporal(){
  const c=animateControls(),fpsRange=c.ranges?.fps||{min:8,max:30};
  state.fps=Math.max(+fpsRange.min||8,Math.min(+fpsRange.max||30,Math.round(+state.fps||16)));
  const maxFrames=+c.max_frames||81,maxSec=maxFrames/state.fps;
  state.animateSeconds=Math.max(9/state.fps,Math.min(maxSec,+state.animateSeconds||2));
  state.frames=nearestWanFrames(state.animateSeconds,state.fps,maxFrames);
  const sec=$('#animateSeconds'),fps=$('#animateFps');
  if(sec){sec.min=(9/state.fps).toFixed(2);sec.max=maxSec.toFixed(2);sec.value=Number(state.animateSeconds.toFixed(2))}
  if(fps){fps.min=String(fpsRange.min||8);fps.max=String(fpsRange.max||30);fps.value=String(state.fps)}
  $$('[data-duration-seconds]').forEach(b=>b.classList.toggle('active',Math.abs(+b.dataset.durationSeconds-state.animateSeconds)<.08));
}
function renderAnimateControls({modelChanged=false}={}){
  const c=animateControls(),defaults=c.defaults||{},ranges=c.ranges||{};
  if(modelChanged){
    if(!animateResolutionValid(+state.animateWidth||0,+state.animateHeight||0)){
      const p=chooseClosestAnimatePreset(+state.animateWidth||0,+state.animateHeight||0);
      state.animateWidth=+p?.width||+defaults.width||640;state.animateHeight=+p?.height||+defaults.height||640;
    }
    if(!state.fps)state.fps=+defaults.fps||16;
  }
  syncAnimateTemporal();
  const presets=c.resolutions||[],root=$('#animateResolutionPresets');
  if(root){
    root.innerHTML=presets.map(p=>'<button data-animate-resolution="'+esc(p.id||'')+'" class="'+(+p.width===+state.animateWidth&&+p.height===+state.animateHeight?'active':'')+'">'+esc(p.label||p.id||'')+' · '+p.width+'×'+p.height+'</button>').join('');
    $$('[data-animate-resolution]',root).forEach(btn=>btn.onclick=()=>{
      const p=presets.find(x=>String(x.id)===btn.dataset.animateResolution);if(!p)return;
      state.animateWidth=+p.width;state.animateHeight=+p.height;savePrefs();renderAnimateControls();updateAnimateHint();
    });
  }
  const w=$('#animateWidth'),h=$('#animateHeight');
  if(w){const r=ranges.width||{};w.min=r.min||320;w.max=r.max||1280;w.step=r.step||16;w.value=state.animateWidth||defaults.width||640}
  if(h){const r=ranges.height||{};h.min=r.min||320;h.max=r.max||1280;h.step=r.step||16;h.value=state.animateHeight||defaults.height||640}
  const actual=state.frames/state.fps;
  $('#animateDurationInfo').textContent='≈ '+actual.toFixed(2)+' сек · '+state.frames+' кадр.'+(state.frames===+c.max_frames?' · максимум модели':'');
  $('#animateResolutionInfo').textContent=(state.animateWidth||defaults.width||640)+'×'+(state.animateHeight||defaults.height||640)+' · '+(((state.animateWidth||640)*(state.animateHeight||640))/1e6).toFixed(2)+' Мп';
  const over=animateExpertOverridesFor(),dirty=Object.keys(over).length,expert=currentAnimateExpert();
  $('#animateExpertSummary').textContent=dirty?'Изменено: '+dirty:'Рекомендуемые';
  $('#animateExpertSummary').classList.toggle('expert-dirty',dirty>0);
  const bindNum=(id,key)=>{
    const el=$(id),r=ranges[key]||{};if(!el)return;
    el.min=r.min??'';el.max=r.max??'';el.step=r.step??1;el.value=expert[key]??'';
  };
  bindNum('#animateSteps','steps');bindNum('#animateCfg','cfg');bindNum('#animateShift','shift');
  $('#animateSeed').value=state.animateSeed??'';
  const sampler=$('#animateSampler');
  sampler.innerHTML=(c.samplers||[]).map(x=>'<option value="'+esc(x)+'" '+(String(x)===String(expert.sampler)?'selected':'')+'>'+esc(x)+'</option>').join('');
  $('#animateNegative').value=expert.negative??'';
  updateAnimateHint();
}
function updateAnimateHint(){
  const m=modelById(state.animateModel),actual=Math.max(.1,state.frames/state.fps);
  const estimate=m?.estimate?' · '+m.estimate:'';
  const dirty=Object.keys(animateExpertOverridesFor()).length?' · ручные параметры':'';
  $('#animateHint').textContent=(m?.name||'')+' · '+(state.animateWidth||640)+'×'+(state.animateHeight||640)+' · '+actual.toFixed(2)+' сек · '+state.fps+' FPS'+dirty+estimate;
}
function promptStudioState(){
  return {style:state.promptStyle,lighting:state.promptLighting,camera:state.promptCamera,framing:state.promptFraming};
}
const PROMPT_STUDIO_MAP={
  style:{
    photo:'фотореалистичная фотография',
    cinematic:'кинематографичный кадр',
    illustration:'детализированная цифровая иллюстрация',
    anime:'современная аниме-иллюстрация',
    product:'профессиональная предметная фотография'
  },
  lighting:{
    natural:'естественное мягкое освещение',
    studio:'мягкий студийный свет',
    neon:'неоновое освещение',
    golden:'освещение золотого часа',
    dramatic:'драматический контрастный свет'
  },
  camera:{
    '35':'объектив 35 мм',
    '50':'объектив 50 мм',
    '85':'портретный объектив 85 мм',
    macro:'макрообъектив',
    wide:'широкоугольный объектив'
  },
  framing:{
    close:'крупный план',
    half:'поясной портрет',
    full:'персонаж в полный рост',
    wide:'общий план сцены'
  }
};
function promptStudioText(){
  const s=promptStudioState();
  return [
    PROMPT_STUDIO_MAP.style[s.style],
    PROMPT_STUDIO_MAP.lighting[s.lighting],
    PROMPT_STUDIO_MAP.camera[s.camera],
    PROMPT_STUDIO_MAP.framing[s.framing]
  ].filter(Boolean).join(', ');
}
function promptStudioInput(original){
  const extra=promptStudioText();
  return extra?original+', '+extra:original;
}
function updatePromptStudioSummary(){
  const active=[state.promptStyle,state.promptLighting,state.promptCamera,state.promptFraming].filter(x=>x&&x!=='auto').length;
  $('#promptStudioSummary').textContent=active?active+' параметр'+(active===1?'':active<5?'а':'ов'):'Авто';
}
function applyPromptStudioControls(){
  $('#promptStyle').value=state.promptStyle||'auto';
  $('#promptLighting').value=state.promptLighting||'auto';
  $('#promptCamera').value=state.promptCamera||'auto';
  $('#promptFraming').value=state.promptFraming||'auto';
  updatePromptStudioSummary();
}
async function cleanStartCreateContext(){
  const originalModelId=state.createModel;
  const originalModel=modelById(originalModelId);
  state.createReferences=[];
  state.createReferenceRoles=[];
  state.structureControl='';
  state.structureMode='canny';
  state.structureStrength=0.85;
  state.createCharacter='';
  const seed=$('#createSeed');if(seed)seed.value='';
  state.promptStyle='auto';
  state.promptLighting='auto';
  state.promptCamera='auto';
  state.promptFraming='auto';
  if(state.expertOverrides&&state.expertOverrides[originalModelId])delete state.expertOverrides[originalModelId];
  state.createQuality='standard';
  state.autoRecommendation=null;
  state.autoRequestSeq++;
  if(originalModel?.workflow==='character_scene'){
    const normal=(state.backend?.models||[]).find(x=>x.id==='qwen21_design'&&x.installed)
      ||(state.backend?.models||[]).find(x=>x.kind==='create'&&x.installed&&x.workflow==='qwen_t2i');
    if(normal)state.createModel=normal.id;
  }
  applyPromptStudioControls();
  renderCharacters();
  renderModels();
  renderAutoModelStatus();
  renderCreateReferences();
  renderStructureControl();
  renderExpertModelControls();
  renderCreateQuality();
  updateGenerateHint();
  $('#processedPrompt').value='';
  $('#translatorBadge').textContent='';
  savePrefs();
  schedulePrompt();
  toast('С нуля: референсы, персонаж, seed и ручной контекст сброшены');
}
function translatorLabel(result){
  if(result.detected_language==='en')return 'EN';
  if(result.translator==='argos')return 'RU → EN локально';
  if(result.translator==='unavailable')return 'Переводчик не установлен';
  return '';
}
async function preparePromptNow(){
  const text=$('#createPrompt').value.trim();
  if(!text){$('#processedPrompt').value='';$('#translatorBadge').textContent='';return}
  const preparedInput=promptStudioInput(text);
  const result=await api('prepare_prompt',preparedInput,$('#promptMode').value,state.createModel);
  if(!result.ok)return;
  $('#processedPrompt').value=result.final||text;
  $('#translatorBadge').textContent=translatorLabel(result);
}
function schedulePrompt(){clearTimeout(state.promptTimer);state.promptTimer=setTimeout(async()=>{if(state.autoModel)await updateAutoModelRecommendation();await preparePromptNow()},320)}
async function prepareTaskPrompt(text,mode,modelId,outputSelector,badgeSelector){
  const clean=(text||'').trim();
  if(!clean){$(outputSelector).value='';$(badgeSelector).textContent='';return ''}
  const result=await api('prepare_prompt',clean,mode,modelId);
  if(!result.ok)return clean;
  $(outputSelector).value=result.final||clean;
  $(badgeSelector).textContent=translatorLabel(result);
  return result.final||clean;
}
function editGuidance(){
  const items=[];
  if(state.preserveFace)items.push('preserve the exact same face and subject identity');
  if(state.preserveBackground)items.push('keep the background unchanged unless the instruction explicitly asks to change it');
  return items;
}
function motionGuidance(){
  const strength={
    minimal:'minimal subtle motion, small natural movements only',
    natural:'natural moderate motion',
    active:'clear deliberate body motion while keeping anatomy coherent'
  }[state.motionStrength]||'natural moderate motion';
  const camera={
    static:'static camera, locked framing',
    push:'slow cinematic camera push-in',
    pan:'gentle cinematic camera pan'
  }[state.cameraMotion]||'static camera, locked framing';
  const items=[strength,camera];
  if(state.preserveIdentity)items.push('preserve the exact same face, clothing and subject identity');
  return items;
}
async function prepareEditPromptNow(){
  let prompt=await prepareTaskPrompt(
    $('#editPrompt').value,$('#editPromptMode').value,
    state.editMode==='exact'?'flux2_exact':state.editMode==='adult'?'qwen21_adult_edit':'qwen21_edit',
    '#editProcessedPrompt','#editTranslatorBadge');
  if(!prompt)return '';
  const extras=editGuidance().filter(x=>!prompt.toLowerCase().includes(x.toLowerCase()));
  if(extras.length)prompt+=', '+extras.join(', ');
  $('#editProcessedPrompt').value=prompt;
  return prompt;
}
async function prepareMotionPromptNow(){
  let prompt=await prepareTaskPrompt(
    $('#motionPrompt').value,$('#motionPromptMode').value,state.animateModel,
    '#motionProcessedPrompt','#motionTranslatorBadge');
  if(!prompt)return '';
  const extras=motionGuidance().filter(x=>!prompt.toLowerCase().includes(x.toLowerCase()));
  if(extras.length)prompt+=', '+extras.join(', ');
  $('#motionProcessedPrompt').value=prompt;
  return prompt;
}
const taskPromptTimers={edit:null,motion:null};
function scheduleEditPrompt(){
  clearTimeout(taskPromptTimers.edit);
  taskPromptTimers.edit=setTimeout(prepareEditPromptNow,320);
}
function scheduleMotionPrompt(){
  clearTimeout(taskPromptTimers.motion);
  taskPromptTimers.motion=setTimeout(prepareMotionPromptNow,320);
}
function queueHasJobs(){return (state.queueSnapshot?.active_count||0)>0}
function queueKindLabel(kind){
  return ({create:'Генерация',edit_smart:'Умное редактирование',edit_exact:'Локальный ремонт',animate:'Видео',upscale_image:'Улучшение изображения',upscale_video:'Увеличение видео',restore_video_seedvr2:'AI-восстановление видео'})[kind]||kind||'Задача';
}
function queueJobTitle(job){
  const meta=job?.metadata||{},model=meta.model?modelById(meta.model):null;
  const prompt=String(meta.source_prompt||meta.prompt||'').trim();
  return {title:model?.name?queueKindLabel(job.kind)+' · '+model.name:queueKindLabel(job.kind),detail:prompt||((meta.width&&meta.height)?meta.width+'×'+meta.height:'')};
}
function renderQueueState(){
  const snap=state.queueSnapshot||{running:[],pending:[],active_count:0,max_pending:20};
  const pill=$('#queuePill'),count=$('#queueCount');
  if(pill){pill.classList.toggle('active',snap.active_count>0);pill.title=snap.active_count?('Активных задач: '+snap.active_count):'Очередь пуста'}
  if(count)count.textContent=String(snap.active_count||0);
  const running=$('#queueRunning'),pending=$('#queuePending'),empty=$('#queueEmpty');
  if(!running||!pending||!empty)return;
  const card=(job,runningNow)=>{
    const info=queueJobTitle(job);
    const elapsed=job.started_at?Math.max(0,Math.round(Date.now()/1000-job.started_at)):0;
    const status=runningNow?(job.state==='starting_backend'?'Запуск AI':'Выполняется'+(elapsed?' · '+elapsed+' с':'')):('Ожидает · №'+(job.queue_position||'?'));
    return '<div class="queue-item '+(runningNow?'running':'')+'"><div class="queue-item-main"><strong>'+esc(info.title)+'</strong><span>'+esc(status)+'</span>'+(info.detail?'<p>'+esc(info.detail)+'</p>':'')+'</div><button class="ghost" data-queue-cancel="'+esc(job.id)+'">'+(runningNow?'Остановить':'Убрать')+'</button></div>';
  };
  running.innerHTML=(snap.running||[]).map(x=>card(x,true)).join('');
  pending.innerHTML=(snap.pending||[]).map(x=>card(x,false)).join('');
  empty.classList.toggle('hidden',!!snap.active_count);
  $('#queueClearPending').disabled=!(snap.pending||[]).length;
  $$('[data-queue-cancel]',$('#queueModal')).forEach(btn=>btn.onclick=()=>cancelQueueJob(btn.dataset.queueCancel));
}
async function refreshQueueState(){
  if(state.queuePollBusy)return state.queueSnapshot;
  state.queuePollBusy=true;
  try{
    const r=await api('queue_state');
    if(r?.ok){
      state.queueSnapshot={running:r.running||[],pending:r.pending||[],active_count:+r.active_count||0,max_pending:+r.max_pending||20};
      renderQueueState();renderRuntimeSettings();
      const shootout=$('#modelShootoutBtn');if(shootout)shootout.disabled=!!state.batchActive||!!state.jobId||state.createReferences.length>0||queueHasJobs();
      if(!state.jobId&&!state.batchActive){
        const js=$('#jobState');if(js)js.textContent=state.queueSnapshot.active_count?('В очереди · '+state.queueSnapshot.active_count):'Готов к работе';
      }
    }
  }finally{state.queuePollBusy=false}
  return state.queueSnapshot;
}
function openQueueModal(){refreshQueueState();$('#queueModal').classList.remove('hidden')}
function closeQueueModal(){$('#queueModal').classList.add('hidden')}
async function cancelQueueJob(id){
  if(!id)return;
  if(state.batchActive&&state.jobId===id)state.batchCancelled=true;
  const wasForeground=state.jobId===id;
  if(wasForeground)state.jobId='';
  const r=await api('cancel_job',id);
  if(!r.ok){toast('Не удалось отменить задачу',true);return}
  delete state.jobCompareSources[id];
  await refreshQueueState();
  if(wasForeground){setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Остановлено')}
  toast('Задача отменена');
}
async function clearPendingQueue(){
  const ids=(state.queueSnapshot?.pending||[]).map(x=>x.id).filter(Boolean);
  for(const id of ids)await api('cancel_job',id);
  await refreshQueueState();
  if(ids.length)toast('Ожидающие задачи удалены: '+ids.length);
}
function setBusy(busy,label=''){
  const blockSubmit=!!state.batchActive;
  $('#generateBtn').disabled=blockSubmit;$('#editBtn').disabled=blockSubmit;$('#animateBtn').disabled=blockSubmit;$('#enhanceBtn').disabled=blockSubmit;
  $('#modelShootoutBtn').disabled=busy||blockSubmit||state.createReferences.length>0||queueHasJobs();
  $('#finalizeResult').disabled=busy;$('#repeatResult').disabled=busy;$('#variantsResult').disabled=busy;
  $('#jobState').textContent=busy?(label||'Выполняется…'):(queueHasJobs()?('Очередь · '+state.queueSnapshot.active_count):'Готов к работе');
  $$('[data-stop-job]').forEach(x=>x.classList.toggle('hidden',!busy));
}
function updateDiagnostics(job){
  if(!job)return;
  state.lastJob=job;
  const el=$('#diagnosticLog'); if(!el)return;
  const elapsed=job.started_at?Math.max(0,Math.round((job.ended_at||Date.now()/1000)-job.started_at)):0;
  const lines=[
    'Операция: '+(job.kind||'—'),
    'Состояние: '+(job.state||'—'),
    elapsed?'Время: '+elapsed+' с':'',
    job.error?'Ошибка: '+job.error:'',
    '',
    ...((job.log||[]).slice(-30))
  ].filter((x,i)=>x!==''||i===4);
  el.textContent=lines.join('\n').trim()||'Диагностика пока пуста.';
}
async function cancelCurrent(){
  state.batchCancelled=true;
  if(!state.jobId){
    state.batchActive=false;
    setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Остановлено');
    return;
  }
  const id=state.jobId;state.jobId='';
  delete state.jobCompareSources[id];
  await api('cancel_job',id);
  state.batchActive=false;
  await refreshQueueState();
  setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Остановлено');
  toast('Операция остановлена');
}
function mirrorMarkup(){
  return '<div class="preview-head"><strong>Результат</strong><div class="job-controls"><span class="muted mirror-state">Готов к работе</span><button class="stop-job hidden" data-stop-job>Остановить</button></div></div>'+
    '<div class="result-stage empty mirror-stage"><div class="empty-state"><div class="empty-icon">✦</div><strong>Здесь появится результат</strong>'+
    '<span>После выполнения его можно скопировать, сохранить или отправить дальше.</span></div><img alt=""><video controls></video></div>'+
    '<div class="result-actions"><button data-mirror-action="copy">Копировать</button><button data-mirror-action="compare" class="compare-result hidden">До / После</button><button data-mirror-action="save">Сохранить как…</button><button data-mirror-action="reveal">В папке</button></div>';
}
function initMirrors(){
  $$('[data-mirror-preview]').forEach(x=>x.innerHTML=mirrorMarkup());
  $$('[data-mirror-action]').forEach(btn=>btn.onclick=()=>resultAction(btn.dataset.mirrorAction));
}
function localFileUrl(path){return 'file:///'+String(path||'').replace(/\\/g,'/').replace(/ /g,'%20')}
function canReplayJob(job){
  const meta=job?.metadata||{};
  return !!job&&job.kind==='create'&&!!meta.model&&!!meta.prompt&&Number.isFinite(+meta.seed)&&+meta.seed>0;
}
function canFinalizeJob(job){
  const meta=job?.metadata||{};
  return canReplayJob(job)&&meta.create_quality!=='max';
}
function cleanCreateRecipe(job){
  if(!canReplayJob(job))return null;
  const meta={...(job.metadata||{})};
  for(const key of [
    'batch_group','batch_index','batch_total','shootout_group','shootout_index','shootout_total',
    'variant_group','variant_index','variant_total','variant_parent_output','variant_parent_seed',
    'finalized_from_output','finalized_from_job','finalized_from_quality','finalized_at',
    'replay_of_output','replay_of_job','replay_at'
  ])delete meta[key];
  meta.auto_model=false;
  return meta;
}
function syncRecipeActions(){
  const repeat=$('#repeatResult'),variants=$('#variantsResult');
  if(!repeat||!variants)return;
  const can=canReplayJob(state.currentResultJob)&&!!state.lastOutput&&!/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput);
  repeat.classList.toggle('hidden',!can);
  variants.classList.toggle('hidden',!can);
  if(can){
    const meta=state.currentResultJob.metadata||{};
    const quality=meta.create_quality==='max'?'Максимум':'Оптимально';
    repeat.title='Тот же model/prompt/seed/размер · '+quality;
    variants.title='Создать ещё 2 результата с той же моделью, prompt, размером и качеством, но другими seed';
  }else{
    repeat.removeAttribute('title');variants.removeAttribute('title');
  }
}
async function repeatCreateJob(job,sourcePath=''){
  if(queueHasJobs()||state.jobId){toast('Для точного повтора сначала дождись текущей очереди',true);return}
  const meta=cleanCreateRecipe(job);
  if(!meta){toast('Для этого результата точный повтор недоступен');return}
  meta.replay_of_output=sourcePath||state.lastOutput||'';
  meta.replay_of_job=job.id||'';
  meta.replay_at=Math.floor(Date.now()/1000);
  toast('Повторяю точно: та же модель, prompt, seed, размер и качество');
  await start('create',meta);
}
function syncFinalizeAction(){
  const btn=$('#finalizeResult');
  if(!btn)return;
  const can=canFinalizeJob(state.currentResultJob)&&!!state.lastOutput&&!/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput);
  btn.classList.toggle('hidden',!can);
  if(can){
    const model=modelById(state.currentResultJob.metadata?.model);
    btn.title='Перегенерировать этот seed в режиме «Максимум»'+(model?.max_quality_note?' · '+model.max_quality_note:'');
  }else btn.removeAttribute('title');
}
async function finalizeCreateJob(job,sourcePath=''){
  if(queueHasJobs()||state.jobId){toast('Для финализации сначала дождись текущей очереди',true);return}
  if(!canFinalizeJob(job)){toast('Для этого результата финализация недоступна');return}
  const meta={...(job.metadata||{})};
  const parent=sourcePath||state.lastOutput||'';
  for(const key of ['batch_group','batch_index','batch_total','shootout_group','shootout_index','shootout_total'])delete meta[key];
  meta.create_quality='max';
  meta.auto_model=false;
  meta.finalized_from_output=parent;
  meta.finalized_from_job=job.id||'';
  meta.finalized_from_quality=(job.metadata?.create_quality||'standard');
  meta.finalized_at=Math.floor(Date.now()/1000);
  closeBatchCompare();
  toast('Финализация: тот же seed, модель и промпт · режим «Максимум»');
  await start('create',meta);
}
function showResult(path,url='',source='',job=null){
  state.lastOutput=path||'';state.lastOutputUrl=url||'';
  state.currentResultJob=job||null;
  const deleteBtn=$('#deleteResult');if(deleteBtn)deleteBtn.disabled=!state.lastOutput;
  const isVideo=/\.(mp4|mkv|webm|mov)$/i.test(path||'');
  state.compareSource=(!isVideo&&source)?source:'';
  const canCompare=!!state.compareSource&&!!state.lastOutput;
  $('#compareResult').classList.toggle('hidden',!canCompare);
  if($('#saveCharacterResult'))$('#saveCharacterResult').classList.toggle('hidden',isVideo);
  if($('#inspectDetailsResult'))$('#inspectDetailsResult').classList.toggle('hidden',isVideo||!path);
  state.qualityRegions=[];state.qualityRegionSelected='';state.qualityInspectSource='';
  syncFinalizeAction();syncRecipeActions();
  $$('.compare-result').forEach(x=>x.classList.toggle('hidden',!canCompare));
  const stages=[$('#resultStage'),...$$('.mirror-stage')];
  stages.forEach(stage=>{
    const img=$('img',stage),vid=$('video',stage);
    stage.classList.remove('empty','has-image','has-video');
    if(isVideo){stage.classList.add('has-video');vid.src=url;img.removeAttribute('src')}
    else{stage.classList.add('has-image');img.src=url;vid.removeAttribute('src')}
  });
}
async function pollJob(jobId,foreground=true){
  let ownsForeground=!!foreground;
  if(ownsForeground){state.jobId=jobId;setBusy(true,'Запуск…')}
  while(true){
    const j=await api('job_state',jobId);
    if(!j||j.state==='missing')return;
    await refreshQueueState();
    if(j.state==='running'||j.state==='queued'||j.state==='starting_backend'){
      if(!ownsForeground&&!state.jobId&&!state.batchActive&&j.state!=='queued'){
        ownsForeground=true;state.jobId=jobId;setBusy(true,'Запуск…');
      }
      if(ownsForeground&&state.jobId===jobId){
        updateDiagnostics(j);
        const elapsed=j.started_at?Math.max(0,Math.round(Date.now()/1000-j.started_at)):0;
        const label=j.state==='queued'
          ?'В очереди · №'+(j.queue_position||'?')
          :j.state==='starting_backend'
            ?'Запускаю AI-движок… '+elapsed+' с'
            :queueKindLabel(j.kind)+'…'+(elapsed?' '+elapsed+' с':'');
        $('#jobState').textContent=label;$$('.mirror-state').forEach(x=>x.textContent=label);
      }
      await new Promise(r=>setTimeout(r,800));continue;
    }
    const compareSource=state.jobCompareSources[jobId]||'';
    delete state.jobCompareSources[jobId];
    const foregroundNow=ownsForeground&&state.jobId===jobId;
    if(j.state==='succeeded'){
      if(j.output_path)showResult(j.output_path,j.output_url,compareSource,j);
      if(foregroundNow){state.jobId='';setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Готово')}
      loadLibrary();toast(foregroundNow?'Готово':'Задача из очереди готова');
      await refreshQueueState();return;
    }
    if(j.state==='cancelled'){
      if(foregroundNow){state.jobId='';setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Остановлено')}
      await refreshQueueState();return;
    }
    if(foregroundNow){state.jobId='';setBusy(false);$$('.mirror-state').forEach(x=>x.textContent='Ошибка')}
    toast(j.error||'Операция завершилась с ошибкой',true);
    await refreshQueueState();return;
  }
}
async function start(kind,payload){
  const compareSource=(kind==='create'&&(payload.finalized_from_output||payload.replay_of_output))
    ?(payload.finalized_from_output||payload.replay_of_output||'')
    :(kind==='edit_smart'||kind==='edit_exact')
      ?(payload.image||'')
      :(kind==='upscale_image'?(payload.path||''):'');
  const hadActive=!!state.jobId||queueHasJobs()||state.batchActive;
  const r=await api('start_job',kind,payload);
  if(!r.ok){toast(r.message||'Не удалось запустить',true);return}
  state.jobCompareSources[r.job_id]=compareSource;
  await refreshQueueState();
  if(hadActive){
    const queued=(state.queueSnapshot.pending||[]).find(x=>x.id===r.job_id);
    toast('Добавлено в очередь'+(queued?.queue_position?' · №'+queued.queue_position:''));
  }
  pollJob(r.job_id,!hadActive);
}
function updateBeforeAfter(value){
  const v=Math.max(0,Math.min(100,+value||0));
  $('#afterImage').style.clipPath='inset(0 '+(100-v)+'% 0 0)';
  $('#beforeAfterDivider').style.left=v+'%';
}
function closeBeforeAfter(){$('#beforeAfterModal').classList.add('hidden')}
function openBeforeAfter(){
  if(!state.compareSource||!state.lastOutput){toast('Для этого результата нет исходника для сравнения',true);return}
  $('#beforeImage').src=localFileUrl(state.compareSource);
  $('#afterImage').src=state.lastOutputUrl||localFileUrl(state.lastOutput);
  $('#beforeAfterSlider').value='50';updateBeforeAfter(50);
  $('#beforeAfterModal').classList.remove('hidden');
}
let resultViewerScale=1,resultViewerX=0,resultViewerY=0,resultViewerDragging=false,resultViewerStartX=0,resultViewerStartY=0;
function applyResultViewerTransform(){
  const img=$('#resultViewerImage');if(!img)return;
  img.style.transform='translate('+resultViewerX+'px,'+resultViewerY+'px) scale('+resultViewerScale+')';
}
function resetResultViewer(){resultViewerScale=1;resultViewerX=0;resultViewerY=0;applyResultViewerTransform()}
function closeResultViewer(){
  const modal=$('#resultViewerModal');if(modal)modal.classList.add('hidden');
  const vid=$('#resultViewerVideo');if(vid){try{vid.pause()}catch{}}
  resultViewerDragging=false;
}
function openResultViewer(){
  if(!state.lastOutput){toast('Сначала создай результат');return}
  const modal=$('#resultViewerModal'),stage=$('.result-viewer-stage',modal),img=$('#resultViewerImage'),vid=$('#resultViewerVideo');
  const isVideo=/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput);
  stage.classList.toggle('image',!isVideo);stage.classList.toggle('video',isVideo);
  $('#resultViewerName').textContent=state.lastOutput.split(/[\\/]/).pop()||'Результат';
  if(isVideo){vid.src=state.lastOutputUrl||localFileUrl(state.lastOutput);img.removeAttribute('src')}
  else{img.src=state.lastOutputUrl||localFileUrl(state.lastOutput);vid.removeAttribute('src')}
  resetResultViewer();modal.classList.remove('hidden');
}
async function deleteCurrentResult(){
  const path=state.lastOutput;if(!path){toast('Сначала создай результат');return}
  const name=path.split(/[\\/]/).pop()||'файл';
  if(!window.confirm('Удалить «'+name+'» из результатов LocalGen?\n\nФайл будет удалён без перемещения в корзину.'))return;
  const r=await api('delete_output',path);
  if(!r.ok){toast(r.message||'Не удалось удалить результат',true);return}
  closeResultViewer();
  state.lastOutput='';state.lastOutputUrl='';state.compareSource='';state.currentResultJob=null;
  state.qualityRegions=[];state.qualityRegionSelected='';state.qualityInspectSource='';
  $('#compareResult').classList.add('hidden');$('#inspectDetailsResult').classList.add('hidden');$('#deleteResult').disabled=true;
  syncFinalizeAction();syncRecipeActions();
  for(const stage of [$('#resultStage'),...$$('.mirror-stage')]){
    stage.classList.remove('has-image','has-video');stage.classList.add('empty');
    const img=$('img',stage),vid=$('video',stage);if(img)img.removeAttribute('src');if(vid){vid.removeAttribute('src');try{vid.load()}catch{}}
  }
  await loadLibrary();toast('Результат удалён');
}
async function resultAction(action){
  if(!state.lastOutput){toast('Сначала создай результат');return}
  if(action==='compare'){openBeforeAfter();return}
  if(action==='copy'){
    if(/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput)){await api('copy_text',state.lastOutput);toast('Путь к видео скопирован')}
    else{const r=await api('copy_image',state.lastOutput);toast(r.ok?'Изображение скопировано':'Не удалось скопировать',!r.ok)}
  }
  if(action==='save')await api('save_as',state.lastOutput);
  if(action==='reveal')await api('reveal',state.lastOutput);
}
function qualityRegionById(id){return (state.qualityRegions||[]).find(x=>x.id===id)||null}
function selectQualityRegion(id){
  state.qualityRegionSelected=id||'';
  $$('[data-quality-region]').forEach(x=>x.classList.toggle('active',x.dataset.qualityRegion===state.qualityRegionSelected));
  const region=qualityRegionById(state.qualityRegionSelected);
  const btn=$('#qualityInspectRepair');if(btn)btn.disabled=!region;
  if(region)$('#qualityInspectSummary').textContent=region.label+' · область '+Math.round((region.area_fraction||0)*1000)/10+'% кадра. Выбери «Исправить выбранное» только если здесь действительно есть дефект.';
}
function renderQualityRegions(){
  const overlay=$('#qualityInspectOverlay'),list=$('#qualityInspectRegions');
  if(!overlay||!list)return;
  const regions=state.qualityRegions||[];
  overlay.innerHTML=regions.map(r=>{
    const [x0,y0,x1,y1]=r.bbox||[0,0,0,0];
    const hand=r.kind!=='face'?' hand':'';
    return '<button type="button" class="quality-region-box'+hand+'" data-quality-region="'+esc(r.id)+'" style="left:'+(x0*100)+'%;top:'+(y0*100)+'%;width:'+((x1-x0)*100)+'%;height:'+((y1-y0)*100)+'%"><span>'+esc(r.label)+'</span></button>';
  }).join('');
  list.innerHTML=regions.map(r=>'<button type="button" class="quality-region-item" data-quality-region="'+esc(r.id)+'"><strong>'+esc(r.label)+'</strong><span>'+r.points+' точек · '+(Math.round((r.area_fraction||0)*1000)/10)+'% кадра</span></button>').join('');
  $$('[data-quality-region]').forEach(x=>x.onclick=()=>selectQualityRegion(x.dataset.qualityRegion));
  if(regions.length)selectQualityRegion(regions[0].id);else selectQualityRegion('');
}
function closeQualityInspector(){
  $('#qualityInspectModal')?.classList.add('hidden');
  state.qualityRegionSelected='';
}
async function inspectCurrentResult(){
  const path=state.lastOutput;
  if(!path){toast('Сначала нужен результат',true);return}
  if(/\.(mp4|mkv|webm|mov)$/i.test(path)){toast('Проверка деталей работает с изображениями',true);return}
  if(queueHasJobs()||state.jobId){toast('Дождись завершения текущей GPU-задачи',true);return}
  if(state.qualityInspectBusy)return;
  state.qualityInspectBusy=true;state.qualityInspectSource=path;state.qualityRegions=[];state.qualityRegionSelected='';
  const modal=$('#qualityInspectModal'),btn=$('#inspectDetailsResult');
  modal.classList.remove('hidden');
  $('#qualityInspectImage').src=state.lastOutputUrl||localFileUrl(path);
  $('#qualityInspectSummary').textContent='Ищу лицо и кисти локальным DWPose…';
  $('#qualityInspectRegions').innerHTML='';$('#qualityInspectOverlay').innerHTML='';
  $('#qualityInspectRepair').disabled=true;
  if(btn){btn.disabled=true;btn.textContent='Проверяю…'}
  const r=await api('inspect_quality_regions',path);
  state.qualityInspectBusy=false;
  if(btn){btn.disabled=false;btn.textContent='Проверить детали'}
  if(!r.ok){
    $('#qualityInspectSummary').textContent=r.message||'Не удалось проверить детали';
    toast(r.message||'Не удалось проверить детали',true);return;
  }
  state.qualityRegions=Array.isArray(r.regions)?r.regions:[];
  if(!state.qualityRegions.length){
    $('#qualityInspectSummary').textContent='DWPose не нашёл достаточно уверенных областей лица или кистей. Изображение не изменено.';
    renderQualityRegions();return;
  }
  const faces=state.qualityRegions.filter(x=>x.kind==='face').length;
  const hands=state.qualityRegions.length-faces;
  $('#qualityInspectSummary').textContent='Найдено: '+faces+' лиц · '+hands+' кистей. Это подсказки областей, а не автоматический диагноз дефекта.';
  renderQualityRegions();
}
function qualityRepairPrompt(region){
  if(region?.kind==='face')return 'Исправь лицо, глаза и мелкую анатомию только в выделенной области. Сохрани ту же личность, черты лица, цвет глаз, выражение, кожу, волосы, освещение и стиль. Не меняй ничего вне выделения.';
  return 'Исправь кисть, пальцы и анатомию руки только в выделенной области. Сохрани исходную позу, одежду, кожу, освещение и стиль. Не меняй ничего вне выделения.';
}
async function prepareQualityRegionRepair(){
  const region=qualityRegionById(state.qualityRegionSelected);
  const source=state.qualityInspectSource||state.lastOutput;
  if(!region||!source){toast('Выбери область для ремонта',true);return}
  const btn=$('#qualityInspectRepair');btn.disabled=true;btn.textContent='Готовлю маску…';
  const r=await api('create_quality_region_mask',source,region.bbox,region.kind);
  btn.disabled=false;btn.textContent='Исправить выбранное';
  if(!r.ok){toast(r.message||'Не удалось создать маску',true);return}
  setSource('edit',source);
  state.editMask=r.path;
  applyEditMode('exact');
  $('#editPrompt').value=qualityRepairPrompt(region);
  $('#editPromptMode').value='original';
  $('#maskStatus').textContent='Авто-маска · '+region.label+' · контекст '+(r.bbox_px?.[2]-r.bbox_px?.[0]||0)+'×'+(r.bbox_px?.[3]-r.bbox_px?.[1]||0);
  scheduleEditPrompt();
  closeQualityInspector();
  switchView('edit');
  toast('Область подготовлена для локального ремонта. Проверь текст и нажми «Изменить».');
}
function setSource(kind,path){
  if(!path)return;
  if(kind==='edit'){state.editSource=path;setSourcePreview($('#editDrop'),$('#editSourcePreview'),path)}
  if(kind==='animate'){state.animateSource=path;setSourcePreview($('#animateDrop'),$('#animateSourcePreview'),path)}
  if(kind==='enhance'){
    state.enhanceSource=path;$('#enhanceDrop').classList.add('has-source');
    $('#enhanceDrop .source-placeholder').innerHTML='<strong>'+path.split(/[\\/]/).pop()+'</strong><span>Источник выбран</span>';
  }
}
function setSourcePreview(drop,img,path){
  drop.classList.add('has-source');img.src='file:///'+path.replace(/\\/g,'/').replace(/ /g,'%20');
}
async function commitCreateReferenceChange(){
  renderCreateReferences();
  if(state.autoModel)await updateAutoModelRecommendation();else renderAutoModelStatus();
  schedulePrompt();
}
function appendCreateReferences(paths){
  let added=0;
  for(const path of paths||[]){
    const clean=String(path||'').trim();
    if(!clean||state.createReferences.length>=CREATE_REFERENCE_MAX)break;
    if(state.createReferences.includes(clean))continue;
    state.createReferences.push(clean);state.createReferenceRoles.push('auto');added++;
  }
  if(added&&state.structureControl){
    state.structureControl='';
    renderStructureControl();
  }
  return added;
}
async function pickCreateReferences(){
  const r=await api('choose_images');
  if(!r.ok)return;
  const added=appendCreateReferences(r.paths||[]);
  await commitCreateReferenceChange();
  if(r.truncated||state.createReferences.length>=CREATE_REFERENCE_MAX)toast('Reference Board заполнен: максимум '+CREATE_REFERENCE_MAX+' изображений');
  else if(added)toast('Добавлено референсов: '+added);
}
async function pasteCreateReference(){
  if(state.createReferences.length>=CREATE_REFERENCE_MAX){toast('Достигнут лимит '+CREATE_REFERENCE_MAX+' референсов',true);return}
  const r=await api('paste_image');
  if(!r.ok){toast(r.message||'В буфере нет изображения',true);return}
  const added=appendCreateReferences([r.path]);
  await commitCreateReferenceChange();
  if(added)toast('Изображение добавлено как референс');
}
async function removeCreateReference(index){
  if(index<0||index>=state.createReferences.length)return;
  state.createReferences.splice(index,1);state.createReferenceRoles.splice(index,1);
  await commitCreateReferenceChange();
}
async function clearCreateReferences(){
  state.createReferences=[];state.createReferenceRoles=[];
  await commitCreateReferenceChange();
}
function preferredStructureControlModel(){
  const models=state.backend?.models||[];
  return models.find(m=>m.id==='zimage_turbo_q5'&&m.installed&&m.structure_control_installed)
    ||models.find(m=>m.installed&&m.structure_control_installed)||null;
}
function structureControlModel(){
  const current=modelById(state.createModel);
  if(!state.autoModel&&current?.installed&&current.structure_control_installed)return current;
  return preferredStructureControlModel();
}
function structureModeLabel(mode=state.structureMode){
  return ({canny:'Контуры',pose:'Поза',depth:'Глубина'})[mode]||'Контуры';
}
function structureModeAvailable(model=structureControlModel(),mode=state.structureMode){
  return !!(model?.structure_control_modes||[]).includes(mode);
}
function structureControlCapable(modelId=state.createModel){
  const model=modelById(modelId);
  return !!(model?.installed&&model.structure_control_installed&&(model.structure_control_modes||[]).includes(state.structureMode));
}
function renderStructureControl(){
  const card=$('#createStructureCard'),preview=$('#structureControlPreview'),img=preview?.querySelector('img');
  const status=$('#structureControlStatus'),badge=$('#structureControlBadge'),strength=$('#structureStrength');
  if(!card||!preview||!status||!badge||!strength)return;
  const model=structureControlModel(),active=!!state.structureControl;
  const current=modelById(state.createModel),currentIsQwenUnion=current?.structure_control_backend==='qwen21_union';
  let available=structureModeAvailable(model,state.structureMode),capable=structureControlCapable();
  if(model&&!available){
    const fallback=(model.structure_control_modes||[])[0]||'canny';
    state.structureMode=fallback;
    available=structureModeAvailable(model,state.structureMode);
    capable=structureControlCapable();
  }
  const mode=state.structureMode||'canny',label=structureModeLabel(mode);
  $$('[data-structure-mode]').forEach(b=>{
    const m=b.dataset.structureMode;
    const enabled=!!model&&(model.structure_control_modes||[]).includes(m);
    b.disabled=!enabled;
    b.classList.toggle('active',m===mode);
  });
  preview.classList.toggle('empty',!active);
  if(active&&img){img.src=localFileUrl(state.structureControl);img.title=state.structureControl}
  else if(img){img.removeAttribute('src');img.removeAttribute('title')}
  const placeholder=preview.querySelector('span');
  if(placeholder)placeholder.textContent=mode==='pose'
    ?'Поза человека задаст положение тела, рук и ног'
    :mode==='depth'
      ?'Карта глубины задаст масштаб объектов и перспективу сцены'
      :'Контуры изображения зададут композицию и геометрию сцены';
  const activeBadge={canny:'Контуры активны',pose:'Поза активна',depth:'Глубина активна'}[mode]||label+' активен';
  badge.textContent=active?activeBadge:'Выкл';
  badge.classList.toggle('active',active);
  strength.value=String(state.structureStrength||1);
  $('#structureStrengthValue').textContent=Number(state.structureStrength||1).toFixed(2);
  $('#clearStructureControl').disabled=!active;
  $('#pickStructureControl').disabled=!model||!structureModeAvailable(model,mode);
  $('#pasteStructureControl').disabled=!model||!structureModeAvailable(model,mode);
  strength.disabled=!active;
  status.classList.remove('warning');
  if(!model){
    status.textContent='Проверенный Structure Control сейчас недоступен.';
    status.classList.add('warning');
  }else if(!structureModeAvailable(model,mode)){
    status.textContent=label+' сейчас недоступен для выбранного structural backend.';
    status.classList.add('warning');
  }else if(active&&capable){
    status.textContent=currentIsQwenUnion
      ?'Контуры активны через Qwen Union: точнее держит позу, силуэт и композицию; Recommended использует 20 шагов, Maximum — 40.'
      :mode==='pose'
        ?'Поза активна: LocalGen выделит главного человека через DWPose и передаст только его позу в Z-Image.'
        :mode==='depth'
          ?'Глубина активна: LocalGen построит локальную Depth Anything V2 карту и сохранит масштаб/перспективу сцены.'
          :'Контуры активны через Z-Image: быстрее Qwen Union и выше по standalone visual-quality score.';
  }else if(active){
    status.textContent='Контроль выбран, но текущая модель его не поддерживает. Переключись на '+model.name+'.';
    status.classList.add('warning');
  }else{
    status.textContent=currentIsQwenUnion
      ?'Qwen Union использует Canny-контуры для максимально точного следования структуре; на RTX 3070 проверен примерно до 1.1 Мп.'
      :mode==='pose'
        ?'Использует позу главного человека, но не копирует его внешность.'
        :mode==='depth'
          ?'Использует только относительную глубину и перспективу, без копирования внешности/текстур.'
          :'Использует только контуры. Лицо, стиль и цвета исходника напрямую не копируются.';
  }
  const switcher=$('#useZImageForStructure');
  if(switcher){
    switcher.textContent=model?'Выбрать '+model.name:'Выбрать модель контроля';
    switcher.classList.toggle('hidden',!active||capable||!model);
  }
  const shootout=$('#modelShootoutBtn');
  if(shootout){
    const blocked=state.createReferences.length>0||active;
    shootout.disabled=blocked;
    shootout.title=state.createReferences.length?'Model Shootout отключён для reference-generation: референсы требуют Qwen-Image-2.1.':(active?'Model Shootout отключён при активном контроле структуры.':'');
  }
}
async function commitStructureControl(path){
  state.structureControl=String(path||'').trim();
  if(state.structureControl){
    state.createReferences=[];state.createReferenceRoles=[];
    renderCreateReferences();
  }
  renderStructureControl();
  if(state.autoModel)await updateAutoModelRecommendation();else renderAutoModelStatus();
  updateGenerateHint();
}
async function pickStructureControl(){
  const r=await api('choose_image');if(!r.ok)return;
  await commitStructureControl(r.path);
  if(r.path)toast('Контроль структуры добавлен');
}
async function pasteStructureControl(){
  const r=await api('paste_image');
  if(!r.ok){toast(r.message||'В буфере нет изображения',true);return}
  await commitStructureControl(r.path);
  toast('Контроль структуры вставлен');
}
async function clearStructureControl(){
  await commitStructureControl('');
}
async function setStructureMode(mode){
  const clean=['canny','pose','depth'].includes(mode)?mode:'canny';
  const model=structureControlModel();
  if(model&&!structureModeAvailable(model,clean)){
    toast(structureModeLabel(clean)+' сейчас недоступен',true);
    return;
  }
  state.structureMode=clean;
  savePrefs();
  renderStructureControl();
  if(state.structureControl&&state.autoModel)await updateAutoModelRecommendation();
  else renderAutoModelStatus();
  updateGenerateHint();
}
async function selectZImageForStructure(){
  const model=structureControlModel();
  if(!model){toast('Structure Control недоступен',true);return}
  state.autoModel=false;state.autoRecommendation=null;state.autoRequestSeq++;state.createModel=model.id;
  savePrefs();renderModels();renderAutoModelStatus();renderExpertModelControls();renderCreateQuality();renderCreateReferences();renderStructureControl();schedulePrompt();updateGenerateHint();
}
function readDroppedImage(file){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error||new Error('FileReader error'));reader.readAsDataURL(file);
  });
}
async function addDroppedCreateReferences(files){
  const images=[...(files||[])].filter(f=>f.type?.startsWith('image/')).slice(0,Math.max(0,CREATE_REFERENCE_MAX-state.createReferences.length));
  let added=0;
  for(const file of images){
    try{
      const data=await readDroppedImage(file);
      const r=await api('save_dropped_image',data,file.name);
      if(r.ok)added+=appendCreateReferences([r.path]);
    }catch{}
  }
  await commitCreateReferenceChange();
  if(added)toast('Добавлено референсов: '+added);
}
function wireCreateReferenceDrop(){
  const el=$('#createReferenceDrop');if(!el)return;
  ['dragenter','dragover'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.add('dragover')}));
  ['dragleave','drop'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.remove('dragover')}));
  el.addEventListener('drop',e=>addDroppedCreateReferences(e.dataTransfer?.files));
}
function setEditReference(slot,path){
  if(slot<0||slot>2)return;
  state.editReferences[slot]=path||'';
  if(!path)state.editReferenceRoles[slot]='auto';
  renderEditReferences();
}
function renderEditReferences(){
  $$('.reference-slot').forEach(el=>{
    const slot=+el.dataset.referenceSlot;
    const path=state.editReferences[slot]||'';
    const img=el.querySelector('img');
    const role=el.querySelector('[data-ref-role]');
    if(role)role.value=state.editReferenceRoles[slot]||'auto';
    el.classList.toggle('has-reference',!!path);
    if(path){
      img.src='file:///'+path.replace(/\\/g,'/').replace(/ /g,'%20');
      img.title=path;
    }else{
      img.removeAttribute('src');img.removeAttribute('title');
    }
  });
}
function characterById(id){return state.characters.find(x=>x.id===id)}
function renderCharacters(){
  const options='<option value="">Сохранённый персонаж…</option>'+state.characters.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>').join('');
  const create=$('#createCharacterSelect');
  if(create){
    create.innerHTML=options;
    if(state.characters.some(x=>x.id===state.createCharacter))create.value=state.createCharacter;
    else state.createCharacter='';
  }
  for(const sel of [$('#editCharacterSelect'),$('#animateCharacterSelect')]){
    if(!sel)continue;
    const current=sel.value;
    sel.innerHTML=options;
    if(state.characters.some(x=>x.id===current))sel.value=current;
  }
  if($('#deleteCharacter'))$('#deleteCharacter').disabled=!$('#editCharacterSelect')?.value;
  updateCreateCharacterUI();
  updateGenerateHint();
}
async function loadCharacters(){
  const r=await api('list_characters');
  if(!r.ok){toast(r.message||'Не удалось загрузить персонажей',true);return}
  state.characters=r.items||[];
  renderCharacters();
}
function closeCharacterModal(){
  state.pendingCharacterSave=null;
  $('#characterModal').classList.add('hidden');
  $('#characterPreview').removeAttribute('src');
}
function saveCharacterFrom(path,description=''){
  if(!path||/\.(mp4|mkv|webm|mov)$/i.test(path)){toast('Для персонажа нужна картинка',true);return}
  state.pendingCharacterSave={path,description:String(description||'').trim()};
  $('#characterName').value='';
  $('#characterDescription').value=state.pendingCharacterSave.description;
  $('#characterPreview').src=localFileUrl(path);
  $('#characterModal').classList.remove('hidden');
  setTimeout(()=>$('#characterName').focus(),0);
}
async function commitCharacterSave(){
  const pending=state.pendingCharacterSave;
  if(!pending?.path){closeCharacterModal();return}
  const name=$('#characterName').value.trim();
  if(!name){toast('Укажи имя персонажа',true);$('#characterName').focus();return}
  const description=$('#characterDescription').value.trim();
  const button=$('#characterSave');button.disabled=true;
  try{
    const r=await api('create_character',name,pending.path,description);
    if(!r.ok){toast(r.message||'Не удалось сохранить персонажа',true);return}
    await loadCharacters();
    closeCharacterModal();
    toast('Персонаж сохранён: '+r.item.name);
  }finally{button.disabled=false}
}
function applyEditCharacter(){
  const item=characterById($('#editCharacterSelect').value);
  if(!item){toast('Выбери персонажа',true);return}
  setEditReference(0,item.image_path);
  state.editReferenceRoles[0]='identity';
  renderEditReferences();
  toast(item.name+' добавлен как референс лица');
}
function applyAnimateCharacter(){
  const item=characterById($('#animateCharacterSelect').value);
  if(!item){toast('Выбери персонажа',true);return}
  setSource('animate',item.image_path);
  toast(item.name+' выбран как источник');
}
async function deleteSelectedCharacter(){
  const item=characterById($('#editCharacterSelect').value);
  if(!item)return;
  if(!window.confirm('Удалить персонажа «'+item.name+'»?'))return;
  const r=await api('delete_character',item.id);
  if(!r.ok){toast(r.message||'Не удалось удалить персонажа',true);return}
  await loadCharacters();
  toast('Персонаж удалён');
}
async function pickEditReference(slot){
  const r=await api('choose_image');
  if(r.ok)setEditReference(slot,r.path);
}
async function pasteEditReference(slot){
  const r=await api('paste_image');
  if(r.ok)setEditReference(slot,r.path);else toast(r.message||'В буфере нет изображения',true);
}
function wireReferenceDrop(el,slot){
  ['dragenter','dragover'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.add('dragover')}));
  ['dragleave','drop'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.remove('dragover')}));
  el.addEventListener('drop',e=>{
    const file=e.dataTransfer?.files?.[0];if(!file)return;
    if(file.type?.startsWith('image/')){
      const reader=new FileReader();
      reader.onload=async()=>{const r=await api('save_dropped_image',reader.result,file.name);if(r.ok)setEditReference(slot,r.path);else toast(r.message||'Не удалось принять файл',true)};
      reader.readAsDataURL(file);return;
    }
    if(file.path)setEditReference(slot,file.path);else toast('Для этого файла используй «Выбрать»');
  });
}
async function pickSource(kind){
  const method=kind==='enhance'&&state.enhanceType==='video'?'choose_video':'choose_image';
  const r=await api(method);if(r.ok)setSource(kind,r.path);
}
async function pasteSource(kind){
  const r=await api('paste_image');
  if(r.ok)setSource(kind,r.path);else toast(r.message||'В буфере нет изображения',true);
}
function wireDrop(el,kind){
  ['dragenter','dragover'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.add('dragover')}));
  ['dragleave','drop'].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();el.classList.remove('dragover')}));
  el.addEventListener('drop',e=>{
    const file=e.dataTransfer?.files?.[0];if(!file)return;
    if(file.type?.startsWith('image/')){
      const reader=new FileReader();
      reader.onload=async()=>{const r=await api('save_dropped_image',reader.result,file.name);if(r.ok)setSource(kind,r.path);else toast(r.message||'Не удалось принять файл',true)};
      reader.readAsDataURL(file);return;
    }
    if(file.path)setSource(kind,file.path);else toast('Для видео используй кнопку «Выбрать файл»');
  });
}
async function waitCreateBatchJob(jobId,index,total,displayLabel=''){
  state.jobId=jobId;
  while(!state.batchCancelled&&state.jobId===jobId){
    const j=await api('job_state',jobId);
    updateDiagnostics(j);
    if(['queued','starting_backend','running'].includes(j.state)){
      const elapsed=j.started_at?Math.max(0,Math.round(Date.now()/1000-j.started_at)):0;
      const phase=j.state==='queued'?'в очереди':j.state==='starting_backend'?'запуск AI':'генерация';
      const label=(displayLabel||('Вариант '+index+'/'+total))+' · '+phase+(elapsed?' · '+elapsed+' с':'');
      $('#jobState').textContent=label;$$('.mirror-state').forEach(x=>x.textContent=label);
      await new Promise(r=>setTimeout(r,800));continue;
    }
    if(j.state==='succeeded'){
      if(j.output_path)showResult(j.output_path,j.output_url,'',j);
      state.jobId='';
      return {ok:true,job:j};
    }
    if(j.state==='cancelled'){state.jobId='';return {ok:false,cancelled:true,job:j}}
    state.jobId='';
    return {ok:false,message:j.error||'Вариант завершился с ошибкой',job:j};
  }
  return {ok:false,cancelled:true};
}
async function runCreateBatch(payload,count){
  state.batchActive=true;state.batchCancelled=false;
  setBusy(true,'Подготовка серии…');
  const rawSeed=$('#createSeed').value.trim();
  const baseSeed=rawSeed?Math.max(0,Math.min(2147483647,+rawSeed||0)):(Date.now()%2147000000);
  const batchGroup='batch_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
  let done=0;
  for(let i=0;i<count;i++){
    if(state.batchCancelled)break;
    const seed=(baseSeed+i*7919)%2147483647;
    const r=await api('start_job','create',{...payload,seed,batch_index:i+1,batch_total:count,batch_group:batchGroup});
    if(!r.ok){toast(r.message||'Не удалось запустить вариант',true);break}
    const result=await waitCreateBatchJob(r.job_id,i+1,count);
    if(!result.ok){
      if(!result.cancelled)toast(result.message||'Ошибка генерации',true);
      break;
    }
    done++;
  }
  state.batchActive=false;state.jobId='';
  setBusy(false);
  await loadLibrary();
  if(done>1&&batchItems(batchGroup).length<done){await new Promise(r=>setTimeout(r,450));await loadLibrary()}
  if(state.batchCancelled){$$('.mirror-state').forEach(x=>x.textContent='Остановлено');toast('Серия остановлена');return}
  $$('[data-stop-job]').forEach(x=>x.classList.add('hidden'));
  $('#jobState').textContent=done===count?'Готово':'Серия завершена';
  $$('.mirror-state').forEach(x=>x.textContent=$('#jobState').textContent);
  if(done>1)openBatchCompare(batchGroup);
  toast(done===count?(count>1?'Готово вариантов: '+done:'Готово'):'Готово вариантов: '+done);
}
async function runMoreVariants(job,parentPath='',parentUrl=''){
  if(queueHasJobs()||state.jobId){toast('Для серии вариантов сначала дождись текущей очереди',true);return}
  const recipe=cleanCreateRecipe(job);
  if(!recipe){toast('Для этого результата варианты недоступны');return}
  const originalSeed=+recipe.seed;
  const group='variant_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
  const total=3;
  state.batchActive=true;state.batchCancelled=false;
  setBusy(true,'Подготовка вариантов…');
  let done=0;
  for(let i=0;i<2;i++){
    if(state.batchCancelled)break;
    let seed=(originalSeed+(i+1)*7919)%2147483647;
    if(seed<=0)seed=originalSeed+i+1;
    const payload={
      ...recipe,
      seed,
      variant_group:group,
      variant_index:i+2,
      variant_total:total,
      variant_parent_output:parentPath||state.lastOutput||'',
      variant_parent_seed:originalSeed
    };
    const r=await api('start_job','create',payload);
    if(!r.ok){toast(r.message||'Не удалось запустить вариант',true);break}
    const result=await waitCreateBatchJob(r.job_id,i+2,total,'Вариант '+(i+2)+'/'+total);
    if(!result.ok){
      if(!result.cancelled)toast(result.message||'Ошибка варианта',true);
      break;
    }
    done++;
  }
  state.batchActive=false;state.jobId='';
  setBusy(false);
  await loadLibrary();
  if(done&&variantItems(group).length<done+1){await new Promise(r=>setTimeout(r,450));await loadLibrary()}
  if(state.batchCancelled){$$('.mirror-state').forEach(x=>x.textContent='Остановлено');toast('Варианты остановлены');return}
  $$('[data-stop-job]').forEach(x=>x.classList.add('hidden'));
  $('#jobState').textContent=done===2?'Варианты готовы':'Варианты завершены';
  $$('.mirror-state').forEach(x=>x.textContent=$('#jobState').textContent);
  const items=variantItems(group);
  if(items.length>=2)openComparison(items,'variant');
  toast(done===2?'Добавлены ещё 2 варианта':'Готово вариантов: '+done);
}
function shootoutEligibleModels(){
  return (state.backend?.models||[]).filter(m=>m.kind==='create'&&m.installed&&m.workflow!=='character_scene');
}
function closeShootoutModal(){$('#shootoutModal').classList.add('hidden')}
function updateShootoutSelectionCount(){
  const count=$$('[data-shootout-model]:checked',$('#shootoutModels')).length;
  const total=$$('[data-shootout-model]',$('#shootoutModels')).length;
  if($('#shootoutSelectedCount'))$('#shootoutSelectedCount').textContent='Выбрано: '+count+' из '+total;
  if($('#shootoutRun'))$('#shootoutRun').disabled=count<2;
}
function openModelShootout(){
  if(queueHasJobs()||state.jobId){toast('Сравнение моделей запускается только при пустой очереди',true);return}
  if(state.createReferences.length){toast('Model Shootout недоступен с референсами: reference workflow использует Qwen-Image-2.1',true);return}
  if(state.structureControl){toast('Model Shootout недоступен при активном контроле структуры',true);return}
  const models=shootoutEligibleModels();
  if(models.length<2){toast('Для сравнения нужны хотя бы две установленные модели',true);return}
  const selected=new Set();
  if(models.some(m=>m.id===state.createModel))selected.add(state.createModel);
  for(const m of models){
    if(selected.size>=3)break;
    if(m.recommended&&!m.adult)selected.add(m.id);
  }
  for(const m of models){if(selected.size>=2)break;selected.add(m.id)}
  $('#shootoutModels').innerHTML=models.map(m=>
    '<label class="shootout-choice"><input type="checkbox" data-shootout-model="'+esc(m.id)+'" '+(selected.has(m.id)?'checked':'')+'>'+
    '<div><strong>'+esc(m.name)+'</strong><span>'+esc((m.category_label||'Модель')+' · '+(m.best_for||''))+'</span></div></label>'
  ).join('');
  $$('[data-shootout-model]',$('#shootoutModels')).forEach(x=>x.addEventListener('change',updateShootoutSelectionCount));
  updateShootoutSelectionCount();
  $('#shootoutModal').classList.remove('hidden');
}
async function runModelShootout(){
  if(queueHasJobs()||state.jobId){closeShootoutModal();toast('Сравнение моделей запускается только при пустой очереди',true);return}
  const original=$('#createPrompt').value.trim();
  if(!original){closeShootoutModal();toast('Сначала опиши, что нужно создать',true);return}
  const ids=$$('[data-shootout-model]:checked',$('#shootoutModels')).map(x=>x.dataset.shootoutModel);
  if(ids.length<2){toast('Выбери хотя бы 2 модели',true);return}
  const models=ids.map(modelById).filter(Boolean);
  if(models.length!==ids.length){toast('Одна из моделей больше недоступна',true);return}
  const preparedInput=promptStudioInput(original);
  const mode=$('#promptMode').value;
  const prepared=[];
  $('#shootoutRun').disabled=true;
  try{
    for(const model of models){
      const p=await api('prepare_prompt',preparedInput,mode,model.id);
      if(!p.ok){toast((p.message||'Не удалось подготовить промпт')+' · '+model.name,true);return}
      prepared.push({model,prompt:p.final||preparedInput});
    }
  }finally{$('#shootoutRun').disabled=false}
  closeShootoutModal();
  rememberPrompt('create',original);
  state.batchActive=true;state.batchCancelled=false;
  setBusy(true,'Подготовка сравнения…');
  const rawSeed=$('#createSeed').value.trim();
  const seed=rawSeed?Math.max(0,Math.min(2147483647,+rawSeed||0)):(Date.now()%2147000000);
  const group='models_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
  const size=currentCreateSize(),width=size.width,height=size.height;
  const delivery=deliveryTarget(width,height);
  let done=0;const failures=[];
  for(let i=0;i<prepared.length;i++){
    if(state.batchCancelled)break;
    const {model,prompt}=prepared[i];
    const payload={
      model:model.id,prompt,width,height,seed,create_quality:state.createQuality,
      delivery_preset:state.deliveryPreset,
      output_width:delivery.preset==='native'?0:delivery.width,output_height:delivery.preset==='native'?0:delivery.height,
      expert:{...modelExpertOverrides(model.id)},
      source_prompt:original,prompt_mode:mode,aspect:size.aspect,prompt_studio:promptStudioState(),
      shootout_group:group,shootout_index:i+1,shootout_total:prepared.length
    };
    const r=await api('start_job','create',payload);
    if(!r.ok){failures.push(model.name+': '+(r.message||'не удалось запустить'));continue}
    const result=await waitCreateBatchJob(r.job_id,i+1,prepared.length,model.name+' '+(i+1)+'/'+prepared.length);
    if(!result.ok){
      if(result.cancelled)break;
      failures.push(model.name+': '+(result.message||'ошибка генерации'));continue;
    }
    done++;
  }
  state.batchActive=false;state.jobId='';
  setBusy(false);
  await loadLibrary();
  if(done>=2&&shootoutItems(group).length<done){await new Promise(r=>setTimeout(r,450));await loadLibrary()}
  if(state.batchCancelled){$$('.mirror-state').forEach(x=>x.textContent='Остановлено');toast('Сравнение остановлено');return}
  $$('[data-stop-job]').forEach(x=>x.classList.add('hidden'));
  $('#jobState').textContent=done===prepared.length?'Сравнение готово':('Готово '+done+' из '+prepared.length);
  $$('.mirror-state').forEach(x=>x.textContent=$('#jobState').textContent);
  if(done>=2)openShootoutCompare(group);
  if(failures.length)toast('Готово '+done+' из '+prepared.length+'. Ошибки: '+failures.length,true);else toast('Модели готовы к сравнению');
}
async function doGenerate(){
  const original=$('#createPrompt').value.trim();if(!original){toast('Опиши, что нужно создать',true);return}
  if(state.autoModel)await updateAutoModelRecommendation();
  const referencePairs=createReferencePairs();
  if(state.structureControl&&referencePairs.length){
    toast('Контроль структуры и Qwen Reference Board нельзя использовать одновременно',true);return;
  }
  if(state.structureControl&&!structureControlCapable()){
    toast('Для контроля структуры выбери Z-Image Turbo или включи авто-подбор',true);return;
  }
  if(referencePairs.length&&!createReferenceCapable()){
    toast('Для генерации с референсами выбери Qwen-Image-2.1 или включи авто-подбор',true);return;
  }
  await preparePromptNow();const prompt=$('#processedPrompt').value.trim()||original;
  rememberPrompt('create',original);
  const count=Math.max(1,Math.min(4,+$('#createVariants').value||state.batchCount||1));
  if(count>1&&(queueHasJobs()||state.jobId)){toast('Серия вариантов запускается только при пустой очереди. Для очереди выбери 1 вариант.',true);return}
  state.batchCount=count;savePrefs();
  const size=currentCreateSize(),baseWidth=size.width,baseHeight=size.height;
  const delivery=deliveryTarget(baseWidth,baseHeight);
  const payload={
    model:state.createModel,prompt,width:baseWidth,height:baseHeight,create_quality:state.createQuality,
    delivery_preset:state.deliveryPreset,
    output_width:delivery.preset==='native'?0:delivery.width,output_height:delivery.preset==='native'?0:delivery.height,
    expert:state.createQuality==='custom'?currentExpertOverrides():{},
    source_prompt:original,prompt_mode:$('#promptMode').value,aspect:size.aspect,prompt_studio:promptStudioState(),
    auto_model:!!state.autoModel,auto_recommendation:state.autoModel&&state.autoRecommendation?{model_id:state.autoRecommendation.model_id,reason:state.autoRecommendation.reason,warning:state.autoRecommendation.warning,confidence:state.autoRecommendation.confidence}:null,
    references:referencePairs.map(x=>x.path),reference_roles:referencePairs.map(x=>x.role),
    structure_control:state.structureControl&&structureControlCapable()?state.structureControl:'',
    structure_mode:state.structureControl&&structureControlCapable()?state.structureMode:'canny',
    structure_strength:Number(state.structureStrength||1)
  };
  if(state.createModel==='qwen21_character'){
    const character=characterById(state.createCharacter);
    if(!character){toast('Выбери сохранённого персонажа для новой сцены',true);return}
    payload.character_id=character.id;
    payload.character_name=character.name;
    payload.character_image=character.image_path;
  }
  if(count===1){
    const seed=$('#createSeed').value.trim();
    start('create',{...payload,seed:seed?+seed:0});
  }else{
    runCreateBatch(payload,count);
  }
}
function applyEditMode(mode,{persist=true}={}){
  state.editMode=mode==='exact'?'exact':mode==='adult'?'adult':'smart';
  if(persist)savePrefs();
  scheduleEditPrompt();
  $$('[data-edit-mode]').forEach(x=>x.classList.toggle('active',x.dataset.editMode===state.editMode));
  $('#maskControls').classList.toggle('hidden',state.editMode!=='exact');
  $('#referenceCard').classList.toggle('hidden',state.editMode==='exact');
  $('#editModeHelp').textContent=state.editMode==='exact'
    ?'Локальный ремонт автоматически выбирает Qwen для лица, глаз, рук и анатомии, а FLUX.2 для простых локальных материалов/объектов. Маленькая маска увеличивается с контекстом; пиксели вне неё сохраняются.'
    :state.editMode==='adult'
      ?'18+ Adult Edit использует локальный Qwen-Image-2.1 без облачной модерации и принимает только явно совершеннолетних персонажей. Сейчас это базовый Qwen; специализированный anatomy/NSFW LoRA v2 ещё проходит квалификацию.'
      :'Qwen-Image-2.1 понимает всю сцену и подходит для одежды, фона, объектов и крупных смысловых изменений.';
}
async function doEdit(){
  if(!state.editSource){toast('Выбери исходное изображение',true);return}
  const original=$('#editPrompt').value.trim();if(!original){toast('Напиши, что нужно изменить',true);return}
  const prompt=await prepareEditPromptNow();if(!prompt)return;
  rememberPrompt('edit',original);
  const meta={source_prompt:original,prompt_mode:$('#editPromptMode').value,edit_mode:state.editMode};
  if(state.editMode==='exact'){
    if(!state.editMask){toast('Для точного режима нужна маска',true);return}
    start('edit_exact',{image:state.editSource,mask:state.editMask,prompt:prompt,...meta});
  }else{
    const pairs=state.editReferences.map((path,i)=>({path,role:state.editReferenceRoles[i]||'auto'})).filter(x=>x.path);
    start('edit_smart',{image:state.editSource,references:pairs.map(x=>x.path),reference_roles:pairs.map(x=>x.role),prompt:prompt,...meta});
  }
}
async function doAnimate(){
  if(!state.animateSource){toast('Выбери исходное фото',true);return}
  const original=$('#motionPrompt').value.trim();if(!original){toast('Опиши движение',true);return}
  const prompt=await prepareTaskPrompt(original,$('#motionPromptMode').value,state.animateModel,'#motionProcessedPrompt','#motionTranslatorBadge');
  if(!prompt)return;
  renderAnimateControls();
  const width=+state.animateWidth||640,height=+state.animateHeight||640;
  if(!animateResolutionValid(width,height)){toast('Разрешение выше безопасного лимита выбранной видеомодели. Выбери один из пресетов.',true);return}
  const seedRaw=String(state.animateSeed??'').trim();
  start('animate',{
    model:state.animateModel,image:state.animateSource,prompt:prompt,width,height,frames:state.frames,fps:state.fps,
    seed:seedRaw===''?'':Math.max(0,Math.min(2147483647,+seedRaw||0)),
    expert:currentAnimateExpert(),
    source_prompt:original,prompt_mode:$('#motionPromptMode').value,
    requested_duration_s:+state.animateSeconds||2
  });
}
function updateEnhanceUI(){
  const isVideo=state.enhanceType==='video';
  $('#imageEnhanceMethods').classList.toggle('hidden',isVideo);
  $('#videoEnhanceMethods').classList.toggle('hidden',!isVideo);
  $$('[data-image-enhance]').forEach(x=>x.classList.toggle('selected',x.dataset.imageEnhance===state.imageEnhanceMode));
  $$('[data-video-enhance]').forEach(x=>x.classList.toggle('selected',x.dataset.videoEnhance===state.videoEnhanceMode));
  const x4=$('[data-scale="4"]');
  const seedvr=isVideo&&state.videoEnhanceMode==='seedvr2';
  const omnisr=!isVideo&&state.imageEnhanceMode==='omnisr';
  const vosr2=!isVideo&&state.imageEnhanceMode==='vosr2';
  const lockedX2=seedvr||omnisr;
  if(lockedX2&&state.scale>2)state.scale=2;
  if(x4){
    x4.disabled=lockedX2;
    x4.title=seedvr?'SeedVR2 проверен в режиме ×2 на RTX 3070 8 ГБ':
      omnisr?'Установленная OmniSR модель обучена для ×2':'';
  }
  $$('[data-scale]').forEach(x=>x.classList.toggle('active',+x.dataset.scale===+state.scale));
  const hint=isVideo
    ?(seedvr?'SeedVR2 AI Restore · ×2':'NMKD Fast Video · ×'+state.scale)
    :(omnisr?'OmniSR Faithful · ×2':vosr2?'VOSR2 AI Restore · ×'+state.scale:'NMKD Detail Boost · ×'+state.scale);
  $('#enhanceHint').textContent=hint;
  $('#imageEnhanceHelp').textContent=omnisr
    ?'OmniSR — бережный x2: лучше всего сохраняет уже хорошие детали, структуру, цвет и лицо.'
    :vosr2
      ?'VOSR2 — генеративное восстановление: реконструирует волосы, кожу и мелкие структуры. Может правдоподобно дорисовывать отсутствующие детали.'
      :'NMKD — более агрессивный detail boost: сильнее подчёркивает резкость и микротекстуры, поддерживает ×2 и ×4.';
  $('#videoEnhanceHelp').textContent=seedvr
    ?'SeedVR2 3B FP8 + BlockSwap настроен под RTX 3070 8 ГБ. Реальный E2E: 512→1024, 17 кадров за ~95 секунд.'
    :'Быстрый NMKD обрабатывает кадры независимо. Используй, когда temporal-восстановление не нужно.';
}
async function doEnhance(){
  if(!state.enhanceSource){toast('Выбери файл',true);return}
  if(state.enhanceType==='image'){
    start('upscale_image',{path:state.enhanceSource,scale:state.scale,model:state.imageEnhanceMode});return;
  }
  const kind=state.videoEnhanceMode==='seedvr2'?'restore_video_seedvr2':'upscale_video';
  start(kind,{path:state.enhanceSource,scale:state.scale});
}
function sendLast(target){
  if(!state.lastOutput){toast('Сначала нужен результат');return}
  if(target==='edit'){setSource('edit',state.lastOutput);switchView('edit')}
  if(target==='animate'){
    if(/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput)){toast('Для оживления нужна картинка',true);return}
    setSource('animate',state.lastOutput);switchView('animate');
  }
  if(target==='enhance'){
    state.enhanceType=/\.(mp4|mkv|webm|mov)$/i.test(state.lastOutput)?'video':'image';
    setSource('enhance',state.lastOutput);switchView('enhance');
  }
}
let maskBitmapCanvas=null, maskDrawing=false, maskErase=false, maskInvert=false, maskLast=null;

function openMaskEditor(){
  if(!state.editSource){toast('Сначала выбери исходное изображение',true);return}
  const modal=$('#maskModal'), img=$('#maskImage'), overlay=$('#maskOverlay');
  modal.classList.remove('hidden');
  maskInvert=false;
  $('#maskInvert').classList.remove('active');
  overlay.style.opacity=String((+$('#maskOpacity').value||85)/100);
  img.onload=()=>{
    overlay.width=img.naturalWidth;overlay.height=img.naturalHeight;
    maskBitmapCanvas=document.createElement('canvas');
    maskBitmapCanvas.width=img.naturalWidth;maskBitmapCanvas.height=img.naturalHeight;
    const mctx=maskBitmapCanvas.getContext('2d');
    mctx.fillStyle='black';mctx.fillRect(0,0,maskBitmapCanvas.width,maskBitmapCanvas.height);
    overlay.getContext('2d').clearRect(0,0,overlay.width,overlay.height);
  };
  img.src='file:///'+state.editSource.replace(/\\/g,'/').replace(/ /g,'%20');
}
function closeMaskEditor(){maskDrawing=false;maskLast=null;$('#maskModal').classList.add('hidden')}
function maskPoint(e){
  const c=$('#maskOverlay'),r=c.getBoundingClientRect();
  return {x:(e.clientX-r.left)*c.width/r.width,y:(e.clientY-r.top)*c.height/r.height};
}
function paintMaskSegment(a,b){
  if(!maskBitmapCanvas)return;
  const overlay=$('#maskOverlay'),octx=overlay.getContext('2d'),mctx=maskBitmapCanvas.getContext('2d');
  const size=+$('#maskBrush').value;
  [mctx,octx].forEach(ctx=>{ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=size});
  mctx.globalCompositeOperation='source-over';mctx.strokeStyle=maskErase?'black':'white';
  mctx.beginPath();mctx.moveTo(a.x,a.y);mctx.lineTo(b.x,b.y);mctx.stroke();
  octx.globalCompositeOperation=maskErase?'destination-out':'source-over';octx.strokeStyle='rgba(255,75,105,.58)';
  octx.beginPath();octx.moveTo(a.x,a.y);octx.lineTo(b.x,b.y);octx.stroke();
}
function wireMaskEditor(){
  const overlay=$('#maskOverlay');
  overlay.addEventListener('pointerdown',e=>{if(!maskBitmapCanvas)return;maskDrawing=true;maskLast=maskPoint(e);overlay.setPointerCapture(e.pointerId);paintMaskSegment(maskLast,maskLast)});
  overlay.addEventListener('pointermove',e=>{if(!maskDrawing)return;const p=maskPoint(e);paintMaskSegment(maskLast,p);maskLast=p});
  const end=()=>{maskDrawing=false;maskLast=null};overlay.addEventListener('pointerup',end);overlay.addEventListener('pointercancel',end);
  $('#maskDraw').onclick=()=>{maskErase=false;$('#maskDraw').classList.add('active');$('#maskErase').classList.remove('active')};
  $('#maskErase').onclick=()=>{maskErase=true;$('#maskErase').classList.add('active');$('#maskDraw').classList.remove('active')};
  $('#maskClear').onclick=()=>{if(!maskBitmapCanvas)return;const m=maskBitmapCanvas.getContext('2d');m.fillStyle='black';m.fillRect(0,0,maskBitmapCanvas.width,maskBitmapCanvas.height);overlay.getContext('2d').clearRect(0,0,overlay.width,overlay.height)};
  $('#maskInvert').onclick=()=>{maskInvert=!maskInvert;$('#maskInvert').classList.toggle('active',maskInvert);toast(maskInvert?'Инверсия: будет изменено всё кроме нарисованной области':'Инверсия выключена')};
  $('#maskOpacity').oninput=()=>{overlay.style.opacity=String((+$('#maskOpacity').value||85)/100)};
  $('#maskClose').onclick=closeMaskEditor;$('#maskCancel').onclick=closeMaskEditor;
  $('#maskSave').onclick=async()=>{
    if(!maskBitmapCanvas)return;
    const grow=Math.max(0,Math.min(32,+$('#maskGrow').value||0));
    const feather=Math.max(0,Math.min(24,+$('#maskFeather').value||0));
    const r=await api('save_mask',maskBitmapCanvas.toDataURL('image/png'),grow,feather,maskInvert);
    if(r.ok){
      state.editMask=r.path;
      const bits=['Маска готова'];
      if(r.grow)bits.push('+'+r.grow+' px');
      if(r.feather)bits.push('смягчение '+r.feather+' px');
      if(r.invert)bits.push('инверсия');
      $('#maskStatus').textContent=bits.join(' · ');
      closeMaskEditor();toast('Маска сохранена');
    }else toast(r.message||'Не удалось сохранить маску',true);
  };
}

function useLibraryItem(it,target){
  showResult(it.path,it.url,'',it.job||null);
  if(target==='edit'){
    if(it.type==='video'){toast('Видео нельзя отправить в редактор изображения',true);return}
    setSource('edit',it.path);switchView('edit');return;
  }
  if(target==='animate'){
    if(it.type==='video'){toast('Для оживления нужна картинка',true);return}
    setSource('animate',it.path);switchView('animate');return;
  }
  state.enhanceType=it.type==='video'?'video':'image';
  setSource('enhance',it.path);switchView('enhance');
}
async function copyLibraryItem(it){
  if(it.type==='video'){
    const r=await api('copy_text',it.path);toast(r.ok?'Путь к видео скопирован':'Не удалось скопировать',!r.ok);return;
  }
  const r=await api('copy_image',it.path);toast(r.ok?'Изображение скопировано':'Не удалось скопировать',!r.ok);
}
function batchItems(group){
  return state.libraryItems
    .filter(it=>it.job?.metadata?.batch_group===group)
    .sort((a,b)=>(+a.job?.metadata?.batch_index||0)-(+b.job?.metadata?.batch_index||0));
}
function shootoutItems(group){
  return state.libraryItems
    .filter(it=>it.job?.metadata?.shootout_group===group)
    .sort((a,b)=>(+a.job?.metadata?.shootout_index||0)-(+b.job?.metadata?.shootout_index||0));
}
function variantItems(group){
  const children=state.libraryItems
    .filter(it=>it.job?.metadata?.variant_group===group)
    .sort((a,b)=>(+a.job?.metadata?.variant_index||0)-(+b.job?.metadata?.variant_index||0));
  if(!children.length)return [];
  const parentPath=children[0].job?.metadata?.variant_parent_output||'';
  const parent=state.libraryItems.find(it=>String(it.path||'').toLowerCase()===String(parentPath).toLowerCase());
  return parent?[{...parent,_variantParent:true},...children]:children;
}
function closeBatchCompare(){$('#compareModal').classList.add('hidden')}
function variantScoreKey(items,prompt){
  return String(prompt||'').trim()+'\n'+items.map(x=>String(x?.path||'').toLowerCase()).join('\n');
}
function applyVariantScores(items,result,grid,key){
  if(!result?.ok||grid?.dataset?.qualityKey!==key)return;
  const scores=Array.isArray(result.scores)?result.scores:[];
  const ordered=[...scores].sort((a,b)=>(+a.rank||999)-(+b.rank||999));
  const realMargin=ordered.length>1?(+ordered[0].recommendation||0)-(+ordered[1].recommendation||0):1;
  const meaningful=result?.recommendation_meaningful!==false&&realMargin>=0.01;
  const strong=meaningful&&realMargin>=0.07&&result?.confidence==='normal';
  scores.forEach(s=>{
    const idx=+s.index;
    const card=grid.querySelector('[data-compare-card="'+idx+'"]');
    const box=grid.querySelector('[data-compare-quality="'+idx+'"]');
    const badge=grid.querySelector('[data-compare-recommend="'+idx+'"]');
    if(card)card.classList.toggle('recommended',+s.rank===1&&meaningful);
    if(box){
      const promptScore=Number(s.prompt_similarity);
      const aesthetic=Number(s.aesthetic);
      const technical=Number(s.technical_quality);
      const preference=Number(s.preference);
      const qrealign=s.qrealign_quality==null?NaN:Number(s.qrealign_quality);
      const composite=Number(s.recommendation);
      box.innerHTML='<b>#'+esc(s.rank||'—')+'</b><span>Промпт '+(Number.isFinite(promptScore)?promptScore.toFixed(3):'—')+
        ' · Эстетика '+(Number.isFinite(aesthetic)?aesthetic.toFixed(2):'—')+
        (Number.isFinite(technical)?' · Тех. '+technical.toFixed(3):'')+
        (Number.isFinite(preference)?' · HPS '+preference.toFixed(3):'')+
        (Number.isFinite(qrealign)?' · Q '+qrealign.toFixed(3):'')+
        ' · Сводный '+(Number.isFinite(composite)?composite.toFixed(2):'—')+'</span>';
      const qRelation=result?.qrealign_signal?.relation;
      box.title=result?.qrealign_signal?.used
        ?(qRelation==='corroborates'
          ?'Q-ReAlign независимо подтвердил текущего лидера. Он используется только как дополнительный сигнал и не является проверкой анатомии.'
          :qRelation==='disagrees'
            ?'Q-ReAlign заметно расходится с текущим рейтингом, поэтому уверенность понижена. Победитель автоматически не меняется; Q-ReAlign не является проверкой анатомии.'
            :'Q-ReAlign запущен, но разница между лидерами по нему слишком мала и не влияет на рейтинг. Он не является проверкой анатомии.')
        :result?.preference_signal?.used
          ?'Базовый рейтинг был близким, поэтому добавлен HPSv2.1 как 20% preference tie-break. TOPIQ и HPS не являются проверкой анатомии.'
          :Number.isFinite(technical)
            ?'Сводный рейтинг внутри серии: 55% промпт + 20% эстетика + 25% техническое качество TOPIQ. TOPIQ не является проверкой анатомии.'
            :'Сводный рейтинг внутри серии: 68% промпт + 32% эстетика.';
    }
    if(badge){
      const best=+s.rank===1;
      badge.classList.toggle('hidden',!best||!meaningful);
      if(best&&meaningful)badge.textContent=strong?'Рекомендуется':'Небольшое преимущество';
    }
  });
  const subtitle=$('#compareSubtitle');
  if(subtitle){
    subtitle.textContent=!meaningful
      ?'Подсказка качества: оценки лидеров практически равны, поэтому LocalGen не выбирает победителя.'
      :result?.qrealign_signal?.used&&result?.qrealign_signal?.relation==='disagrees'
        ?'Подсказка качества: Q-ReAlign заметно расходится с текущим лидером. Уверенность понижена, рейтинг автоматически не переопределяется.'
        :result?.qrealign_signal?.used&&result?.qrealign_signal?.relation==='corroborates'
          ?'Подсказка качества: Q-ReAlign независимо подтвердил текущего лидера. Рейтинг автоматически не переопределялся.'
          :result?.qrealign_signal?.used&&result?.qrealign_signal?.relation==='weak'
            ?'Подсказка качества: Q-ReAlign не дал значимого разрыва, поэтому основной рейтинг сохранён. Выбор остаётся за тобой.'
            :result?.preference_signal?.used
              ?'Подсказка качества: лидеры были близки, поэтому добавлена оценка человеческих предпочтений HPSv2.1. Выбор остаётся за тобой.'
              :(strong
                ?'Подсказка качества: #1 лучше по промпту, эстетике и техническому качеству. Выбор остаётся за тобой.'
                :'Подсказка качества: разница между лидерами небольшая. Выбор остаётся за тобой.');
  }
}
async function scoreVariantComparison(items,grid){
  const prompt=String(items.find(x=>x?.job?.metadata)?.job?.metadata?.source_prompt
    ||items.find(x=>x?.job?.metadata)?.job?.metadata?.prompt||'').trim();
  const paths=items.map(x=>String(x?.path||'')).filter(Boolean);
  if(!prompt||paths.length<2)return;
  const key=variantScoreKey(items,prompt);
  grid.dataset.qualityKey=key;
  const cached=state.variantScoreCache[key];
  if(cached){applyVariantScores(items,cached,grid,key);return}
  $$('[data-compare-quality]',grid).forEach(x=>x.innerHTML='<span>Оцениваю качество на CPU…</span>');
  const seq=++state.variantScoreRequestSeq;
  const r=await api('score_quality_variants',paths,prompt);
  if(seq!==state.variantScoreRequestSeq||grid.dataset.qualityKey!==key)return;
  if(!r?.ok){
    $$('[data-compare-quality]',grid).forEach(x=>x.innerHTML='<span>Оценка недоступна</span>');
    return;
  }
  state.variantScoreCache[key]=r;
  applyVariantScores(items,r,grid,key);
}
function openComparison(items,mode='batch'){
  if(items.length<2){toast('Недостаточно результатов для сравнения',true);return}
  const shootout=mode==='shootout',variant=mode==='variant';
  $('#compareTitle').textContent=shootout?'Сравнение моделей':variant?'Варианты результата':'Сравнить варианты';
  $('#compareSubtitle').textContent=shootout?'Один запрос, одинаковый seed и формат · выбери лучший результат':variant?'Та же модель, prompt, размер и качество · отличаются только seed':'Выбери лучший кадр серии';
  const grid=$('#compareGrid');
  grid.innerHTML=items.map((it,idx)=>{
    const meta=it.job?.metadata||{};
    const seed=meta.seed??'—';
    const elapsed=it.job?.started_at&&it.job?.ended_at?Math.max(0,Math.round(it.job.ended_at-it.job.started_at))+' с':'';
    const modelName=meta.model?(modelById(meta.model)?.name||meta.model):'Модель';
    const pos=variant?(it._variantParent?1:(meta.variant_index||idx+1)):(meta.batch_index||idx+1);
    const total=variant?(meta.variant_total||items.length):(meta.batch_total||items.length);
    const title=shootout?modelName:(variant&&it._variantParent?'Исходный · 1/'+total:'Вариант '+pos+'/'+total);
    const displayW=+meta.output_width||+meta.width||1,displayH=+meta.output_height||+meta.height||1;
    const details='Seed '+seed+' · '+displayW+'×'+displayH+(elapsed?' · '+elapsed:'');
    const finalize=canFinalizeJob(it.job)?'<button data-compare-finalize="'+idx+'" class="finalize-mini">Финал Max</button>':'';
    const quality=variant?'<div class="compare-quality" data-compare-quality="'+idx+'"><span>Оценка качества…</span></div>':'';
    const badge=variant?'<span class="compare-recommend hidden" data-compare-recommend="'+idx+'"></span>':'';
    return '<article class="compare-item" data-compare-card="'+idx+'"><div class="compare-image" style="aspect-ratio:'+displayW+'/'+displayH+'">'+badge+'<img src="'+esc(it.url)+'" alt=""></div>'+
      '<div class="compare-info"><strong>'+esc(title)+'</strong><span>'+esc(details)+'</span></div>'+quality+
      '<div class="compare-actions"><button data-compare-pick="'+idx+'" class="primary-mini">Выбрать</button>'+finalize+
      '<button data-compare-edit="'+idx+'">Изменить</button><button data-compare-animate="'+idx+'">Оживить</button><button data-compare-enhance="'+idx+'">Улучшить</button></div></article>';
  }).join('');
  $$('[data-compare-pick]',grid).forEach(b=>b.onclick=()=>{const it=items[+b.dataset.comparePick];const meta=it?.job?.metadata||{};const source=meta.finalized_from_output||meta.replay_of_output||'';showResult(it.path,it.url,source,it.job||null);closeBatchCompare();toast(shootout?'Результат модели выбран':'Вариант выбран')});
  $$('[data-compare-finalize]',grid).forEach(b=>b.onclick=()=>{const it=items[+b.dataset.compareFinalize];finalizeCreateJob(it.job,it.path)});
  $$('[data-compare-edit]',grid).forEach(b=>b.onclick=()=>{closeBatchCompare();useLibraryItem(items[+b.dataset.compareEdit],'edit')});
  $$('[data-compare-animate]',grid).forEach(b=>b.onclick=()=>{closeBatchCompare();useLibraryItem(items[+b.dataset.compareAnimate],'animate')});
  $$('[data-compare-enhance]',grid).forEach(b=>b.onclick=()=>{closeBatchCompare();useLibraryItem(items[+b.dataset.compareEnhance],'enhance')});
  $('#compareModal').classList.remove('hidden');
  if(variant)scoreVariantComparison(items,grid);
}
function openBatchCompare(group){openComparison(batchItems(group),'batch')}
function openShootoutCompare(group){openComparison(shootoutItems(group),'shootout')}
function restoreLibrarySettings(it){
  const job=it.job,meta=job?.metadata||{};
  if(!job||job.kind!=='create'){toast('Для этого результата настройки генерации не сохранены',true);return}
  if(meta.model)state.createModel=meta.model;
  state.autoModel=false;state.autoRecommendation=null;state.autoRequestSeq++;
  if(meta.aspect)state.aspect=meta.aspect;
  state.createQuality=['standard','max','custom'].includes(meta.create_quality)?meta.create_quality:'standard';
  state.deliveryPreset=meta.delivery_preset||((meta.output_width&&meta.output_height)?'custom':'native');
  if(!DELIVERY_NAMES[state.deliveryPreset])state.deliveryPreset='native';
  if(meta.model){
    if(!state.expertOverrides||typeof state.expertOverrides!=='object')state.expertOverrides={};
    if(meta.expert&&typeof meta.expert==='object'&&Object.keys(meta.expert).length)state.expertOverrides[meta.model]={...meta.expert};else delete state.expertOverrides[meta.model];
  }
  if(meta.width){$('#createWidth').value=meta.width;state.createWidth=+meta.width}
  if(meta.height){$('#createHeight').value=meta.height;state.createHeight=+meta.height}
  if(meta.width&&meta.height)syncAspectFromCurrentSize({persist:false,render:false});
  $('#createSeed').value=(meta.seed&&+meta.seed!==0)?meta.seed:'';
  if(meta.prompt_mode)$('#promptMode').value=meta.prompt_mode;
  if(meta.prompt_studio){
    state.promptStyle=meta.prompt_studio.style||'auto';
    state.promptLighting=meta.prompt_studio.lighting||'auto';
    state.promptCamera=meta.prompt_studio.camera||'auto';
    state.promptFraming=meta.prompt_studio.framing||'auto';
    applyPromptStudioControls();
  }
  $('#createPrompt').value=meta.source_prompt||meta.prompt||'';
  state.createReferences=Array.isArray(meta.references)?meta.references.filter(Boolean).slice(0,CREATE_REFERENCE_MAX):[];
  state.createReferenceRoles=Array.isArray(meta.reference_roles)?meta.reference_roles.slice(0,state.createReferences.length):[];
  while(state.createReferenceRoles.length<state.createReferences.length)state.createReferenceRoles.push('auto');
  state.structureControl=String(meta.structure_control||'').trim();
  state.structureMode=['canny','pose','depth'].includes(String(meta.structure_mode||'').toLowerCase())?String(meta.structure_mode).toLowerCase():'canny';
  state.structureStrength=Math.max(.1,Math.min(1.5,Number(meta.structure_strength)||1));
  if(state.structureControl){state.createReferences=[];state.createReferenceRoles=[]}
  renderModels();renderAutoModelStatus();renderExpertModelControls();renderAspects();renderDeliveryPresets();renderCreateQuality();renderCreateReferences();renderStructureControl();updateGenerateHint();savePrefs();schedulePrompt();switchView('create');
  toast('Настройки генерации восстановлены');
}
function renderLibrary(){
  const grid=$('#libraryGrid');
  const favorites=favoritePaths();
  const q=(state.libraryQuery||'').trim().toLowerCase();
  const items=state.libraryItems.filter(it=>{
    const fav=favorites.has(String(it.path||'').toLowerCase());
    const typeOk=state.libraryFilter==='all'||(state.libraryFilter==='favorite'?fav:it.type===state.libraryFilter);
    if(!typeOk)return false;
    if(!q)return true;
    const meta=it.job?.metadata||{};
    const modelName=meta.model?modelById(meta.model)?.name:'';
    const hay=[it.name,modelName,meta.source_prompt,meta.prompt].filter(Boolean).join(' ').toLowerCase();
    return hay.includes(q);
  });
  $('#libraryCount').textContent=items.length+' из '+state.libraryItems.length;
  if(!items.length){grid.innerHTML='<div class="library-empty">По этому фильтру ничего не найдено.</div>';return}
  grid.innerHTML=items.map(it=>{
    const i=state.libraryItems.indexOf(it);
    const isFav=favorites.has(String(it.path||'').toLowerCase());
    const media=it.type==='video'?'<video muted preload="metadata" src="'+esc(it.url)+'"></video>':'<img loading="lazy" src="'+esc(it.url)+'" alt="">';
    const size=(it.bytes/1048576).toFixed(it.bytes>10485760?0:1)+' МБ';
    const meta=it.job?.metadata||{};
    const prompt=(meta.source_prompt||'').trim();
    const modelName=meta.model?modelById(meta.model)?.name:'';
    const batchInfo=meta.batch_group&&+meta.batch_total>1
      ?'<span class="batch-chip">Вариант '+esc(meta.batch_index||'?')+'/'+esc(meta.batch_total)+' · seed '+esc(meta.seed??'—')+'</span>'
      :'';
    const shootoutInfo=meta.shootout_group&&+meta.shootout_total>1
      ?'<span class="batch-chip">Сравнение моделей '+esc(meta.shootout_index||'?')+'/'+esc(meta.shootout_total)+' · seed '+esc(meta.seed??'—')+'</span>'
      :'';
    const variantInfo=meta.variant_group?'<span class="batch-chip">Вариант '+esc(meta.variant_index||'?')+'/'+esc(meta.variant_total||'?')+' · seed '+esc(meta.seed??'—')+'</span>':'';
    const qualityInfo=it.job?.kind==='create'&&meta.create_quality==='max'?'<span class="batch-chip">Максимум'+(meta.finalized_from_output?' · финал':'')+'</span>':'';
    const replayInfo=meta.replay_of_output?'<span class="batch-chip">Точный повтор · seed '+esc(meta.seed??'—')+'</span>':'';
    const referenceInfo=+meta.reference_count?'<span class="batch-chip">Референсы · '+esc(meta.reference_count)+'</span>':'';
    const historyInfo=it.job
      ?'<div class="library-meta">'+(modelName?'<b>'+esc(modelName)+'</b>':'')+batchInfo+shootoutInfo+variantInfo+qualityInfo+replayInfo+referenceInfo+(prompt?'<span title="'+esc(prompt)+'">'+esc(prompt)+'</span>':'')+'</div>'
      :'';
    const restore=it.job?.kind==='create'?'<button data-lib-restore="'+i+'">Настройки</button>':'';
    const finalize=canFinalizeJob(it.job)?'<button data-lib-finalize="'+i+'">Финал Max</button>':'';
    const repeat=canReplayJob(it.job)?'<button data-lib-repeat="'+i+'">Повторить</button><button data-lib-variants="'+i+'">Ещё варианты</button>':'';
    const parentSource=meta.finalized_from_output||meta.replay_of_output||'';
    const finalCompare=parentSource?'<button data-lib-final-compare="'+i+'">До / После</button>':'';
    const variantCompare=meta.variant_group?'<button data-lib-variant-compare="'+i+'">Сравнить варианты</button>':'';
    const compare=meta.batch_group&&+meta.batch_total>1?'<button data-lib-compare="'+i+'">Сравнить</button>':(meta.shootout_group&&+meta.shootout_total>1?'<button data-lib-shootout="'+i+'">Сравнить модели</button>':'');
    const workflow=it.type==='video'
      ?'<button data-lib-enhance="'+i+'">Улучшить</button>'
      :compare+variantCompare+finalize+repeat+finalCompare+restore+'<button data-lib-character="'+i+'">Персонаж</button><button data-lib-edit="'+i+'">Изменить</button><button data-lib-animate="'+i+'">Оживить</button><button data-lib-enhance="'+i+'">Улучшить</button>';
    return '<div class="library-item '+(isFav?'favorite':'')+'"><div class="library-thumb">'+media+'<button class="library-star '+(isFav?'active':'')+'" data-lib-favorite="'+i+'" title="Избранное">★</button></div><div class="library-info"><strong title="'+esc(it.name)+'">'+esc(it.name)+'</strong><span>'+size+' · '+(it.type==='video'?'видео':'картинка')+'</span>'+historyInfo+'<div class="library-actions"><button data-lib-open="'+i+'">В папке</button><button data-lib-copy="'+i+'">Копировать</button>'+workflow+'</div></div></div>';
  }).join('');
  $$('[data-lib-favorite]').forEach(b=>b.onclick=()=>toggleFavorite(state.libraryItems[+b.dataset.libFavorite].path));
  $$('[data-lib-open]').forEach(b=>b.onclick=()=>api('reveal',state.libraryItems[+b.dataset.libOpen].path));
  $$('[data-lib-copy]').forEach(b=>b.onclick=()=>copyLibraryItem(state.libraryItems[+b.dataset.libCopy]));
  $$('[data-lib-compare]').forEach(b=>b.onclick=()=>{
    const it=state.libraryItems[+b.dataset.libCompare];
    const group=it?.job?.metadata?.batch_group;
    if(group)openBatchCompare(group);
  });
  $$('[data-lib-shootout]').forEach(b=>b.onclick=()=>{
    const it=state.libraryItems[+b.dataset.libShootout];
    const group=it?.job?.metadata?.shootout_group;
    if(group)openShootoutCompare(group);
  });
  $$('[data-lib-finalize]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libFinalize];finalizeCreateJob(it.job,it.path)});
  $$('[data-lib-repeat]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libRepeat];repeatCreateJob(it.job,it.path)});
  $$('[data-lib-variants]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libVariants];runMoreVariants(it.job,it.path,it.url)});
  $$('[data-lib-variant-compare]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libVariantCompare];const group=it?.job?.metadata?.variant_group;if(group)openComparison(variantItems(group),'variant')});
  $$('[data-lib-final-compare]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libFinalCompare];const meta=it?.job?.metadata||{};const source=meta.finalized_from_output||meta.replay_of_output||'';showResult(it.path,it.url,source,it.job||null);openBeforeAfter()});
  $$('[data-lib-restore]').forEach(b=>b.onclick=()=>restoreLibrarySettings(state.libraryItems[+b.dataset.libRestore]));
  $$('[data-lib-character]').forEach(b=>b.onclick=()=>{const it=state.libraryItems[+b.dataset.libCharacter];const m=it?.job?.metadata||{};saveCharacterFrom(it.path,m.source_prompt||m.prompt||'')});
  $$('[data-lib-edit]').forEach(b=>b.onclick=()=>useLibraryItem(state.libraryItems[+b.dataset.libEdit],'edit'));
  $$('[data-lib-animate]').forEach(b=>b.onclick=()=>useLibraryItem(state.libraryItems[+b.dataset.libAnimate],'animate'));
  $$('[data-lib-enhance]').forEach(b=>b.onclick=()=>useLibraryItem(state.libraryItems[+b.dataset.libEnhance],'enhance'));
}
async function loadLibrary(){
  const r=await api('recent_outputs',100);
  if(!r.ok)return;
  state.libraryItems=r.items||[];
  renderLibrary();
}

function normalizeRuntimePath(value){
  return String(value||'').replace(/\//g,'\\').replace(/\\+$/,'').toLowerCase();
}
function runtimeSettingsDirty(){
  const current=state.runtimeSettings||{};
  return normalizeRuntimePath(state.pendingRuntimeOutput)!==normalizeRuntimePath(current.output_directory)
    || String(state.pendingPerformanceProfile||'auto')!==String(current.performance_profile||'auto')
    || String(state.pendingVramPolicy||'keep')!==String(current.vram_policy||'keep')
    || Number(state.pendingVramIdleMinutes||10)!==Number(current.vram_idle_minutes||10)
    || String(state.pendingBackendPolicy||'keep')!==String(current.backend_policy||'keep')
    || Number(state.pendingBackendIdleMinutes||30)!==Number(current.backend_idle_minutes||30);
}
function syncRuntimeSettings(settings){
  if(!settings)return;
  state.runtimeSettings={...settings};
  state.pendingRuntimeOutput=String(settings.output_directory||settings.default_output_directory||'');
  state.pendingPerformanceProfile=String(settings.performance_profile||'auto');
  state.pendingVramPolicy=String(settings.vram_policy||'keep');
  state.pendingVramIdleMinutes=Math.max(1,Math.min(120,Number(settings.vram_idle_minutes||10)||10));
  state.pendingBackendPolicy=String(settings.backend_policy||'keep');
  state.pendingBackendIdleMinutes=Math.max(5,Math.min(240,Number(settings.backend_idle_minutes||30)||30));
  renderRuntimeSettings();
}
function renderRuntimeSettings(){
  const settings=state.runtimeSettings||{};
  const output=$('#runtimeOutputDirectory');
  if(output)output.value=state.pendingRuntimeOutput||settings.output_directory||'';
  $$('[data-runtime-profile]').forEach(b=>b.classList.toggle('active',b.dataset.runtimeProfile===state.pendingPerformanceProfile));
  $$('[data-vram-policy]').forEach(b=>b.classList.toggle('active',b.dataset.vramPolicy===state.pendingVramPolicy));
  $$('[data-backend-policy]').forEach(b=>b.classList.toggle('active',b.dataset.backendPolicy===state.pendingBackendPolicy));
  const vramIdle=$('#vramIdleMinutes');
  if(vramIdle){vramIdle.value=String(state.pendingVramIdleMinutes);vramIdle.disabled=state.pendingVramPolicy!=='idle'||state.runtimeApplying}
  const backendIdle=$('#backendIdleMinutes');
  if(backendIdle){backendIdle.value=String(state.pendingBackendIdleMinutes);backendIdle.disabled=state.pendingBackendPolicy!=='idle'||state.runtimeApplying}
  const lifecycleInfo=$('#runtimeLifecycleInfo');
  if(lifecycleInfo){
    const vramLabels={keep:'Быстрый повтор',idle:'Автоочистка',immediate:'Сразу освобождать'};
    const backendLabels={keep:'Движок остаётся',exit:'Остановить при выходе',idle:'Автостоп'};
    lifecycleInfo.textContent='VRAM: '+(vramLabels[state.pendingVramPolicy]||state.pendingVramPolicy)+' · Backend: '+(backendLabels[state.pendingBackendPolicy]||state.pendingBackendPolicy);
  }
  const free=Number(settings.output_free_bytes||0);
  const known=Array.isArray(settings.known_output_directories)?settings.known_output_directories.length:0;
  const info=$('#runtimeOutputInfo');
  if(info){
    const parts=[];
    if(free>0)parts.push('Свободно '+(free/1073741824).toFixed(1)+' ГБ');
    if(known>1)parts.push('Галерея помнит папок: '+known);
    info.textContent=parts.join(' · ')||'Папка будет проверена на запись перед применением.';
  }
  const labels={auto:'Авто',balanced:'Balanced',lowram:'Low-RAM'};
  const effective=String(settings.effective_performance_profile||'');
  const activeOut=String(settings.backend_output_directory||'');
  const effectiveEl=$('#runtimeEffectiveProfile');
  if(effectiveEl){
    const parts=[];
    if(effective)parts.push('Сейчас: '+(labels[effective]||effective));
    if(activeOut&&normalizeRuntimePath(activeOut)!==normalizeRuntimePath(settings.output_directory))parts.push('папка backend требует перезапуска');
    effectiveEl.textContent=parts.join(' · ');
  }
  const dirty=runtimeSettingsDirty(),badge=$('#runtimeSettingsBadge');
  if(badge){badge.textContent=dirty?'Есть изменения':'Активно';badge.className='health-badge '+(dirty?'warning':'ok')}
  const apply=$('#applyRuntimeSettings');
  if(apply){
    apply.disabled=state.runtimeApplying||!dirty||queueHasJobs();
    apply.textContent=state.runtimeApplying?'Применяю…':'Применить';
  }
  const reset=$('#resetRuntimeSettings');
  if(reset)reset.disabled=state.runtimeApplying||(
    normalizeRuntimePath(state.pendingRuntimeOutput)===normalizeRuntimePath(settings.default_output_directory)
    && state.pendingPerformanceProfile==='auto'
    && state.pendingVramPolicy==='keep'
    && Number(state.pendingVramIdleMinutes)===10
    && state.pendingBackendPolicy==='keep'
    && Number(state.pendingBackendIdleMinutes)===30
  );
  const status=$('#runtimeSettingsStatus');
  if(status){
    status.textContent=dirty
      ?'Изменения ещё не применены. Политики VRAM/backend меняются без перезапуска; папка или профиль AI-движка требуют безопасного перезапуска.'
      :'Политики работают только при пустой очереди. Если ComfyUI занят или его очередь недоступна, LocalGen ничего не выгружает и не останавливает.';
  }
}
async function chooseRuntimeOutput(){
  if(state.runtimeApplying)return;
  const r=await api('choose_output_directory');
  if(!r.ok){if(!r.cancelled)toast(r.message||'Не удалось выбрать папку',true);return}
  state.pendingRuntimeOutput=r.path||state.pendingRuntimeOutput;
  renderRuntimeSettings();
}
function resetRuntimeSettingsForm(){
  const settings=state.runtimeSettings||{};
  state.pendingRuntimeOutput=String(settings.default_output_directory||'');
  state.pendingPerformanceProfile='auto';
  state.pendingVramPolicy='keep';
  state.pendingVramIdleMinutes=10;
  state.pendingBackendPolicy='keep';
  state.pendingBackendIdleMinutes=30;
  renderRuntimeSettings();
}
async function applyRuntimeSettingsUi(){
  if(state.runtimeApplying)return;
  if(queueHasJobs()||state.jobId){toast('Дождись завершения очереди перед сменой runtime-настроек',true);return}
  if(!runtimeSettingsDirty())return;
  state.runtimeApplying=true;renderRuntimeSettings();
  try{
    const r=await api(
      'apply_runtime_settings',
      state.pendingRuntimeOutput,
      state.pendingPerformanceProfile,
      state.pendingVramPolicy,
      Number(state.pendingVramIdleMinutes)||10,
      state.pendingBackendPolicy,
      Number(state.pendingBackendIdleMinutes)||30
    );
    if(!r.ok){toast(r.message||'Не удалось применить настройки',true);return}
    state.backend=r;
    syncRuntimeSettings(r.runtime_settings||r.settings);
    await loadState();
    await runHealthCheck(true);
    await loadLibrary();
    toast(r.settings?.restarted?'Настройки применены, AI-движок безопасно перезапущен':'Настройки применены без перезапуска движка');
  }finally{
    state.runtimeApplying=false;renderRuntimeSettings();
  }
}

async function runHealthCheck(silent=false){
  const r=await api('health_check');
  const badge=$('#healthBadge'),box=$('#healthChecks');
  if(!r.ok){
    badge.textContent='Ошибка';badge.className='health-badge error';
    box.innerHTML='<div class="health-row bad"><b>Не удалось проверить</b><span>'+esc(r.message||'Неизвестная ошибка')+'</span></div>';
    if(!silent)toast(r.message||'Проверка не удалась',true);
    return;
  }
  const labels={ok:'Всё в порядке',warning:'Есть предупреждения',error:'Нужна проверка'};
  badge.textContent=labels[r.overall]||r.overall;badge.className='health-badge '+r.overall;
  box.innerHTML=(r.checks||[]).map(c=>'<div class="health-row '+(c.ok?'good':'bad')+'"><i></i><div><b>'+esc(c.label)+'</b><span>'+esc(c.detail)+'</span></div></div>').join('');
  const temp=r.temp_bytes?((r.temp_bytes/1048576).toFixed(1)+' МБ'):'0 МБ';
  box.innerHTML+='<div class="health-foot">Активных задач: '+(r.active_jobs||0)+' · Временных файлов: '+(r.temp_files||0)+' ('+temp+')</div>';
  if(!silent)toast('Проверка завершена');
}
async function maintenanceAction(kind){
  if(kind==='restart'&&!confirm('Перезапустить AI-движок? Активные задачи не будут затронуты: при активной задаче операция просто не выполнится.'))return;
  const map={free:['free_vram','VRAM освобождена'],restart:['restart_backend','AI-движок перезапущен'],clean:['clean_temp','Временные файлы очищены']};
  const [method,success]=map[kind]; const r=await api(method);
  if(!r.ok){toast(r.message||'Операция не выполнена',true);return}
  if(kind==='clean')toast('Удалено временных файлов: '+(r.removed||0));
  else toast(success);
  await loadState();await runHealthCheck(true);
}
function renderAppUpdate(){
  const u=state.updateState||{},badge=$('#updateBadge'),info=$('#updateInfo'),status=$('#updateStatusText');
  if(!badge||!info||!status)return;
  const source=!!u.source_configured,s=String(u.status||'idle'),ver=String(u.version||''),current=String(u.current_version||state.backend?.app_version||'');
  let label='Готово',cls='health-badge ok',text='Можно проверить наличие новой версии.';
  if(!source){label='Не настроено';cls='health-badge';text='Источник подписанных обновлений пока не настроен в этой сборке.'}
  else if(s==='available'){label='Доступно';cls='health-badge warning';text='Доступна версия '+ver+'. Сначала пакет будет скачан и полностью проверен.'}
  else if(s==='staged'){label='Проверено';cls='health-badge ok';text='Версия '+ver+' загружена и проверена. Установка начнётся только после перезапуска.'}
  else if(s==='applying'){label='Установка';cls='health-badge warning';text='Обновление подготовлено к применению после закрытия LocalGen.'}
  else if(s==='installed'){label='Установлено';cls='health-badge ok';text='Обновление '+ver+' установлено.'}
  else if(s==='failed'){label='Ошибка';cls='health-badge error';text='Обновление не установлено: '+String(u.last_result?.message||'неизвестная ошибка')}
  else if(s==='current'){label='Актуально';cls='health-badge ok';text='Установлена актуальная версия.'}
  badge.textContent=label;badge.className=cls;
  info.textContent='Текущая версия: '+(current||'неизвестно')+(ver&&ver!==current?' · найдено: '+ver:'');
  status.textContent=text;
  $('#checkAppUpdate').disabled=state.updateBusy||!source;
  $('#updateCheckOnStart').checked=!!state.updateCheckOnStart;
  $('#updateCheckOnStart').disabled=!source;
  $('#downloadAppUpdate').classList.toggle('hidden',s!=='available');
  $('#downloadAppUpdate').disabled=state.updateBusy;
  $('#applyAppUpdate').classList.toggle('hidden',s!=='staged');
  $('#applyAppUpdate').disabled=state.updateBusy;
}
async function loadUpdateStatus({allowAuto=false}={}){
  const r=await api('update_status');
  state.updateState=r?.ok?r:{ok:false,source_configured:false,status:'failed',last_result:{message:r?.message||'Не удалось прочитать состояние обновлений'}};
  renderAppUpdate();
  if(allowAuto&&!state.updateAutoChecked&&state.updateCheckOnStart&&r?.ok&&r.source_configured){
    state.updateAutoChecked=true;await checkAppUpdate(true);
  }
}
async function checkAppUpdate(silent=false){
  if(state.updateBusy)return;
  state.updateBusy=true;renderAppUpdate();
  try{
    const r=await api('check_for_updates');
    if(!r.ok){if(!silent)toast(r.message||'Не удалось проверить обновления',true);return}
    await loadUpdateStatus();
    if(!silent)toast(r.update_available?'Найдена новая версия LocalGen':'Установлена актуальная версия');
  }finally{state.updateBusy=false;renderAppUpdate()}
}
async function downloadAppUpdate(){
  if(state.updateBusy)return;
  state.updateBusy=true;renderAppUpdate();
  try{
    const r=await api('download_update');
    if(!r.ok){toast(r.message||'Не удалось загрузить обновление',true);return}
    await loadUpdateStatus();toast('Обновление загружено и проверено');
  }finally{state.updateBusy=false;renderAppUpdate()}
}
async function applyAppUpdate(){
  if(state.updateBusy)return;
  if(!confirm('Установить проверенное обновление и перезапустить LocalGen?'))return;
  state.updateBusy=true;renderAppUpdate();
  const r=await api('apply_update');
  if(!r.ok){state.updateBusy=false;renderAppUpdate();toast(r.message||'Не удалось начать обновление',true);return}
  $('#updateStatusText').textContent='LocalGen закрывается для безопасной установки обновления…';
}
function wireUi(){
  $$('.nav-item[data-view]').forEach(b=>b.onclick=()=>switchView(b.dataset.view));
  const openHelp=()=>$('#helpModal').classList.remove('hidden');
  const closeHelp=()=>$('#helpModal').classList.add('hidden');
  $('#helpBtn').onclick=openHelp;$('#helpClose').onclick=closeHelp;$('#helpOk').onclick=closeHelp;
  $('#queuePill').onclick=openQueueModal;$('#queueClose').onclick=closeQueueModal;$('#queueDone').onclick=closeQueueModal;$('#queueClearPending').onclick=clearPendingQueue;
  $('#characterClose').onclick=closeCharacterModal;$('#characterCancel').onclick=closeCharacterModal;$('#characterSave').onclick=commitCharacterSave;
  $('#characterName').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();commitCharacterSave()}});
  $$('[data-window]').forEach(b=>b.onclick=async()=>{
    const a=b.dataset.window;
    if(a==='maximize'){state.maximized=!state.maximized;await api('window_action',state.maximized?'maximize':'restore')}
    else await api('window_action',a);
  });
  $('#createPrompt').addEventListener('input',schedulePrompt);
  $('#autoModelToggle').onclick=()=>{state.autoModel=!state.autoModel;state.autoRecommendation=null;state.autoRequestSeq++;savePrefs();renderAutoModelStatus();if(state.autoModel)schedulePrompt()};
  $('#promptMode').addEventListener('change',()=>{savePrefs();schedulePrompt()});
  for(const [id,key] of [['promptStyle','promptStyle'],['promptLighting','promptLighting'],['promptCamera','promptCamera'],['promptFraming','promptFraming']]){
    $('#'+id).addEventListener('change',e=>{state[key]=e.target.value||'auto';updatePromptStudioSummary();savePrefs();schedulePrompt()});
  }
  $('#editPrompt').addEventListener('input',scheduleEditPrompt);
  $('#motionPrompt').addEventListener('input',scheduleMotionPrompt);
  $('#editPromptMode').addEventListener('change',()=>{savePrefs();scheduleEditPrompt()});
  $('#motionPromptMode').addEventListener('change',()=>{savePrefs();scheduleMotionPrompt()});
  $('#createWidth').addEventListener('input',()=>{syncAspectFromCurrentSize({persist:false});renderResolutionPlanner();renderDeliveryPresets();updateGenerateHint()});$('#createWidth').addEventListener('change',()=>{syncAspectFromCurrentSize({persist:true});renderResolutionPlanner();renderDeliveryPresets();updateGenerateHint()});
  $('#createHeight').addEventListener('input',()=>{syncAspectFromCurrentSize({persist:false});renderResolutionPlanner();renderDeliveryPresets();updateGenerateHint()});$('#createHeight').addEventListener('change',()=>{syncAspectFromCurrentSize({persist:true});renderResolutionPlanner();renderDeliveryPresets();updateGenerateHint()});
  $$('[data-create-quality]').forEach(b=>b.onclick=()=>{
    const mode=b.dataset.createQuality;
    state.createQuality=['standard','max','custom'].includes(mode)?mode:'standard';
    if(state.createQuality==='custom')$('#expertModelPanel').open=true;
    savePrefs();renderExpertModelControls();renderCreateQuality();updateGenerateHint();
  });
  $$('[data-delivery]').forEach(b=>b.onclick=()=>{state.deliveryPreset=b.dataset.delivery||'native';savePrefs();renderDeliveryPresets();updateGenerateHint()});
  $('#resetExpertModel').onclick=resetExpertModel;
  $('#createVariants').addEventListener('change',e=>{state.batchCount=Math.max(1,Math.min(4,+e.target.value||1));savePrefs();updateGenerateHint()});
  $('#pastePrompt').onclick=async()=>{try{$('#createPrompt').value=await navigator.clipboard.readText();schedulePrompt()}catch{toast('Не удалось прочитать текст из буфера',true)}};
  $('#clearPrompt').onclick=()=>{$('#createPrompt').value='';$('#processedPrompt').value='';state.autoRecommendation=null;state.autoRequestSeq++;renderAutoModelStatus()};
  $('#cleanStartCreate').onclick=cleanStartCreateContext;
  $('#copyProcessed').onclick=()=>api('copy_text',$('#processedPrompt').value).then(()=>toast('Промпт скопирован'));
  $('#addCreateReferences').onclick=pickCreateReferences;
  $('#pasteCreateReference').onclick=pasteCreateReference;
  $('#clearCreateReferences').onclick=clearCreateReferences;
  $('#useQwenForReferences').onclick=selectQwenForReferences;
  $$('[data-structure-mode]').forEach(b=>b.onclick=()=>setStructureMode(b.dataset.structureMode));
  $('#pickStructureControl').onclick=pickStructureControl;
  $('#pasteStructureControl').onclick=pasteStructureControl;
  $('#clearStructureControl').onclick=clearStructureControl;
  $('#useZImageForStructure').onclick=selectZImageForStructure;
  $('#structureStrength').addEventListener('input',e=>{state.structureStrength=Math.max(.1,Math.min(1.5,+e.target.value||1));renderStructureControl();updateGenerateHint()});
  wireCreateReferenceDrop();renderCreateReferences();renderStructureControl();
  $('#generateBtn').onclick=doGenerate;$('#modelShootoutBtn').onclick=openModelShootout;$('#editBtn').onclick=doEdit;$('#animateBtn').onclick=doAnimate;$('#enhanceBtn').onclick=doEnhance;
  $('#finalizeResult').onclick=()=>finalizeCreateJob(state.currentResultJob,state.lastOutput);
  $('#inspectDetailsResult').onclick=inspectCurrentResult;
  $('#qualityInspectClose').onclick=closeQualityInspector;$('#qualityInspectCancel').onclick=closeQualityInspector;
  $('#qualityInspectRepair').onclick=prepareQualityRegionRepair;
  $('#qualityInspectModal').addEventListener('mousedown',e=>{if(e.target===$('#qualityInspectModal'))closeQualityInspector()});
  $('#repeatResult').onclick=()=>repeatCreateJob(state.currentResultJob,state.lastOutput);
  $('#variantsResult').onclick=()=>runMoreVariants(state.currentResultJob,state.lastOutput,state.lastOutputUrl);
  $('#copyResult').onclick=()=>resultAction('copy');$('#compareResult').onclick=()=>resultAction('compare');$('#saveResult').onclick=()=>resultAction('save');$('#revealResult').onclick=()=>resultAction('reveal');$('#deleteResult').onclick=deleteCurrentResult;
  $('#resultImage').onclick=openResultViewer;$$('.mirror-stage img').forEach(img=>img.onclick=openResultViewer);
  $('#resultViewerClose').onclick=closeResultViewer;$('#resultViewerReset').onclick=resetResultViewer;$('#resultViewerReveal').onclick=()=>resultAction('reveal');
  const viewerStage=$('.result-viewer-stage');
  viewerStage.addEventListener('wheel',e=>{if($('#resultViewerModal').classList.contains('hidden')||!viewerStage.classList.contains('image'))return;e.preventDefault();const next=Math.max(1,Math.min(8,resultViewerScale*(e.deltaY<0?1.15:1/1.15)));if(next===1){resultViewerX=0;resultViewerY=0}resultViewerScale=next;applyResultViewerTransform()},{passive:false});
  viewerStage.addEventListener('mousedown',e=>{if(resultViewerScale<=1||!viewerStage.classList.contains('image'))return;resultViewerDragging=true;resultViewerStartX=e.clientX-resultViewerX;resultViewerStartY=e.clientY-resultViewerY;viewerStage.classList.add('dragging');e.preventDefault()});
  window.addEventListener('mousemove',e=>{if(!resultViewerDragging)return;resultViewerX=e.clientX-resultViewerStartX;resultViewerY=e.clientY-resultViewerStartY;applyResultViewerTransform()});
  window.addEventListener('mouseup',()=>{resultViewerDragging=false;viewerStage.classList.remove('dragging')});
  $('#resultViewerModal').addEventListener('mousedown',e=>{if(e.target===$('#resultViewerModal'))closeResultViewer()});
  $('#saveCharacterResult').onclick=()=>saveCharacterFrom(state.lastOutput,$('#createPrompt').value.trim());
  $$('[data-stop-job]').forEach(b=>b.onclick=cancelCurrent);
  $$('[data-send]').forEach(b=>b.onclick=()=>sendLast(b.dataset.send));
  $$('[data-pick]').forEach(b=>b.onclick=()=>pickSource(b.dataset.pick));
  $$('[data-paste]').forEach(b=>b.onclick=()=>pasteSource(b.dataset.paste));
  $$('[data-last]').forEach(b=>b.onclick=()=>sendLast(b.dataset.last));
  $$('[data-edit-mode]').forEach(b=>b.onclick=()=>applyEditMode(b.dataset.editMode));
  $('#drawMaskBtn').onclick=openMaskEditor;
  $$('[data-ref-pick]').forEach(b=>b.onclick=()=>pickEditReference(+b.dataset.refPick));
  $$('[data-ref-paste]').forEach(b=>b.onclick=()=>pasteEditReference(+b.dataset.refPaste));
  $$('[data-ref-clear]').forEach(b=>b.onclick=()=>setEditReference(+b.dataset.refClear,''));
  $$('[data-ref-role]').forEach(s=>s.onchange=()=>{state.editReferenceRoles[+s.dataset.refRole]=s.value||'auto'});
  $$('.reference-slot').forEach(el=>wireReferenceDrop(el,+el.dataset.referenceSlot));
  renderEditReferences();
  $('#createCharacterSelect').onchange=e=>{state.createCharacter=e.target.value||'';savePrefs();updateCreateCharacterUI();updateGenerateHint()};
  $('#editCharacterSelect').onchange=()=>{$('#deleteCharacter').disabled=!$('#editCharacterSelect').value};
  $('#applyEditCharacter').onclick=applyEditCharacter;
  $('#saveEditSourceCharacter').onclick=()=>saveCharacterFrom(state.editSource,$('#editPrompt').value.trim());
  $('#deleteCharacter').onclick=deleteSelectedCharacter;
  $('#animateCharacterSelect').onchange=()=>{};
  $('#applyAnimateCharacter').onclick=applyAnimateCharacter;
  $('#referenceCard').classList.toggle('hidden',state.editMode==='exact');
  $$('[data-duration-seconds]').forEach(b=>b.onclick=()=>{
    state.animateSeconds=+b.dataset.durationSeconds||2;syncAnimateTemporal();savePrefs();renderAnimateControls();
  });
  $('#animateSeconds').addEventListener('input',e=>{state.animateSeconds=Math.max(.1,+e.target.value||2);syncAnimateTemporal();updateAnimateHint()});
  $('#animateSeconds').addEventListener('change',()=>{syncAnimateTemporal();savePrefs();renderAnimateControls()});
  $('#animateFps').addEventListener('change',e=>{state.fps=Math.round(+e.target.value||16);syncAnimateTemporal();savePrefs();renderAnimateControls()});
  const commitAnimateSize=()=>{
    const w=Math.round((+$('#animateWidth').value||640)/16)*16,h=Math.round((+$('#animateHeight').value||640)/16)*16;
    state.animateWidth=w;state.animateHeight=h;savePrefs();renderAnimateControls();updateAnimateHint();
  };
  $('#animateWidth').addEventListener('change',commitAnimateSize);$('#animateHeight').addEventListener('change',commitAnimateSize);
  $('#animateSeed').addEventListener('change',e=>{state.animateSeed=String(e.target.value||'').trim();savePrefs();updateAnimateHint()});
  $('#animateSteps').addEventListener('change',e=>setAnimateExpert('steps',Number(e.target.value)));
  $('#animateCfg').addEventListener('change',e=>setAnimateExpert('cfg',Number(e.target.value)));
  $('#animateShift').addEventListener('change',e=>setAnimateExpert('shift',Number(e.target.value)));
  $('#animateSampler').addEventListener('change',e=>setAnimateExpert('sampler',e.target.value));
  $('#animateNegative').addEventListener('change',e=>setAnimateExpert('negative',e.target.value));
  $('#resetAnimateExpert').onclick=resetAnimateExpert;
  $$('[data-enhance-type]').forEach(b=>b.onclick=()=>{
    state.enhanceType=b.dataset.enhanceType;
    savePrefs();
    $$('[data-enhance-type]').forEach(x=>x.classList.toggle('active',x===b));
    updateEnhanceUI();
  });
  $$('[data-image-enhance]').forEach(b=>b.onclick=()=>{
    state.imageEnhanceMode=b.dataset.imageEnhance;savePrefs();updateEnhanceUI();
  });
  $$('[data-video-enhance]').forEach(b=>b.onclick=()=>{
    state.videoEnhanceMode=b.dataset.videoEnhance;savePrefs();updateEnhanceUI();
  });
  $$('[data-scale]').forEach(b=>b.onclick=()=>{
    if(b.disabled)return;
    state.scale=+b.dataset.scale;savePrefs();updateEnhanceUI();
  });
  $('#enhancePick').onclick=()=>pickSource('enhance');$('#openOutputs').onclick=()=>api('open_outputs');$('#refreshState').onclick=loadState;
  $('#historyClose').onclick=closePromptHistory;$('#historyDone').onclick=closePromptHistory;$('#historyClear').onclick=clearPromptHistoryModal;
  $('#historyModal').addEventListener('mousedown',e=>{if(e.target===$('#historyModal'))closePromptHistory()});
  $('#shootoutClose').onclick=closeShootoutModal;$('#shootoutCancel').onclick=closeShootoutModal;$('#shootoutRun').onclick=runModelShootout;
  $('#shootoutSelectAll').onclick=()=>{$$('[data-shootout-model]',$('#shootoutModels')).forEach(x=>x.checked=true);updateShootoutSelectionCount()};
  $('#shootoutClear').onclick=()=>{$$('[data-shootout-model]',$('#shootoutModels')).forEach(x=>x.checked=false);updateShootoutSelectionCount()};
  $('#compareClose').onclick=closeBatchCompare;$('#compareDone').onclick=closeBatchCompare;
  $('#beforeAfterClose').onclick=closeBeforeAfter;$('#beforeAfterDone').onclick=closeBeforeAfter;
  $('#beforeAfterSlider').addEventListener('input',e=>updateBeforeAfter(e.target.value));
  $('#userPresetSelect').onchange=e=>{const id=e.target.value;$('#deleteUserPreset').disabled=!id;if(id)applyUserPreset(id)};
  $('#saveUserPreset').onclick=saveUserPreset;$('#deleteUserPreset').onclick=deleteUserPreset;
  $('#chooseRuntimeOutput').onclick=chooseRuntimeOutput;$('#openRuntimeOutput').onclick=()=>api('reveal',state.pendingRuntimeOutput||state.runtimeSettings?.output_directory||'');
  $$('[data-runtime-profile]').forEach(b=>b.onclick=()=>{state.pendingPerformanceProfile=b.dataset.runtimeProfile||'auto';renderRuntimeSettings()});
  $$('[data-vram-policy]').forEach(b=>b.onclick=()=>{state.pendingVramPolicy=b.dataset.vramPolicy||'keep';renderRuntimeSettings()});
  $$('[data-backend-policy]').forEach(b=>b.onclick=()=>{state.pendingBackendPolicy=b.dataset.backendPolicy||'keep';renderRuntimeSettings()});
  $('#vramIdleMinutes').oninput=e=>{state.pendingVramIdleMinutes=Math.max(1,Math.min(120,Number(e.target.value)||10));renderRuntimeSettings()};
  $('#backendIdleMinutes').oninput=e=>{state.pendingBackendIdleMinutes=Math.max(5,Math.min(240,Number(e.target.value)||30));renderRuntimeSettings()};
  $('#applyRuntimeSettings').onclick=applyRuntimeSettingsUi;$('#resetRuntimeSettings').onclick=resetRuntimeSettingsForm;
  $('#runHealthCheck').onclick=()=>runHealthCheck(false);$('#freeVram').onclick=()=>maintenanceAction('free');$('#restartBackend').onclick=()=>maintenanceAction('restart');$('#cleanTemp').onclick=()=>maintenanceAction('clean');
  $('#checkAppUpdate').onclick=()=>checkAppUpdate(false);$('#downloadAppUpdate').onclick=downloadAppUpdate;$('#applyAppUpdate').onclick=applyAppUpdate;
  $('#updateCheckOnStart').onchange=e=>{state.updateCheckOnStart=!!e.target.checked;savePrefs();renderAppUpdate()};
  $$('[data-model-catalog]').forEach(b=>b.onclick=()=>api('open_model_catalog',b.dataset.modelCatalog));
  $('#openModelsFolder').onclick=()=>api('open_model_folder','root');
  $('#importCheckpoint').onclick=()=>importModelFile('checkpoints');
  $('#importDiffusionModel').onclick=()=>importModelFile('diffusion_models');
  $('#importLora').onclick=()=>importModelFile('loras');
  $('#modelHubResolve').onclick=resolveModelHubLink;
  $('#modelHubInstall').onclick=startModelHubDownload;
  $('#modelHubCancel').onclick=cancelModelHubDownload;
  $('#modelHubUrl').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();resolveModelHubLink()}});
  $('#registerCustomModel').onclick=registerCustomModel;
  $('#resetCustomModelForm').onclick=resetCustomModelForm;
  $('#customModelFamily').addEventListener('change',updateCustomModelFields);
  $('#customModelCheckpoint').addEventListener('change',e=>{const item=parseCustomModelFile(e.target.value);if(item)inspectModelInventoryItem(item.folder,item.name)});
  $('#modelInspectorClose').onclick=closeModelInspector;
  $('#modelInspectorUse').onclick=applyInspectionToCustomModel;
  $('#modelInspectorReveal').onclick=()=>{if(state.modelInspection?.path)api('reveal',state.modelInspection.path)};
  $('#uiScaleRange').addEventListener('input',e=>applyUiScale(e.target.value,{persist:false,announce:false}));
  $('#uiScaleRange').addEventListener('change',e=>applyUiScale(e.target.value,{persist:true,announce:true}));
  $$('[data-ui-scale-preset]').forEach(b=>b.onclick=()=>applyUiScale(+b.dataset.uiScalePreset,{persist:true,announce:true}));
  $('#resetPrefs').onclick=()=>{localStorage.removeItem(PREF_KEY);toast('Настройки сброшены');setTimeout(()=>location.reload(),250)};
  $('#exportProfile').onclick=exportProfile;
  $('#importProfile').onclick=importProfile;
  $('#clearPromptHistory').onclick=clearPromptHistory;
  $$('[data-library-filter]').forEach(b=>b.onclick=()=>{
    state.libraryFilter=b.dataset.libraryFilter;
    $$('[data-library-filter]').forEach(x=>x.classList.toggle('active',x===b));
    renderLibrary();
  });
  $('#librarySearch').addEventListener('input',e=>{state.libraryQuery=e.target.value||'';renderLibrary()});
  wireDrop($('#editDrop'),'edit');wireDrop($('#animateDrop'),'animate');wireDrop($('#enhanceDrop'),'enhance');
  window.addEventListener('wheel',handleUiScaleWheel,{passive:false});
  window.addEventListener('resize',syncUiScaleLayout);
  document.addEventListener('keydown',e=>{
    if(e.ctrlKey&&(e.key==='+'||e.key==='=')){e.preventDefault();stepUiScale(1,true);return}
    if(e.ctrlKey&&(e.key==='-'||e.key==='_')){e.preventDefault();stepUiScale(-1,true);return}
    if(e.ctrlKey&&e.key==='0'){e.preventDefault();applyUiScale(100,{persist:true,announce:true});return}
    if(e.key==='Escape'&&!$('#historyModal').classList.contains('hidden')){e.preventDefault();closePromptHistory();return}
    if(e.key==='Escape'&&!$('#characterModal').classList.contains('hidden')){e.preventDefault();closeCharacterModal();return}
    if(e.key==='Escape'&&!$('#helpModal').classList.contains('hidden')){e.preventDefault();$('#helpModal').classList.add('hidden');return}
    if(e.key==='Escape'&&!$('#queueModal').classList.contains('hidden')){e.preventDefault();closeQueueModal();return}
    if(e.key==='Escape'&&!$('#beforeAfterModal').classList.contains('hidden')){e.preventDefault();closeBeforeAfter();return}
    if(e.key==='Escape'&&!$('#resultViewerModal').classList.contains('hidden')){e.preventDefault();closeResultViewer();return}
    if(e.key==='Escape'&&!$('#shootoutModal').classList.contains('hidden')){e.preventDefault();closeShootoutModal();return}
    if(e.key==='Escape'&&!$('#compareModal').classList.contains('hidden')){e.preventDefault();closeBatchCompare();return}
    if(e.key==='Escape'&&!$('#maskModal').classList.contains('hidden')){e.preventDefault();closeMaskEditor();return}
    if(e.ctrlKey&&['1','2','3','4','5','6'].includes(e.key)){
      e.preventDefault();const views={1:'create',2:'edit',3:'animate',4:'enhance',5:'library',6:'settings'};switchView(views[e.key]);return;
    }
    if(e.ctrlKey&&e.key==='Enter'){
      e.preventDefault();
      if(!$('#characterModal').classList.contains('hidden')){commitCharacterSave();return}
      if(!$('#shootoutModal').classList.contains('hidden')){runModelShootout();return}
      if(state.view==='create')doGenerate();
      else if(state.view==='edit')doEdit();
      else if(state.view==='animate')doAnimate();
      else if(state.view==='enhance')doEnhance();
      return;
    }
    if(e.ctrlKey&&e.key.toLowerCase()==='v'&&['edit','animate'].includes(state.view)&&!isTextEntryTarget(e.target)){e.preventDefault();pasteSource(state.view);return}
    if(e.key==='F5'){e.preventDefault();loadState();loadModelManager();if(state.view==='library')loadLibrary();toast('Состояние обновлено')}
  });
}
function parseCustomModelFile(value){
  const raw=String(value||'');const split=raw.indexOf('::');
  if(split<1)return null;
  return {folder:raw.slice(0,split),name:raw.slice(split+2)};
}
function updateCustomModelFields(){
  const family=$('#customModelFamily')?.value||'sdxl';
  $$('.custom-sdxl-only').forEach(x=>x.classList.toggle('hidden',family!=='sdxl'));
}
function resetCustomModelForm(){
  const set=(id,value)=>{const el=$(id);if(el)el.value=value};
  set('#customModelName','');set('#customModelFamily','sdxl');set('#customModelCheckpoint','');set('#customModelSteps','30');set('#customModelCfg','5');
  set('#customModelSampler','dpmpp_2m');set('#customModelScheduler','karras');set('#customModelClipSkip','1');set('#customModelPrediction','eps');
  set('#customModelBestFor','');set('#customModelNegative','');set('#customModelDescription','');
  if($('#customModelZsnr'))$('#customModelZsnr').checked=false;
  updateCustomModelFields();
}
function closeModelInspector(){
  state.modelInspection=null;
  $('#modelInspector')?.classList.add('hidden');
}
function renderModelInspection(data){
  state.modelInspection=data||null;
  const panel=$('#modelInspector');
  if(!panel)return;
  if(!data){panel.classList.add('hidden');return}
  panel.classList.remove('hidden');
  $('#modelInspectorName').textContent=data.suggested_name||data.name||'Файл модели';
  $('#modelInspectorPath').textContent=data.path||'';
  const safeClass=data.safety==='caution'?'warn':'safe';
  const registered=data.registered?'<span class="safe">Уже подключён</span>':'<span>Не подключён</span>';
  $('#modelInspectorBadges').innerHTML=
    '<span>'+esc(data.architecture_label||'Не определено')+'</span>'+
    '<span class="'+safeClass+'">'+esc(data.safety_label||data.format||'')+'</span>'+
    '<span>'+esc(data.size_gb)+' ГБ</span>'+
    '<span>Уверенность: '+esc(data.confidence||'—')+'</span>'+registered;
  const used=(data.used_by_names||[]).join(', ')||'—';
  const options=data.registration_options||[];
  const registerLabel=options.length?options.map(x=>x.label||x.family).join(', '):'Нет';
  const rows=[
    ['Формат',(data.format||'—').toUpperCase()],
    ['Папка',data.folder||'—'],
    ['Workflow',data.workflow||'—'],
    ['Tensor keys',String(data.tensor_key_count??0)],
    ['Header',data.header_bytes?Math.round(data.header_bytes/1024)+' КБ':'—'],
    ['Используется',used],
    ['Можно подключить',registerLabel],
    ['Файл',data.name||'—']
  ];
  $('#modelInspectorGrid').innerHTML=rows.map(x=>'<div><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>').join('');
  $('#modelInspectorNote').textContent=[data.register_reason,data.safety_note,data.header_error].filter(Boolean).join(' ');
  const meta=data.metadata||{},metaWrap=$('#modelInspectorMetaWrap'),metaBox=$('#modelInspectorMeta');
  if(Object.keys(meta).length){
    metaWrap.classList.remove('hidden');
    metaBox.textContent=JSON.stringify(meta,null,2);
  }else{
    metaWrap.classList.add('hidden');
    metaWrap.open=false;
    metaBox.textContent='';
  }
  const use=$('#modelInspectorUse');
  use.classList.toggle('hidden',!data.register_supported);
  if(data.register_supported){const first=(data.registration_options||[])[0];use.textContent='Подставить'+(first?.label?' как '+first.label:'')}
}
function applyInspectionToCustomModel(){
  const data=state.modelInspection;
  const option=(data?.registration_options||[])[0];
  if(!data?.register_supported||!option){toast('Для этого файла нет проверенного Create workflow',true);return}
  const set=(id,value)=>{const el=$(id);if(el&&value!==undefined&&value!==null)el.value=String(value)};
  set('#customModelFamily',option.family||'sdxl');
  set('#customModelCheckpoint',(data.folder||option.folder)+'::'+data.name);
  set('#customModelName',data.suggested_name||data.name);
  const d=data.recommended_settings||{};
  set('#customModelSteps',d.steps??30);set('#customModelCfg',d.cfg??5);
  set('#customModelSampler',d.sampler||'dpmpp_2m');set('#customModelScheduler',d.scheduler||'karras');
  set('#customModelClipSkip',d.clip_skip??1);set('#customModelPrediction',d.prediction||'eps');
  if($('#customModelZsnr'))$('#customModelZsnr').checked=!!d.zsnr;
  set('#customModelNegative',d.negative||'');
  updateCustomModelFields();
  const details=$('.custom-model-add');if(details)details.open=true;
  $('#customModelName')?.focus();
  toast('Совместимость проверена. Рекомендуемые параметры подставлены');
}
async function inspectModelInventoryItem(folder,name){
  if(!folder||!name)return;
  const panel=$('#modelInspector');
  panel?.classList.remove('hidden');
  if($('#modelInspectorName'))$('#modelInspectorName').textContent='Проверяю '+name+'…';
  if($('#modelInspectorGrid'))$('#modelInspectorGrid').innerHTML='';
  const r=await api('inspect_model',folder,name);
  if(!r.ok){closeModelInspector();toast(r.message||'Не удалось проверить модель',true);return null}
  renderModelInspection(r);
  return r;
}
function formatModelHubBytes(value){
  const n=Math.max(0,Number(value)||0);
  if(!n)return 'размер не указан';
  const units=['Б','КБ','МБ','ГБ','ТБ'];let v=n,i=0;
  while(v>=1024&&i<units.length-1){v/=1024;i++}
  return (i<2?Math.round(v):v.toFixed(v>=100?0:v>=10?1:2))+' '+units[i];
}
function selectModelHubCandidate(id){
  const item=(state.modelHubCandidates||[]).find(x=>x.id===id);
  if(!item)return;
  state.modelHubCandidateId=id;
  $$('[data-model-hub-candidate]').forEach(x=>x.classList.toggle('active',x.dataset.modelHubCandidate===id));
  if($('#modelHubFolder'))$('#modelHubFolder').value=item.folder_hint||'checkpoints';
  if($('#modelHubInstall')){$('#modelHubInstall').disabled=false;$('#modelHubInstall').textContent='Скачать и проверить'}
}
function renderModelHubCandidates(){
  const list=$('#modelHubCandidates'),wrap=$('#modelHubResolved');if(!list||!wrap)return;
  const items=state.modelHubCandidates||[];
  wrap.classList.toggle('hidden',!items.length);
  list.innerHTML=items.map(x=>{
    const hash=x.sha256?'<span class="verified">SHA-256</span>':'<span>без опубликованного хэша</span>';
    return '<button type="button" class="model-hub-candidate" data-model-hub-candidate="'+esc(x.id)+'">'+
      '<div><strong>'+esc(x.filename)+'</strong><small>'+esc(x.source_label||x.provider_label||'')+'</small></div>'+
      '<div class="model-hub-candidate-meta"><span>'+esc(formatModelHubBytes(x.bytes))+'</span><span>'+esc((x.format||'').toUpperCase())+'</span><span>'+esc(x.folder_hint||'checkpoints')+'</span>'+hash+'</div>'+
      (x.detail?'<p>'+esc(x.detail)+'</p>':'')+
    '</button>';
  }).join('');
  $$('[data-model-hub-candidate]',list).forEach(b=>b.onclick=()=>selectModelHubCandidate(b.dataset.modelHubCandidate));
  if(items.length)selectModelHubCandidate(items[0].id);
}
async function resolveModelHubLink(){
  const input=$('#modelHubUrl'),btn=$('#modelHubResolve'),badge=$('#modelHubProvider');
  const source=(input?.value||'').trim();
  if(!source){toast('Вставь ссылку на модель или Hugging Face repo',true);return}
  btn.disabled=true;btn.textContent='Проверяю…';
  if(badge){badge.textContent='Проверка…';badge.classList.remove('ok','warning','error')}
  const r=await api('resolve_model_link',source);
  btn.disabled=false;btn.textContent='Проверить ссылку';
  if(!r.ok){
    state.modelHubCandidates=[];state.modelHubCandidateId='';renderModelHubCandidates();
    if(badge){badge.textContent='Ошибка';badge.classList.add('error')}
    toast(r.message||'Не удалось прочитать ссылку',true);return;
  }
  state.modelHubCandidates=r.candidates||[];state.modelHubCandidateId='';
  if(badge){badge.textContent=state.modelHubCandidates[0]?.provider_label||r.provider||'Готово';badge.classList.add('ok')}
  renderModelHubCandidates();
  toast('Найдено файлов модели: '+state.modelHubCandidates.length);
}
function renderModelDownloadJob(job){
  const box=$('#modelHubDownload');if(!box)return;
  if(!job){box.classList.add('hidden');return}
  box.classList.remove('hidden');
  const statusMap={queued:'В очереди',downloading:'Скачивание',verifying:'Проверка файла',completed:'Готово',cancelled:'Остановлено',error:'Ошибка'};
  $('#modelHubDownloadName').textContent=job.filename||'Загрузка модели';
  $('#modelHubDownloadStatus').textContent=statusMap[job.state]||job.state||'';
  const pct=Math.max(0,Math.min(100,Number(job.percent)||0));
  $('#modelHubProgressBar').style.width=pct+'%';
  const total=Number(job.bytes_total)||0,done=Number(job.bytes_done)||0;
  $('#modelHubProgressBytes').textContent=(done?formatModelHubBytes(done):'0 Б')+(total?' / '+formatModelHubBytes(total):'')+(job.resumed_bytes?' · продолжено с '+formatModelHubBytes(job.resumed_bytes):'');
  $('#modelHubProgressSpeed').textContent=job.state==='downloading'&&job.speed_bps?formatModelHubBytes(job.speed_bps)+'/с':(job.sha256_actual?'SHA-256 проверен':'');
  const cancel=$('#modelHubCancel');cancel.classList.toggle('hidden',!['queued','downloading','verifying'].includes(job.state));cancel.disabled=job.state==='verifying';
  const install=$('#modelHubInstall');
  if(install){
    const active=['queued','downloading','verifying'].includes(job.state);
    install.disabled=active||job.state==='completed'||!state.modelHubCandidateId;
    if(job.state==='cancelled'||job.state==='error')install.textContent='Продолжить загрузку';
    else if(job.state==='completed')install.textContent='Установлено';
    else install.textContent='Скачать и проверить';
  }
  if(job.state==='error'&&job.error)$('#modelHubDownloadStatus').textContent='Ошибка: '+job.error;
  if(job.state==='completed'&&state.modelDownloadHandled!==job.id){
    state.modelDownloadHandled=job.id;
    loadModelManager().then(()=>inspectModelInventoryItem(job.folder,job.filename));
    toast('Модель скачана и проверена: '+job.filename);
  }
}
async function pollModelDownloadState(){
  clearTimeout(state.modelDownloadPollTimer);
  const r=await api('model_download_state');
  if(!r.ok)return;
  let job=null;
  if(state.modelDownloadJobId)job=(r.jobs||[]).find(x=>x.id===state.modelDownloadJobId)||null;
  if(!job)job=r.active||(r.queued||[])[0]||(r.jobs||[])[0]||null;
  if(job){
    state.modelDownloadJobId=job.id;renderModelDownloadJob(job);
    if(['queued','downloading','verifying'].includes(job.state))state.modelDownloadPollTimer=setTimeout(pollModelDownloadState,450);
  }
}
async function startModelHubDownload(){
  const id=state.modelHubCandidateId,folder=$('#modelHubFolder')?.value||'';
  if(!id){toast('Сначала выбери файл модели',true);return}
  const btn=$('#modelHubInstall');btn.disabled=true;btn.textContent='Добавляю в очередь…';
  const r=await api('start_model_download',id,folder);
  if(!r.ok){btn.disabled=false;btn.textContent='Скачать и проверить';toast(r.message||'Не удалось начать загрузку',true);return}
  state.modelDownloadJobId=r.job?.id||'';state.modelDownloadHandled='';
  renderModelDownloadJob(r.job);pollModelDownloadState();
}
async function cancelModelHubDownload(){
  if(!state.modelDownloadJobId)return;
  const r=await api('cancel_model_download',state.modelDownloadJobId);
  if(!r.ok){toast(r.message||'Не удалось остановить загрузку',true);return}
  renderModelDownloadJob(r.job);pollModelDownloadState();
}
function renderModelManager(){
  const inv=state.modelInventory;if(!inv)return;
  const badge=$('#modelInventoryBadge'),summary=$('#modelInventorySummary'),list=$('#modelInventoryList'),profiles=$('#customModelProfiles'),select=$('#customModelCheckpoint');
  if(badge){badge.textContent=inv.total+' файлов';badge.classList.toggle('ok',true)}
  if(summary)summary.innerHTML='<span>Всего: '+esc(inv.total)+'</span><span>Используются: '+esc(inv.registered)+'</span><span>Не зарегистрированы: '+esc(inv.unregistered)+'</span><span>Свои профили: '+esc((inv.custom_profiles||[]).length)+'</span>';
  if(select){
    const candidates=(inv.items||[]).filter(x=>['checkpoints','diffusion_models'].includes(x.folder)&&String(x.name||'').toLowerCase().endsWith('.safetensors'));
    const current=select.value;
    select.innerHTML='<option value="">Выбери совместимый файл…</option>'+candidates.map(x=>{const value=x.folder+'::'+x.name;return '<option value="'+esc(value)+'">'+esc(x.name)+' · '+esc(x.folder)+(x.registered?' · уже используется':'')+'</option>'}).join('');
    if(candidates.some(x=>x.folder+'::'+x.name===current))select.value=current;
  }
  if(profiles){
    const items=inv.custom_profiles||[];
    profiles.innerHTML=items.length?items.map(p=>{const file=p.checkpoint||p.model_file||'—',family=(p.family||'sdxl').toUpperCase(),sched=p.scheduler?' / '+esc(p.scheduler):'';return '<div class="custom-model-profile"><div><strong>'+esc(p.name||file)+'</strong><span>'+esc(file)+' · '+esc(family)+' · '+esc(p.steps)+' steps · CFG '+esc(p.cfg)+' · '+esc(p.sampler)+sched+'</span></div><button data-delete-custom-model="'+esc(p.id)+'">Удалить профиль</button></div>'}).join(''):'';
    $$('[data-delete-custom-model]',profiles).forEach(b=>b.onclick=async()=>{const r=await api('delete_custom_model',b.dataset.deleteCustomModel);if(!r.ok){toast(r.message||'Не удалось удалить профиль',true);return}state.backend=r.backend||state.backend;state.modelInventory=r.inventory||state.modelInventory;renderModels();renderModelManager();toast('Профиль модели удалён. Файл модели оставлен на диске')});
  }
  if(list){
    const items=inv.items||[];
    list.innerHTML=items.length?items.map((x,i)=>'<div class="model-file-row"><strong title="'+esc(x.path)+'">'+esc(x.name)+'</strong><span>'+esc(x.folder)+' · '+esc(x.size_gb)+' ГБ</span><span class="'+(x.registered?'registered':'unregistered')+'">'+(x.registered?'используется':'не подключён')+'</span><button data-inspect-model="'+i+'">Проверить</button></div>').join(''):'<div class="library-empty">Файлы моделей не найдены.</div>';
    $$('[data-inspect-model]',list).forEach(b=>b.onclick=()=>{const it=items[+b.dataset.inspectModel];if(it)inspectModelInventoryItem(it.folder,it.name)});
  }
}
async function loadModelManager(){
  if(!$('#modelInventorySummary'))return;
  const r=await api('model_inventory');
  if(!r.ok){toast(r.message||'Не удалось прочитать модели',true);return}
  state.modelInventory=r;renderModelManager();
}
async function importModelFile(folder){
  const r=await api('import_model_file',folder);
  if(r.cancelled)return;
  if(!r.ok){toast(r.message||'Не удалось импортировать файл',true);return}
  state.modelInventory=r;renderModelManager();toast('Файл '+(r.name||'модели')+' скопирован в LocalGen');
  if(r.name)await inspectModelInventoryItem(folder,r.name);
}
async function registerCustomModel(){
  const file=parseCustomModelFile($('#customModelCheckpoint').value),name=$('#customModelName').value.trim(),family=$('#customModelFamily').value;
  if(!file||!name){toast('Укажи название и файл модели',true);return}
  const settings={
    steps:+$('#customModelSteps').value||30,cfg:+$('#customModelCfg').value||5,
    sampler:$('#customModelSampler').value,scheduler:$('#customModelScheduler').value,
    clip_skip:+$('#customModelClipSkip').value||1,prediction:$('#customModelPrediction').value,
    zsnr:$('#customModelZsnr').checked,best_for:$('#customModelBestFor').value.trim(),
    negative:$('#customModelNegative').value.trim(),description:$('#customModelDescription').value.trim()
  };
  const r=await api('register_custom_model',name,file.folder,file.name,family,settings);
  if(!r.ok){toast(r.message||'Не удалось зарегистрировать модель',true);return}
  state.backend=r.backend||state.backend;state.modelInventory=r.inventory||state.modelInventory;
  renderModels();renderModelManager();resetCustomModelForm();toast('Модель добавлена в Create → Мои модели');
}
async function loadState(){
  const s=await api('ready');if(!s.ok){toast('Не удалось получить состояние LocalGen',true);return}
  state.backend=s;
  syncRuntimeSettings(s.runtime_settings||{});
  if($('#appVersion')) $('#appVersion').textContent='v'+(s.app_version||'0.1.0');
  $('#backendPill').classList.toggle('online',!!s.comfy_online);
  $('#backendPill').classList.toggle('offline',!s.comfy_online);
  $('#backendPill span').textContent=s.comfy_online?'Движок готов':'Запустится автоматически';
  $('#backendDetail').textContent=s.comfy_online?'ComfyUI работает локально на 127.0.0.1:8188':'ComfyUI сейчас выключен и запустится перед первой задачей.';
  const sys=s.system||{},dev=sys.devices?.[0],ram=sys.system?.ram_free;
  $('#systemStats').innerHTML=[
    ram?'Свободно RAM: '+(ram/1073741824).toFixed(1)+' ГБ':'',
    dev?.vram_free?'Свободно VRAM: '+(dev.vram_free/1073741824).toFixed(1)+' ГБ':'',
    'Локальный перевод RU→EN: '+(s.translator_available?'готов':'ещё не установлен')
  ].filter(Boolean).join('<br>');
  const first=s.models.find(x=>x.id===state.createModel&&x.installed)||s.models.find(x=>x.kind==='create'&&x.installed);
  if(first)state.createModel=first.id;
  const anim=s.models.find(x=>x.id===state.animateModel&&x.installed)||s.models.find(x=>x.kind==='animate'&&x.installed);
  if(anim)state.animateModel=anim.id;
  $$('[data-edit-mode]').forEach(x=>x.classList.toggle('active',x.dataset.editMode===state.editMode));
  $('#maskControls').classList.toggle('hidden',state.editMode!=='exact');
  $('#createVariants').value=String(Math.max(1,Math.min(4,+state.batchCount||1)));
  applyPromptStudioControls();
  if(!Number.isFinite(+state.animateSeconds)||+state.animateSeconds<=0)state.animateSeconds=Math.max(.5,(+state.frames||33)/(+state.fps||16));
  $$('[data-enhance-type]').forEach(x=>x.classList.toggle('active',x.dataset.enhanceType===state.enhanceType));
  $$('[data-scale]').forEach(x=>x.classList.toggle('active',+x.dataset.scale===+state.scale));
  restoreCreateSize();renderModels();renderAutoModelStatus();renderExpertModelControls();renderAspects();renderDeliveryPresets();renderCreateQuality();renderCreateReferences();renderStructureControl();updateGenerateHint();renderAnimateControls({modelChanged:true});updateEnhanceUI();
  loadModelManager();
  await loadUpdateStatus({allowAuto:true});
  if(state.autoModel&&$('#createPrompt').value.trim())schedulePrompt();
}
let appInitialized=false;
function init(){
  if(appInitialized)return;
  appInitialized=true;
  initMirrors();wireMaskEditor();wireUi();loadPrefs();applyUiScale(state.uiScale,{persist:false,announce:false});renderUserPresets();loadState();loadLibrary();loadCharacters();refreshQueueState();setInterval(refreshQueueState,900);
}
window.addEventListener('pywebviewready',init);
window.addEventListener('DOMContentLoaded',()=>{
  let tries=0;
  const timer=setInterval(()=>{
    if(window.pywebview?.api){clearInterval(timer);init();return}
    if(++tries>80)clearInterval(timer);
  },100);
});
